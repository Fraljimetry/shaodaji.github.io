// MathReader · Equation indexing, Results/Structure indexing, and Bibliography rendering.
function normalizedReferenceLabel(value) {
  return String(value || '').normalize('NFKC')
    .replace(/(\d)\s*[.·]\s*(?=\d)/g, '$1.')
    .replace(/(\d)\s*[-–—]\s*(?=\d)/g, '$1.')
    .replace(/\s+/g, ' ')
    .replace(/\s*([()[\].,:])\s*/g, '$1')
    .trim().toLocaleLowerCase();
}

const STRUCTURE_STRONG_UNNUMBERED_TYPES = new Set(['theorem', 'lemma', 'proposition', 'corollary', 'definition', 'claim', 'conjecture']);

function normalizedStructureResultText(value) {
  return String(value || '').normalize('NFKC')
    .replace(/(\d)\s*[.·]\s*(?=\d)/g, '$1.')
    .replace(/(\d)\s*[-–—]\s*(?=\d)/g, '$1-')
    .replace(/(\d)\s*·\s*/g, '$1.')
    .replace(/\s+/g, ' ')
    .trim();
}

function canonicalStructureResultType(value) {
  const text = String(value || '').toLocaleLowerCase();
  if (text === 'main result') return 'Main Result';
  return text ? `${text[0].toLocaleUpperCase()}${text.slice(1)}` : '';
}

function structureResultProseReferenceTail(value) {
  const tail = String(value || '').trim();
  if (!tail) return false;
  return /^(?:(?:above|below)\s+)?(?:(?:therefore|hence|thus|then|also|again|now|indeed|similarly|consequently|clearly|in\s+particular)\s+)?(?:shows?|showed|implies?|implied|follows?|followed|gives?|gave|states?|stated|yields?|yielded|guarantees?|guaranteed|provides?|provided|is|was|were|will|can|could|should|may|might|has|have|had|applies?|applied|extends?|extended|justifies?|justified|furnishes?|furnished|ensures?|ensured|says?|said|asserts?|asserted|proves?|proved|establishes?|established|allows?|allowed|requires?|required|means?|meant|contains?|contained)\b/i.test(tail);
}

// A label at the beginning of a visual text line is not sufficient evidence of
// a mathematical declaration. PDF line wrapping can start a sentence fragment
// with "Theorem 4.1 of ..." or "Lemma 4.4 from ...". These unpunctuated,
// lower-case grammatical continuations refer to a result instead of defining
// one. Preserve actual headings with a delimiter ("Theorem 4.1. For ..."),
// parenthetical theorem names, and direct statement starts ("Lemma 2.1 Let ...").
function structureResultUnpunctuatedReferenceTail(fullText, tail) {
  const continuation = String(tail || '').trim();
  if (!/^(?:of|from|in|on|for|with|without|by|to|as|at|under|over|above|below|before|after|within|between|among|about|against|through|across|upon|since|according|and|or|but|where|which|whose|that)\b/.test(continuation)) return false;
  const source = String(fullText || '');
  const beforeTail = source.slice(0, source.length - continuation.length).trimEnd();
  return !/[.:)]$/.test(beforeTail);
}

// Reject a reference before attempting multiple label grammars. Otherwise an
// appendix reference such as "Theorem B.3 from ..." can be partly re-parsed as
// an unrelated "Theorem B" after its complete-label branch rejects it.
function structureResultStartsNarrativeReference(text) {
  const match = String(text || '').match(/^(?:Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+(?:[A-Z]{1,2}(?:[.·-]\d+(?:[.·-]\d+)*)?|\d+(?:[.·-]\d+)*)(?:['’])?\s+(.+)$/i);
  return Boolean(match && structureResultUnpunctuatedReferenceTail(text, match[1]));
}

// Visual PDF text extraction may begin a NEW visual line in the middle of a
// sentence. A later line beginning "Theorem N" is not a declaration when
// the preceding adjacent line supplies "(see", "deduce", "from", etc.
// Use the actual neighboring physical lines; never infer a reference solely
// from the theorem number or from a remote paragraph elsewhere on the page.
function structureResultWrappedProseReference(lines, lineIndex, cleaned) {
  const label = String(cleaned || '').match(/^(?:Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+(?:[A-Z]{1,2}[.·-])?\d+(?:[.·-]\d+)*(?:['’])?(?:[.):,;]|\s|$)/i);
  if (!label || lineIndex < 1) return false;
  const current = lines?.[lineIndex];
  if (!current) return false;
  // Superscripts can be extracted as a separate, extremely short row between
  // the prose reference lead and the quoted theorem label. Look past at most
  // two such tiny fragments; do not skip a substantive line or a column.
  for (let j = lineIndex - 1; j >= Math.max(0, lineIndex - 3); j -= 1) {
    if (j < lineIndex - 1) {
      const intervening = lines[j + 1];
      const width = Number(intervening?.xEndRatio) - Number(intervening?.xStartRatio);
      if (!intervening || String(intervening.text || '').trim().length > 15
          || !Number.isFinite(width) || width > 0.16) break;
    }
    const previous = lines[j];
    if (!previous) break;
    const distance = Number(current.ratio) - Number(previous.ratio);
    // A real separated heading generally has a visibly larger gap. Do not
    // connect distant columns or different reading blocks by content alone.
    if (!Number.isFinite(distance) || distance < 0 || distance > 0.032) break;
    const prevEnd = Number(previous.xEndRatio);
    const currentStart = Number(current.xStartRatio);
    // A neighboring visual row can belong to the opposite PDF column.
    // Check both directions: a right-column reference lead must not suppress
    // a valid left-column Result (the old check only handled the reverse).
    const previousStart = Number(previous.xStartRatio);
    const currentEnd = Number(current.xEndRatio);
    if (Number.isFinite(previousStart) && Number.isFinite(prevEnd)
        && Number.isFinite(currentStart) && Number.isFinite(currentEnd)
        && ((previousStart < 0.49 && currentStart > 0.51)
          || (previousStart > 0.51 && currentStart < 0.49))) continue;
    if (Number.isFinite(prevEnd) && Number.isFinite(currentStart)
        && currentStart > prevEnd + 0.12) continue;
    const before = normalizedStructureResultText(previous.text);
    const endedWithReferenceLead = /(?:\(\s*(?:see|cf\.?|compare)|\b(?:deduce|deduced|from|of|by|see|apply|applying|using|invoke|invoking|recall|recalling|refer\s+to|according\s+to|in|on|with|to))\s*$/i.test(before);
    if (endedWithReferenceLead) return true;
  }
  return false;
}

// A typeset heading sometimes has no PDF text space before its parenthetical
// title: "Theorem 1(Positive mass).Let ...". This is different from citing
// a subpart "Theorem 2.1(a)". Promote only a substantive named heading with
// an actual statement or an otherwise standalone name, never a short part
// marker or a parenthetical prose citation.
function structureResultParentheticalHeadingTail(tail) {
  const source = String(tail || '').trim();
  // Real typeset headings can put sentence text immediately after a closing
  // parenthesis: "Lemma 3. (Sobolev embedding theorem.)Ifk...". This is not
  // a citation or a theorem subpart. Only recover a substantive named heading
  // followed by a recognized mathematical statement opener.
  const ordinary = source.match(/^\(([^()]{3,90})\)(?:\s*([.:])\s*|\s+|$)(.*)$/);
  const joined = ordinary ? null : source.match(
    /^\(([^()]{3,90})\)((?:If|Let|Suppose|For|Given|When|Whenever|There|Every|Each|All|Any|Assume).{2,})$/
  );
  // Named statements can contain nested mathematical parentheses, e.g.
  // "(Weak (1, 1) plus strong (2, 2))" or "(sign of Δg(r−1))".
  // Extract only a bounded, balanced name; an unbalanced reference or a
  // short subpart token such as "(a)" is never a named declaration.
  let match = ordinary || joined;
  if (!match && source[0] === '(') {
    let depth = 0;
    let close = -1;
    for (let i = 0; i < Math.min(source.length, 124); i += 1) {
      if (source[i] === '(') depth += 1;
      else if (source[i] === ')') {
        depth -= 1;
        if (depth < 0) break;
        if (depth === 0) { close = i; break; }
      }
    }
    if (close >= 4 && close <= 100) {
      const following = source.slice(close + 1);
      if (!following || /^\s+(?:[.:]\s*)?/.test(following) || /^[.:]\s*/.test(following)) {
        const after = following.trim().replace(/^[.:]\s*/, '').trim();
        match = [source, source.slice(1, close), after];
      }
    }
  }
  if (!match) return null;
  const name = match[1].trim();
  const after = String(ordinary ? match[3] : match[2] || '').trim();
  if (!/[A-Za-zÀ-ÿ]{2,}/.test(name) || /^(?:see|cf\.?|compare|by|after|before|above|below|part\s+[a-z0-9]|case\s+[a-z0-9])\b/i.test(name)) return null;
  const statementPreposition = /^(?:In|Under)\s+(?:the|a|an|any|every|each|this|these|that)\b/.test(after)
    || /^As\s+(?:distributions?|measures?|functions?|maps?|operators?|sets?|equations?|currents?|forms?|matrices|elements|tensors)\b/i.test(after);
  if (after && (structureResultProseReferenceTail(after)
    || (!statementPreposition && /^(?:and|or|in|from|on|under|as|which|whose|where|that|than|by)\b/i.test(after)))) return null;
  return {name, after};
}

// PDF extraction can split "Proposition 3.1, ..." into a spurious
// "Proposition 3" because the generic numeric-token regex backtracks at
// the first period. Never turn a *prefix* of the observed number into a Result.
function structureResultHasTruncatedNumber(cleaned, recognizedNumber) {
  const observed = String(cleaned || '').match(/^(?:Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+([A-Z]?\d+(?:[.·-]\d+)*)/i);
  return Boolean(observed && observed[1] !== String(recognizedNumber || '').replace(/['’]$/, ''));
}

// Number-first capitalized chapter/section headings can contain the word
// "DEFINITION" without announcing a mathematical Definition. Their title
// phrases are not Result statements, even when repeated as TOC entries.
// Require an all-uppercase, subsection-number-first noun phrase; preserve
// ordinary label-first "Definition 4-1 ..." declarations in the body.
function structureResultLooksLikeNumberedSectionTitle(value) {
  const text = String(value || '').trim();
  const match = text.match(/^\d{1,2}(?:[-–.]\d{1,2}){1,3}[.)]?\s+(?:DEFINITION|THEOREM|LEMMA|PROPOSITION|COROLLARY|REMARK|EXAMPLE)\s+(?:OF|AND|FOR|ON|IN|WITH)\s+(.{3,100})$/);
  return Boolean(match && /^[A-Z][A-Z\s'’&-]+$/.test(match[1].trim()));
}

// General TOC navigation classifier for Results (not a file- or label-specific
// exclusion).  Rows must resemble section/chapter titles with aligned page
// folios; a repeated sequence establishes the context.  The set is per-row,
// never the entire page, because short papers may contain real statements
// immediately beneath their contents listing.
function tocResultLineIndices(lines, page = 1, pageCount = 1) {
  const rows = Array.isArray(lines) ? lines : [];
  if (!rows.length) return new Set();
  const header = rows.some((line) => {
    if (Number(line?.ratio ?? 1) > 0.20) return false;
    return /^(?:(?:[ivxlcdm]+|\d+)\s+)?(?:table\s+of\s+)?contents\s*(?:(?:[ivxlcdm]+|\d+))?$/i.test(String(line?.text || '').trim());
  });
  const tocNumberedLead = /^(?:\d{1,2}(?:[.·\-–—_]\d{1,2}){0,4}[.)]?|[A-H][.)])\s+\S/i;
  const rowFolio = (line) => {
    const text = String(line?.text || '').replace(/\s+/g, ' ').trim();
    if (!tocNumberedLead.test(text) || text.length > 140) return false;
    if (!/\s(?:\d{1,4}|[ivxlcdm]{1,7})$/i.test(text)) return false;
    const parts = Array.isArray(line?.parts) ? line.parts : [];
    const folioPart = parts.length ? parts[parts.length - 1] : null;
    const end = Number(line?.xEndRatio);
    const folioX = Number(folioPart?.xStartRatio);
    const precedingEnd = Number(parts.length >= 2 ? parts[parts.length - 2]?.xEndRatio : NaN);
    // Native PDF text carries separate right-aligned page-number spans.
    if (folioPart && Number.isFinite(folioX) && Number.isFinite(precedingEnd)) {
      const tail = text.slice(Number(folioPart.start || 0), Number(folioPart.end || text.length)).trim();
      return /^(?:\d{1,4}|[ivxlcdm]{1,7})$/i.test(tail)
        && folioX >= 0.72 && folioX - precedingEnd >= 0.025
        && Number(line?.xStartRatio ?? 1) <= 0.35;
    }
    // An OCR record may lack span geometry. Use only when the page itself
    // has a verified multi-row TOC profile (verified below).
    return !parts.length && Number.isFinite(end) && end >= 0.70
      && Number(line?.xStartRatio ?? 1) <= 0.35;
  };
  const candidates = rows.map((line, index) => rowFolio(line) ? index : -1).filter((index) => index >= 0);
  const earlyPage = page <= Math.max(8, Math.ceil(Number(pageCount || 1) * 0.15));
  const hierarchicalRows = candidates.filter((index) => /^\d{1,2}(?:[.·\-–—_]\d{1,2})+[.)]?\s+\S/.test(String(rows[index].text || ''))).length;
  const titleRows = candidates.filter((index) => {
    const title = String(rows[index].text || '')
      .replace(/^(?:\d{1,2}(?:[.·\-–—_]\d{1,2}){0,4}[.)]?|[A-H][.)])\s+/, '')
      .replace(/\s+(?:\d{1,4}|[ivxlcdm]{1,7})$/i, '');
    return (title.match(/[A-Za-zÀ-ÖØ-öø-ÿ]{3,}/g) || []).length >= 2;
  }).length;
  // Continuation-page headers can be degraded or missing in OCR. Without an
  // explicit Contents header, require *repeated subsection* numbers and
  // substantive title text, not merely rows of numerical measurements.
  const established = (header && candidates.length >= 2 && titleRows >= 1)
    || (earlyPage && candidates.length >= 5 && hierarchicalRows >= 3 && titleRows >= 3
      && candidates.length >= rows.length * 0.13);
  return established ? new Set(candidates) : new Set();
}

// A visible back-of-book index header is page-level navigation, not a
// mathematical Result declaration. Require an explicit upper-page index title
// and a dense page of index rows; do not infer this from a lone headword such
// as "Definition" (which can be a genuine unnumbered mathematical Result).
function structureResultsIndexNavigationPage(lines) {
  const rows = Array.isArray(lines) ? lines : [];
  if (rows.length < 12) return false;
  return rows.some((line) => line?.ratio != null && Number.isFinite(Number(line.ratio))
    && Number(line.ratio) >= 0 && Number(line.ratio) <= 0.16
    && /^(?:(?:subject|name|author|phrase[-\s]?finder|general)\s+)?index\s*[.:]?$/i.test(String(line?.text || '').trim()));
}

// Appendix mathematical Results may have the number before the type, unlike
// "Theorem 2.3" in the main text. The compact/decimal family is recognized
// only in a declaration context, and ambiguous OCR glyphs are never guessed.
const APPENDIX_RESULT_TYPE = '(Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)';

function canonicalAppendixResultDigits(raw) {
  const original = String(raw || '').replace(/\s+/g, '');
  if (!/^[0-9lIO]+(?:[.·\-][0-9lIO]+)*$/.test(original)) return null;
  const digits = original.replace(/[lI]/g, '1').replace(/O/g, '0').replace(/·/g, '.');
  const parts = digits.split(/[.\-]/);
  if (parts.some(part => part.length > 3 || !/^\d+$/.test(part) || Number(part) > 999)) return null;
  return digits;
}

function appendixResultNumberPrefix(raw, separator, rawDigits) {
  const digits = canonicalAppendixResultDigits(rawDigits);
  if (!digits) return null;
  return `${raw}${separator === '·' ? '.' : separator}${digits}`;
}

function appendixResultDeclarationSuffix(value) {
  const tail = String(value || '').trim();
  if (!tail) return true; // A standalone bold "C.10 Theorem" is a real label.
  if (/^[.:]\s*\S/.test(tail)) return true;
  if (/^\([^()]{2,85}\)\s*[:.]\s*\S/.test(tail)) return true;
  if (/^(?:Let|Suppose|If|Assume|Given|For\s+every|There\s+(?:exists?|is|are))\b/i.test(tail)) return true;
  return false; // "A.2 Theorem A.1 for ..." is a section heading.
}

function detectedAppendixResult(line, page) {
  const rawText = normalizedStructureResultText(line?.text)
    .replace(/^[·•]\s+(?=[A-Z]{1,2}[.·\-][0-9lIOS]+\b)/, '');
  // An isolated S (e.g. Giusti C.S) is ambiguous between 5 and 8. Keep the
  // original *observation*; resolve only when explicit neighbors independently
  // bracket one unique value. Never publish a guessed label from C.S alone.
  const ambiguous = rawText.match(/^([A-Z]{1,2})[.·\-]S[.)]?\s+(Theorem|Lemma|Proposition|Corollary|Definition|Remark|Example|Claim|Conjecture)\b(.*)$/);
  if (ambiguous && appendixResultDeclarationSuffix(ambiguous[3])) {
    return { ambiguousAppendixOCR: true, appendixPrefix: ambiguous[1], appendixType: canonicalStructureResultType(ambiguous[2]),
      rawText, titleTail: String(ambiguous[3] || '').trim(), page, ratio: line.ratio };
  }
  const first = rawText.match(new RegExp('^([A-Z]{1,2})([.·\\-])([0-9lIO]{1,3}(?:[.·\\-][0-9lIO]{1,3}){0,3})[.)]?\\s+' + APPENDIX_RESULT_TYPE + '\\b(.*)$', 'i'));
  const compact = first ? null : rawText.match(new RegExp('^([A-Z]{1,2})([0-9]{1,3})[.)]?\\s+' + APPENDIX_RESULT_TYPE + '\\b(.*)$'));
  const match = first || compact;
  if (match) {
    // Prefix letters are alphabetic section identifiers, not variables;
    // lowercase math symbols such as "n.1 theorem" are not appendix labels.
    if (match[1] !== match[1].toUpperCase()) return null;
    const type = canonicalStructureResultType(first ? match[4] : match[3]);
    const number = first ? appendixResultNumberPrefix(match[1].toUpperCase(),match[2],match[3]) : `${match[1]}${match[2]}`;
    const tail = String(first ? match[5] : match[4] || '').trim();
    if (!number || !appendixResultDeclarationSuffix(tail)) return null;
    return {label:`${type} ${number}`,title:`${type} ${number}${tail ? `. ${tail.replace(/^[.:]\s*/, '')}` : ''}`.slice(0,180),page,ratio:line.ratio};
  }
  // Eponymic forms: "A.1 De La Vallée Poussin Theorem: Suppose ...".
  // A colon and actual statement are required: section titles such as
  // "A.2 Theorem A.1 for measures" must not become Results.
  const eponymic=rawText.match(/^([A-Z]{1,2})([.·\-])([0-9lIO]{1,3})[.)]?\s+([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’\-]*(?:\s+[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’\-]*){1,6})\s+(Theorem|Lemma|Proposition|Corollary)\s*:\s*(.{8,})$/);
  if (eponymic) {
    const number=appendixResultNumberPrefix(eponymic[1],eponymic[2],eponymic[3]);
    if (!number || structureResultProseReferenceTail(eponymic[6])) return null;
    const type=canonicalStructureResultType(eponymic[5]);
    return {label:`${type} ${number}`,title:`${type} ${number}. ${eponymic[4]} ${type}: ${eponymic[6]}`.slice(0,180),page,ratio:line.ratio};
  }
  return null;
}

function normalizedStructureResultReference(value) {
  const text = String(value || '').replace(/\b(Theorem|Lemma|Proposition|Corollary|Definition|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+([A-Z]{1,2})([.·\-])([0-9lIO]{1,3}(?:[.·\-][0-9lIO]{1,3})*)\b/gi,
    (all,type,prefix,separator,digits) => {
      const number=appendixResultNumberPrefix(prefix.toUpperCase(),separator,digits);
      return number ? `${type} ${number}` : all;
    });
  return normalizedReferenceLabel(text);
}

function recoverBoundedAppendixResultConfusables(entries, observations) {
  const accepted = Array.isArray(entries) ? entries : [];
  for (const candidate of observations || []) {
    if (!candidate || !candidate.ambiguousAppendixOCR) continue;
    const sameFamily = accepted.filter(r => r.label && r.label.startsWith(`${candidate.appendixType} ${candidate.appendixPrefix}.`));
    const before = sameFamily.filter(r => r.page < candidate.page ||
      (r.page === candidate.page && Number(r.ratio) < Number(candidate.ratio)));
    const after = sameFamily.filter(r => r.page > candidate.page ||
      (r.page === candidate.page && Number(r.ratio) > Number(candidate.ratio)));
    const previous=before[before.length-1];
    const next=after[0];
    const prevNum=Number(previous?.label?.match(/\.(\d+)$/)?.[1]);
    const nextNum=Number(next?.label?.match(/\.(\d+)$/)?.[1]);
    // S can be misread as 5 or 8. Only 7->S->9 uniquely supports 8;
    // no sequence completion, no synthetic result, and no cross-family merge.
    if (prevNum !== 7 || nextNum !== 9 || candidate.page - previous.page > 3 || next.page - candidate.page > 3) continue;
    const label=`${candidate.appendixType} ${candidate.appendixPrefix}.8`;
    if (accepted.some(r=>normalizedStructureResultReference(r.label)===normalizedStructureResultReference(label))) continue;
    // Existing detections are already ordered by their physical reading
    // columns. Inserting the one corroborated observation BEFORE its printed
    // successor preserves that order; a global page-y sort would interleave
    // left/right columns and corrupt Results navigation on every spread.
    const resolved = {label,title:`${label}. ${candidate.titleTail.replace(/^[.:]\s*/, '')}`.slice(0,180),
      page:candidate.page,ratio:candidate.ratio,
      appendixOcrNumberResolved:true,appendixOriginalNumberText:candidate.rawText,
      key:`${candidate.page}:${normalizedReferenceLabel(label)}`,proofReferences:[],usedByProofs:[]};
    const successorIndex = accepted.indexOf(next);
    if (successorIndex >= 0) accepted.splice(successorIndex, 0, resolved);
    else accepted.push(resolved);
  }
  return accepted;
}

// Scanned/historical PDF text layers frequently concatenate the typography of
// an uppercase declaration with its number (THEOREM5.1, LEMMA3.5). Accept
// this shape only at the beginning of an observed visual line; preserve the
// ordinary detector's reference-tail and named-heading checks afterward.
// Avoid global whitespace insertion: inline theorem references and equations
// must retain their exact original text and geometry.
function structureResultExpandJoinedHeading(value) {
  return String(value || '').replace(
    /^(THEOREM|LEMMA|PROPOSITION|COROLLARY|DEFINITION|MAIN RESULT|REMARK|EXAMPLE|CLAIM|CONJECTURE|QUESTION|ASSUMPTION|HYPOTHESIS)(\d+(?:[.·-]\d+)*(?:['’])?)(?=[.:(\s\[]|$)/,
    '$1 $2'
  );
}

// A different native-PDF font/baseline can separate the printed result number
// from its declaration word by 2–4 PDF points. Recognize the split only when
// BOTH original native spans are visible, the uppercase type span ends where
// the independently printed numbered span begins, and they share one row.
// Never borrow a numerical label from a distant column or nearby prose.
function structureResultSplitBaselineLabel(lines, lineIndex, cleaned, page) {
  const heading = String(cleaned || '').match(/^(THEOREM|LEMMA|PROPOSITION|COROLLARY|DEFINITION|CLAIM|CONJECTURE|ASSUMPTION|HYPOTHESIS)(?=\s|$)/);
  const line = lines?.[lineIndex];
  const first = Array.isArray(line?.parts) ? line.parts[0] : null;
  const typeEnd = Number(first?.xEndRatio);
  const lineY = Number(line?.ratio);
  // A complete type-number label already follows the standard parser path.
  if (!heading || /^\s+\d/.test(cleaned.slice(heading[0].length)) || !first
      || !Number.isFinite(typeEnd) || !Number.isFinite(lineY)
      || Number(line?.xStartRatio) > 0.35
      || String(line.text || '').slice(Number(first.start || 0), Number(first.end || 0)).trim() !== heading[1]) return null;
  for (const offset of [-1, 1, -2, 2]) {
    const adjacent = lines?.[lineIndex + offset];
    if (!adjacent) continue;
    const number = String(adjacent.text || '').match(/^(\d{1,2}(?:[.·-]\d+){1,3})(?=[.):\s]|$)/);
    const firstNumber = Array.isArray(adjacent.parts) ? adjacent.parts[0] : null;
    const numericSpan = firstNumber
      ? String(adjacent.text).slice(Number(firstNumber.start || 0), Number(firstNumber.end || 0)).trim() : '';
    const start = Number(adjacent.xStartRatio), y = Number(adjacent.ratio);
    const spanWidth = Number(firstNumber?.xEndRatio) - Number(firstNumber?.xStartRatio);
    if (!number || !firstNumber || !numericSpan.startsWith(number[1])
        || !/^(?:[.):\s]|$)/.test(numericSpan.slice(number[1].length))
        || /^\d{1,2}(?:[.·-]\d+){1,3}\s*\(\s*(?:see|cf\.?|compare)\b/i.test(String(adjacent.text))
        || numericSpan.length > 25 || !Number.isFinite(spanWidth) || spanWidth > 0.19
        || !Number.isFinite(start) || !Number.isFinite(y)
        || Math.abs(y - lineY) > 0.006
        || start < typeEnd - 0.008 || start > typeEnd + 0.03) continue;
    const type = canonicalStructureResultType(heading[1]);
    return {label:`${type} ${number[1]}`,title:`${type} ${number[1]}. ${cleaned.slice(heading[1].length).trim()}`.slice(0,180),page,ratio:Math.min(y,lineY),declarationEvidence:'split-baseline'};
  }
  return null;
}

// Distinguish an unnumbered proof from a damaged explicit "Proof of X".
// The latter must remain unresolved, rather than borrowing a nearby theorem.
function resultProofHeading(text) {
  const value = String(text || '').trim();
  const match = value.match(/^Proof(?:\s+of\s+((?:Theorem|Lemma|Proposition|Corollary|Claim)\s+(?:(?:[A-Z]{1,2}[.·-])?\d+(?:[.·-]\d+)*|[A-Z]{1,2})))?\b[.:]?/i);
  if (!match) return null;
  return { printedReference: match[1] || '', explicitTarget: /^Proof\s+of\b/i.test(value) };
}

// A printed "Proof of Lemma 4.2" is an explicit link, not permission to
// attach the proof to whichever earlier theorem happens to be nearest.
// Unnumbered proofs may attach only to a nearby declaration, and where both
// visual column coordinates are available they must belong to the same column.
function resultProofTarget(entries, printedReference, page, proofLine) {
  const available = Array.isArray(entries) ? entries : [];
  const explicit = String(printedReference || '').trim();
  const proofPage = Number(page);
  if (!Number.isInteger(proofPage) || proofPage < 1) return null;
  const proofRatio = proofLine?.ratio == null ? NaN : Number(proofLine.ratio);
  const proofX = proofLine?.xStartRatio == null ? NaN : Number(proofLine.xStartRatio);
  const candidates = available.filter((entry) => Number.isInteger(Number(entry?.page))
    && Number(entry.page) >= 1 && Number(entry.page) <= proofPage
    && /^(?:theorem|lemma|proposition|corollary|claim)\b/i.test(String(entry.label || ''))
    // Do not select a declaration printed below the proof, regardless of
    // detector insertion order. Unknown geometry retains legacy fallback.
    && (Number(entry.page) !== proofPage || !Number.isFinite(proofRatio)
      || entry?.ratio == null || !Number.isFinite(Number(entry.ratio))
      || Number(entry.ratio) <= proofRatio + 0.003));
  // Detector data need not arrive in physical order (two-column text layers,
  // asynchronous OCR). Resolve the nearest preceding *document position*.
  const precedingFirst = (a, b) => Number(b.page) - Number(a.page)
    || (Number.isFinite(Number(b.ratio)) && b.ratio != null ? Number(b.ratio) : -1)
      - (Number.isFinite(Number(a.ratio)) && a.ratio != null ? Number(a.ratio) : -1);
  if (explicit) {
    const wanted = normalizedStructureResultReference(explicit);
    const matches = candidates.filter((entry) => normalizedStructureResultReference(entry.label) === wanted);
    // The printed target is authoritative. A missing target must not fall
    // through to a different nearby theorem or another result type.
    return matches.sort(precedingFirst)[0] || null;
  }
  const nearby = candidates.filter((entry) => proofPage - Number(entry.page) <= 1);
  if (!Number.isFinite(proofX) && !Number.isFinite(proofRatio)) return nearby[nearby.length - 1] || null;
  // Prioritize a geometrically verified same-column declaration. An earlier
  // right-column theorem must not steal a left-column unnumbered proof merely
  // because another candidate lacks x coordinates.
  const sameColumn = nearby.filter((entry) => {
    const x = entry?.declarationXStartRatio == null ? NaN : Number(entry.declarationXStartRatio);
    return !Number.isFinite(proofX) || !Number.isFinite(x)
      || Math.abs(proofX - x) <= 0.24;
  });
  const geoRank = (entry) => {
    const x = entry?.declarationXStartRatio == null ? NaN : Number(entry.declarationXStartRatio);
    return Number.isFinite(proofX) && Number.isFinite(x) ? 1 : 0;
  };
  return sameColumn.sort((a, b) => Number(b.page) - Number(a.page)
    || geoRank(b) - geoRank(a)
    || (b.ratio == null || !Number.isFinite(Number(b.ratio)) ? -1 : Number(b.ratio))
      - (a.ratio == null || !Number.isFinite(Number(a.ratio)) ? -1 : Number(a.ratio)))[0] || null;
}

function proofLineSameColumn(proofX, currentX) {
  if (proofX == null || currentX == null) return true;
  const anchor = Number(proofX), candidate = Number(currentX);
  return !Number.isFinite(anchor) || !Number.isFinite(candidate)
    || Math.abs(anchor - candidate) <= 0.24;
}

function detectedStructureResult(lines, lineIndex, page) {
  const line = lines?.[lineIndex];
  const cleaned = structureResultExpandJoinedHeading(normalizedStructureResultText(line?.text));
  if (!cleaned || structureResultLooksLikeNumberedSectionTitle(cleaned) || structureResultStartsNarrativeReference(cleaned)
    || structureResultWrappedProseReference(lines, lineIndex, cleaned)) return null;
  // Numbered Chinese mathematical declarations are not English references.
  // Require a visibly printed number, a statement delimiter and a statement
  // opener.  Do not infer unnumbered examples or promote citations such as
  // "定理4.1说明了..." into a Result.
  const chinese = cleaned.match(/^(定理|引理|命题|推论|定义|例)\s*(\d{1,3}(?:[.\u00b7-]\d{1,3}){0,3})\s*(?:(?:\(([^()]{2,60})\)|（([^（）]{2,60})）)\s*)?([.。:：])\s*(.{2,})$/u);
  if (chinese) {
    const name = String(chinese[3] || chinese[4] || '').trim();
    const statement = String(chinese[6] || '').trim();
    if (!name.match(/^(?:见|参见|同上|上文|前文|see|cf\.?)/i)
        && /^(?:设|令|若|如果|当|对|对于|任意|给定|假设|存在|有|则|称|我们称|每个|所有|以下|记|Let\b|Suppose\b|If\b|For\b)/u.test(statement)) {
      const label = `${chinese[1]} ${chinese[2].replace(/\u00b7/g, '.')}`;
      return { label, title: `${label}${name ? ` (${name})` : ''}. ${statement}`.slice(0, 180), page, ratio: line.ratio, declarationEvidence:'explicit-statement' };
    }
  }
  const appendix = detectedAppendixResult(line, page);
  if (appendix) return appendix;
  const splitBaseline = structureResultSplitBaselineLabel(lines, lineIndex, cleaned, page);
  if (splitBaseline) return splitBaseline;

  // Classical papers use both “Lemma 2.3” and “2.3. LEMMA”. Require the
  // declaration to start the visual line so body references cannot qualify.
  let match = cleaned.match(/^(\d+(?:(?:\.\d+)+|(?:-\d+)+))[.)]?\s+(Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\b[.:]?\s*(.*)$/i);
  if (match) {
    const type = canonicalStructureResultType(match[2]);
    const number = match[1];
    const tail = String(match[3] || '').trim();
    if (structureResultProseReferenceTail(tail) || structureResultUnpunctuatedReferenceTail(cleaned, tail)) return null;
    return {
      label: `${type} ${number}`,
      title: `${type} ${number}${tail ? `. ${tail}` : ''}`.slice(0, 180),
      page,
      ratio: line.ratio,
      declarationEvidence: 'number-first',
    };
  }

  // Type-first appendix declarations also suffer 1/l, 0/O confusion in old
  // PDF text layers. Restrict repairs to the actual number token of a labeled
  // Result; prose references are still guarded by the existing tail check.
  match=cleaned.match(/^(Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+([A-Z]{1,2})([.·\-])([0-9lIO]{1,3}(?:[.·\-][0-9lIO]{1,3})*)\b(?:[.:)]\s*|\s+|$)(.*)$/i);
  if(match) {
    if (match[2] !== match[2].toUpperCase()) return null;
    const type=canonicalStructureResultType(match[1]);
    const number=appendixResultNumberPrefix(match[2],match[3],match[4]);
    const tail=String(match[5]||'').trim();
    if(number && !structureResultProseReferenceTail(tail) && !structureResultUnpunctuatedReferenceTail(cleaned, tail)) return {
      label:`${type} ${number}`,title:`${type} ${number}${tail ? `. ${tail}` : ''}`.slice(0,180),page,ratio:line.ratio
    };
  }

  match = cleaned.match(/^(Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+([A-Z]?\d+(?:(?:\.\d+)+|(?:-\d+)+)?(?:['’])?|[A-Z])(?:(?=\()|[.:)]\s*|\s+|$)(.*)$/i);
  if (match) {
    const type = canonicalStructureResultType(match[1]);
    const number = match[2].replace('’', "'");
    if (structureResultHasTruncatedNumber(cleaned, number)) return null;
    // The declaration regex is case-insensitive for the result type, but a
    // single alphabetic label is case-sensitive notation.  Without this check
    // ordinary prose such as "the hypothesis y \in ..." is promoted to a
    // Result as "Hypothesis y".  Lowercase letter/prefixed labels are variable
    // references, not declaration labels; genuine old-style A / A1 labels remain.
    if (/^[A-Za-z]/.test(number) && number[0] !== number[0].toLocaleUpperCase()) return null;
    const tail = String(match[3] || '').trim();
    const named = tail.startsWith('(') ? structureResultParentheticalHeadingTail(tail) : null;
    // A genuine theorem may start with its first lettered assertion rather
    // than a prose preamble: "Theorem 2.12. (a) If ...". Require the explicit
    // dot after the FULL number, a first-item marker, and a substantive
    // capitalized statement lead. Never interpret "Theorem 2.12(a) shows..."
    // or "Theorem 2.12 (a) implies..." as a declaration.
    const firstSubpart = /^\((?:a|i)\)\s+(.{10,})$/u.exec(tail);
    const numberedHeadingLead = cleaned.match(/^(?:Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+[A-Z]?\d+(?:[.\u00b7-]\d+)*[.]\s+\((?:a|i)\)\s+/i);
    const explicitFirstSubpart = Boolean(firstSubpart && numberedHeadingLead
      && /^\p{Lu}/u.test(firstSubpart[1])
      && !structureResultProseReferenceTail(firstSubpart[1]));
    // Imperative tasks are genuine numbered Examples when their printed
    // number has a sentence delimiter.  A prose reference such as
    // "Example 191 proves ..." has no such delimiter and remains rejected.
    // This also preserves the common "Example 191. Prove ..." heading.
    const explicitExampleTask = type === 'Example'
      && /^Example\s+\d+(?:[.\u00b7-]\d+)*[.)]\s+(?:Prove|Show)\b/i.test(cleaned);
    if ((tail.startsWith('(') && !named && !explicitFirstSubpart)
      || (structureResultProseReferenceTail(tail) && !explicitExampleTask)
      || structureResultUnpunctuatedReferenceTail(cleaned, tail)) return null;
    return {
      label: `${type} ${number}`,
      title: `${type} ${number}${tail ? `. ${tail}` : ''}`.slice(0, 180),
      page,
      ratio: line.ratio,
      ...(named ? {declarationEvidence:'named'} :
        // An explicit type/number delimiter followed by a statement-start
        // is independent printed evidence; lecture/chapter numbering can
        // legitimately restart, including repeated "Definition 1" labels.
        /^(?:Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+[A-Z]?\d+(?:[.·-]\d+)*[.:]\s*/i.test(cleaned)
        && (/^(?:A|An|Any|All|Each|Every|Let|Given|Suppose|If|For|There|The)\b/i.test(tail)
          || /^(?:A|An|If|For|Let|The|Given|There|Suppose|When|Whenever|Assume)[a-z]/.test(tail)
          || /^(?:Suppose|If|Let|Given|Assume)(?=[A-Z0-9\[({])/.test(tail))
          ? {declarationEvidence:'explicit-statement'} : {}),
    };
  }

  match = cleaned.match(/^(Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s*\([^()]{2,80}\)\s*[.:]?$/i);
  if (match) {
    // Old books often wrap a section heading across two visual lines, e.g.
    // “10-4 PROOF OF THE UNIFORMIZATION” / “THEOREM (PART I)”.  The
    // second line looks exactly like an unnumbered result unless the nearby
    // heading prefix is considered.  Reject only this explicit “proof of …”
    // continuation class; genuine standalone parenthetical result headings
    // remain eligible.
    const previous = lines?.[lineIndex - 1];
    const previousText = normalizedStructureResultText(previous?.text);
    const previousDistance = previous ? Math.abs((Number(previous.ratio) || 0) - (Number(line.ratio) || 0)) : Infinity;
    // A nearby PROOF OF heading in the opposite column is unrelated.
    const precedingStart = Number(previous?.xStartRatio);
    const headingStart = Number(line?.xStartRatio);
    const sameColumn = !Number.isFinite(precedingStart) || !Number.isFinite(headingStart)
      || !((precedingStart < 0.49 && headingStart > 0.51)
        || (precedingStart > 0.51 && headingStart < 0.49));
    const splitProofHeading = previousDistance <= 0.075 && sameColumn
      && /^(?:\d+(?:(?:\.\d+)+|(?:-\d+)+)\s+)?(?:A\s+)?PROOF\s+OF\s+(?:THE\s+)?/i.test(previousText);
    if (splitProofHeading) return null;
    const title = cleaned.replace(/[.:]+$/, '').trim();
    return { label: title.slice(0, 100), title: cleaned.slice(0, 180), page, ratio: line.ratio };
  }

  // A number is not mandatory for a genuine declaration. Classical papers
  // commonly use forms such as “Definition. A complete ...” or “Lemma. Let ...”.
  // Restrict this to strong result types so prose-style “Remark. ...” lines do
  // not become document-wide Results noise.
  match = cleaned.match(/^(Theorem|Lemma|Proposition|Corollary|Definition|Claim|Conjecture)\.\s+(.{2,})$/i);
  if (match && cleaned[0] === cleaned[0].toLocaleUpperCase()) {
    const type = canonicalStructureResultType(match[1]);
    return {
      label: `${type} · p.${page}`,
      displayLabel: type,
      title: cleaned.slice(0, 180),
      page,
      ratio: line.ratio,
      unnumberedResult: true,
    };
  }

  match = cleaned.match(/^(Theorem|Lemma|Proposition|Corollary|Definition|Main Result|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\.?$/i);
  if (!match || cleaned[0] !== cleaned[0].toLocaleUpperCase()) return null;
  const type = canonicalStructureResultType(match[1]);

  // Fragmented native layers can put "THEOREM" and "1.3. Let ..." into
  // separate, slightly out-of-order fragments on the *same baseline*. Require
  // the number AND statement text, tight y alignment and immediate horizontal
  // continuity. This does not promote lone folios, references, or distant
  // second-column text, and leaves the existing vertical split rule intact.
  const typeEnd = Number(line?.xEndRatio);
  const typeStart = Number(line?.xStartRatio);
  const typeRatio = Number(line?.ratio);
  if (Number.isFinite(typeEnd) && Number.isFinite(typeStart) && Number.isFinite(typeRatio)) {
    const sameRowNumber = (lines || []).filter((adjacent, index) => {
      if (index === lineIndex) return false;
      const start = Number(adjacent?.xStartRatio);
      const ratio = Number(adjacent?.ratio);
      if (!Number.isFinite(start) || !Number.isFinite(ratio)
        || Math.abs(ratio - typeRatio) > 0.006
        || start < typeStart + 0.035
        || start < typeEnd - 0.05
        || start > typeEnd + 0.12) return false;
      const numbered = normalizedStructureResultText(adjacent?.text).match(/^(\d+(?:\.\d+)*)(?:[.)])?\s+(.{5,})$/);
      return Boolean(numbered && !structureResultProseReferenceTail(numbered[2]));
    }).sort((a, b) => Math.abs(Number(a.xStartRatio) - typeEnd) - Math.abs(Number(b.xStartRatio) - typeEnd))[0];
    if (sameRowNumber) {
      const numbered = normalizedStructureResultText(sameRowNumber.text).match(/^(\d+(?:\.\d+)*)(?:[.)])?\s+(.{5,})$/);
      return {
        label: `${type} ${numbered[1]}`,
        title: `${type} ${numbered[1]}. ${numbered[2]}`.slice(0, 180),
        page,
        ratio: Math.min(typeRatio, Number(sameRowNumber.ratio)),
      };
    }
  }

  // Some old layouts put the result type and its number on adjacent visual
  // lines. Accept only a nearby number-leading line, never an arbitrary page
  // number or remote prose line.
  for (const offset of [1, -1]) {
    const adjacent = lines?.[lineIndex + offset];
    if (!adjacent) continue;
    const adjacentText = normalizedStructureResultText(adjacent.text);
    const numbered = adjacentText.match(/^(\d+(?:\.\d+)*)(?:[.)])?\s*(.*)$/);
    if (!numbered) continue;
    const number = numbered[1];
    const tail = String(numbered[2] || '').trim();
    const ratioDistance = Math.abs((Number(adjacent.ratio) || 0) - (Number(line.ratio) || 0));
    if (ratioDistance > 0.07) continue;
    // A bare integer adjacent to a heading is accepted only when there is
    // statement text on that same line. This excludes isolated running page
    // numbers while retaining Yau-style “THEOREM” / “2. Let ...”.
    if (!number.includes('.') && !tail) continue;
    if (tail && structureResultProseReferenceTail(tail)) continue;
    return {
      label: `${type} ${number}`,
      title: `${type} ${number}${tail ? `. ${tail}` : ''}`.slice(0, 180),
      page,
      ratio: Math.min(Number(line.ratio) || 0, Number(adjacent.ratio) || Number(line.ratio) || 0),
    };
  }

  // Keep genuinely unnumbered strong mathematical result headings. Loose
  // labels such as “Remark.” or “Example.” are too common in prose to index
  // safely without a number.
  if (!STRUCTURE_STRONG_UNNUMBERED_TYPES.has(String(match[1] || '').toLocaleLowerCase())) return null;
  return {
    label: `${type} · p.${page}`,
    displayLabel: type,
    title: type,
    page,
    ratio: line.ratio,
    unnumberedResult: true,
  };
}

function normalizeEquationTagCommands(value) {
  const commandMap = new Map([
    ['dagger', '†'], ['Dagger', '†'], ['ddagger', '‡'], ['Ddagger', '‡'],
    ['ast', '*'], ['star', '⋆'], ['bigstar', '★'], ['circ', '○'], ['bullet', '•'],
    ['triangle', '△'], ['blacktriangle', '▲'], ['triangledown', '▽'], ['blacktriangledown', '▼'],
    ['square', '□'], ['blacksquare', '■'], ['diamond', '◇'], ['blackdiamond', '◆'],
    ['odot', '⊙'], ['otimes', '⊗'], ['oplus', '⊕'], ['ominus', '⊖'], ['perp', '⊥'], ['parallel', '∥'],
  ]);
  return String(value || '').replace(/\\([A-Za-z]+)\b/g, (match, name) => commandMap.get(name) || match);
}

function normalizedEquationLabel(value) {
  let inner = normalizeEquationTagCommands(String(value || '').normalize('NFKC').trim());
  inner = inner.replace(/^\(\s*|\s*\)$/g, '').replace(/\s+/g, '');
  return `(${inner})`;
}

function isSymbolicEquationTagInner(inner) {
  const compact = String(inner || '').replace(/\s+/g, '');
  if (!compact || Array.from(compact).length > 8) return false;
  return Array.from(compact).every((char) => EQUATION_TAG_SYMBOL_CLASS.includes(char));
}

function isLikelyCalendarYearEquationLabel(value) {
  const label = normalizedEquationLabel(value);
  const inner = label.slice(1, -1);
  if (/^\d{4}$/.test(inner)) {
    const year = Number(inner);
    return year >= 1800 && year <= 2099;
  }
  const range = inner.match(/^(\d{4})-(\d{4})$/);
  if (!range) return false;
  const start = Number(range[1]);
  const end = Number(range[2]);
  return start >= 1000 && start <= 2199 && end >= 1000 && end <= 2199;
}


function equationOcrPageConfidence(pageNum) {
  if (typeof documentOcrPages === 'undefined' || !(documentOcrPages instanceof Map)) return null;
  const record = documentOcrPages.get(Number(pageNum));
  if (!record) return null;
  const wordValues = (Array.isArray(record.words) ? record.words : [])
    .map((word) => Number(word?.confidence))
    .filter(Number.isFinite);
  if (wordValues.length) return wordValues.reduce((sum, value) => sum + value, 0) / wordValues.length;
  let weightedSum = 0;
  let weightedCount = 0;
  for (const line of Array.isArray(record.lines) ? record.lines : []) {
    const confidence = Number(line?.confidence);
    if (!Number.isFinite(confidence)) continue;
    const weight = Math.max(1, Array.isArray(line?.parts) ? line.parts.length : 1);
    weightedSum += confidence * weight;
    weightedCount += weight;
  }
  return weightedCount ? weightedSum / weightedCount : null;
}

function compactNumericEquationTagInner(raw) {
  const value = String(raw || '').trim();
  if (/\d\s+\d/.test(value)) return '';
  return value.replace(/\s+/g, '');
}

function isPlausibleNumericEquationTagInner(inner) {
  const value = String(inner || '');
  if (/^\d+$/.test(value)) return /^(?:0|[1-9]\d{0,3})$/.test(value);
  // Aligned displays can number subexpressions (1a), (1.2a), (2.4b).
  // A single trailing lowercase letter is a suffix, never a new chapter.
  return /^(?:\d+(?:(?:\.\d+)+|(?:-\d+)+)[a-z]?|[1-9]\d{0,3}[a-z])$/.test(value);
}

// Numbered appendix displays have their own families (A.1, B-2, A1,
// AA.3, A.1.2). Keep the alphabetic prefix: it is part of the equation's
// identity, not an alternative spelling of the main-text integer label.
// Do not admit bare alphabetic tags like (A), which collide with formula
// symbols, multiple-choice lists and citations.
function isPlausibleAppendixEquationTagInner(inner) {
  const value = String(inner || '');
  // Dotted lower-case appendix numbering remains possible, but bare/compact
  // lower-case tokens such as (n-1), (j-2), (k1) are overwhelmingly formula
  // variables, not appendix labels. Preserve uppercase A-1, A1, AA.3 etc.
  return /^(?:[A-Z]{1,2}(?:(?:\.\d{1,4}){1,3}|(?:-\d{1,4}){1,3}|\d{1,4})(?:[a-z])?|[a-z]{1,2}(?:\.\d{1,4}){1,3}(?:[a-z])?|[IVXLCDM]{3,8}(?:\.\d{1,4}){1,3}(?:[a-z])?)$/.test(value);
}

function isPlausibleEquationTagInner(inner) {
  return isPlausibleNumericEquationTagInner(inner)
    || isPlausibleAppendixEquationTagInner(inner);
}

function isEquationLabelQuery(value) {
  const label = normalizedEquationLabel(value);
  const inner = label.slice(1, -1);
  if (isLikelyCalendarYearEquationLabel(label)) return false;
  return isPlausibleEquationTagInner(inner) || isSymbolicEquationTagInner(inner);
}

function parsedSequentialLabel(value) {
  const normalized = normalizedReferenceLabel(value);
  const match = normalized.match(/^(theorem|lemma|proposition|corollary|definition|remark|example|claim|conjecture|question|assumption|hypothesis)\s+([a-z]?)(\d+(?:\.\d+)*)$/i);
  if (!match) return null;
  return {
    type: match[1].toLocaleLowerCase(),
    prefix: match[2].toLocaleLowerCase(),
    parts: match[3].split('.').map((part) => Number(part)),
  };
}

function compareNumberParts(a, b) {
  const left = Array.isArray(a) ? a : [];
  const right = Array.isArray(b) ? b : [];
  const length = Math.max(left.length, right.length);
  for (let i = 0; i < length; i += 1) {
    const av = Number.isFinite(left[i]) ? left[i] : -1;
    const bv = Number.isFinite(right[i]) ? right[i] : -1;
    if (av !== bv) return av < bv ? -1 : 1;
  }
  return 0;
}

function normalizeSequentialStructureEntries(entries) {
  const observed = Array.isArray(entries) ? entries : [];
  const strength = (item) => (item?.declarationEvidence === 'number-first' || item?.declarationEvidence === 'split-baseline') ? 3
    : (item?.declarationEvidence === 'named' || item?.declarationEvidence === 'explicit-statement') ? 2 : 1;
  const byLabel = new Map();
  for (const entry of observed) {
    const key = normalizedReferenceLabel(entry?.label);
    if (!key) continue;
    if (!byLabel.has(key)) byLabel.set(key, []);
    byLabel.get(key).push(entry);
  }
  // For a shared label, use the strongest actual printed evidence. Separate
  // strongly marked declarations are allowed to restart numbering in new
  // chapters/lectures. Mere narrative mentions NEVER create duplicate entries.
  const chosen = new Set();
  for (const occurrences of byLabel.values()) {
    const max = occurrences.reduce((current, entry) => Math.max(current, strength(entry)), 0);
    const good = occurrences.filter(entry => strength(entry) === max);
    const byPage = new Map();
    for (const entry of good) {
      // A detector can return same-page observations in an arbitrary OCR order.
      // Keep the earliest *measured* declaration rather than the first emitted
      // candidate; missing geometry must never outrank a measured position.
      const prior = byPage.get(entry.page);
      const valid = (row) => row && Number.isFinite(row.ratio) && row.ratio >= 0 && row.ratio <= 1;
      if (!prior || (valid(entry) && (!valid(prior) || entry.ratio < prior.ratio))) byPage.set(entry.page, entry);
    }
    if (max > 1) for (const entry of byPage.values()) chosen.add(entry);
    else chosen.add(good[0]);
  }
  // OCR text layers can emit right-column declarations before left-column ones.
  // Evaluate weak monotonicity in printed order rather than arrival order.
  const validRatio = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1;
  const ordered = observed.map((entry, index) => ({ entry, index })).filter(({entry}) => chosen.has(entry));
  // A two-column PDF reads top-to-bottom within each column, not in
  // alternating vertical Y order. Require multiple located declarations in
  // both columns before applying the left-first profile; isolated x offsets
  // in an ordinary single-column paper must not change reading order.
  const byPage = new Map();
  for (const item of ordered) {
    const page = Number(item.entry.page);
    if (!byPage.has(page)) byPage.set(page, []);
    byPage.get(page).push(item.entry);
  }
  const twoColumnPages = new Set();
  for (const [page, rows] of byPage) {
    const validX = rows.map((row) => row.declarationXStartRatio).filter((x) => typeof x === 'number' && Number.isFinite(x) && x >= 0 && x <= 1);
    if (validX.filter((x) => x < 0.44).length >= 2 && validX.filter((x) => x > 0.50).length >= 2) twoColumnPages.add(page);
  }
  const column = (entry) => twoColumnPages.has(Number(entry.page))
    && typeof entry.declarationXStartRatio === 'number' && Number.isFinite(entry.declarationXStartRatio)
    ? (entry.declarationXStartRatio > 0.50 ? 1 : 0) : 0;
  ordered.sort((a, b) => Number(a.entry.page) - Number(b.entry.page)
    || column(a.entry) - column(b.entry)
    || (validRatio(a.entry.ratio) ? a.entry.ratio : 2) - (validRatio(b.entry.ratio) ? b.entry.ratio : 2)
    || a.index - b.index);
  const accepted = [];
  const lastNumericByType = new Map();
  for (const { entry } of ordered) {
    const parsed = parsedSequentialLabel(entry?.label);
    if (parsed && !parsed.prefix) {
      const lastNumeric = lastNumericByType.get(parsed.type) || null;
      if (lastNumeric && compareNumberParts(parsed.parts, lastNumeric.parts) < 0
        && strength(entry) === 1) continue;
      lastNumericByType.set(parsed.type, parsed);
    }
    accepted.push(entry);
  }
  return accepted;
}

function parsedEquationNumber(label) {
  const inner = normalizedEquationLabel(label).slice(1, -1);
  if (isPlausibleNumericEquationTagInner(inner)) {
    const suffix = (inner.match(/[a-z]$/) || [''])[0];
    const body = suffix ? inner.slice(0, -1) : inner;
    const separator = body.includes('-') ? '-' : '.';
    const parts = body.split(separator).map((part) => Number(part));
    return { parts, prefix: parts.slice(0, -1).join(separator), last: parts[parts.length - 1], separator, suffix, appendix: false };
  }
  if (!isPlausibleAppendixEquationTagInner(inner)) return null;
  const match = inner.match(/^([A-Za-z]{1,2}|[IVXLCDM]{3,8})([.\-]?)(\d+(?:[.\-]\d+)*)([a-z]?)$/);
  if (!match) return null;
  const [, letter, separator, digits, suffix] = match;
  const parts = separator ? digits.split(separator).map(Number) : [Number(digits)];
  if (!parts.length || parts.some((part) => !Number.isInteger(part))) return null;
  return {
    parts, prefix: letter + (parts.length > 1 ? separator + parts.slice(0, -1).join(separator) : ''),
    last: parts[parts.length - 1], separator, suffix, appendix: true,
  };
}

// OCR often drops the separator in appendix labels (B.3 -> B3). These are
// distinct printed formats: mixed styles must not corroborate one another as
// a dense sequential family or license an inferred missing-label OCR query.
function equationSequenceFamilyKey(parsed) {
  if (!parsed?.prefix) return 'integer';
  return `prefix:${parsed.prefix}:separator:${parsed.separator || 'compact'}`;
}

function equationDocumentPosition(item) {
  return Number(item?.page || 0) * 10 + (Number(item?.ratio) || 0);
}


function equationLineFragmentForColumns(line, parts, columnIndex, columnStartRatio, columnEndRatio) {
  if (!Array.isArray(parts) || !parts.length) return null;
  const ordered = [...parts].sort((a, b) => Number(a.start || 0) - Number(b.start || 0));
  const source = String(line?.text || '');
  let start = Infinity, end = -Infinity;
  let minX = Infinity, maxX = -Infinity;
  for (const part of ordered) {
    const partStart = Number(part.start || 0), partEnd = Number(part.end || 0);
    const xStart = Number(part.xStartRatio || 0), xEnd = Number(part.xEndRatio || 0);
    if (!Number.isFinite(partStart) || !Number.isFinite(partEnd) || partStart < 0 || partEnd < partStart
        || !Number.isFinite(xStart) || !Number.isFinite(xEnd) || xStart < 0 || xEnd > 1 || xEnd < xStart) return null;
    start = Math.min(start, partStart);
    end = Math.max(end, partEnd);
    minX = Math.min(minX, xStart);
    maxX = Math.max(maxX, xEnd);
  }
  if (start >= source.length || end > source.length) return null;
  const raw = source.slice(start, end).replace(/\s+/g, ' ').trim();
  if (!raw) return null;
  const leading = source.slice(start, end).search(/\S/);
  const adjustedStart = start + Math.max(0, leading);
  const fragmentParts = ordered.map((part) => ({
    ...part,
    start: Math.max(0, Number(part.start || 0) - adjustedStart),
    end: Math.max(0, Number(part.end || 0) - adjustedStart),
  }));
  return {
    ...line,
    text: raw,
    parts: fragmentParts,
    xStartRatio: minX,
    xEndRatio: maxX,
    equationTwoColumn: true,
    equationColumnIndex: columnIndex,
    equationColumnStartRatio: columnStartRatio,
    equationColumnEndRatio: columnEndRatio,
  };
}

function equationColumnAwareSupplementLines(rawLines) {
  const lines = Array.isArray(rawLines) ? rawLines : [];
  if (!lines.length) return lines;
  const evidence = [];
  for (const line of lines) {
    const parts = Array.isArray(line.parts) ? [...line.parts].sort((a, b) => Number(a.xStartRatio || 0) - Number(b.xStartRatio || 0)) : [];
    let best = null;
    for (let index = 0; index + 1 < parts.length; index += 1) {
      const leftEnd = Number(parts[index].xEndRatio || 0);
      const rightStart = Number(parts[index + 1].xStartRatio || 0);
      const gap = rightStart - leftEnd;
      if (leftEnd < 0.38 || leftEnd > 0.58 || rightStart < 0.42 || rightStart > 0.64 || gap < 0.025) continue;
      const midpointDistance = Math.abs(((leftEnd + rightStart) / 2) - 0.5);
      if (midpointDistance > 0.09) continue;
      if (!best || midpointDistance < best.midpointDistance - 0.005
          || (Math.abs(midpointDistance - best.midpointDistance) <= 0.005 && gap > best.gap)) {
        best = { index, gap, midpointDistance };
      }
    }
    if (!best) continue;
    const lp = parts.slice(0, best.index + 1);
    const rp = parts.slice(best.index + 1);
    const bounds = (items) => {
      let start = Infinity, end = -Infinity;
      for (const part of items) {
        start = Math.min(start, Number(part.xStartRatio || 0));
        end = Math.max(end, Number(part.xEndRatio || 0));
      }
      return [start, end];
    };
    const [leftStart, leftEnd] = bounds(lp);
    const [rightStart, rightEnd] = bounds(rp);
    if (leftStart <= 0.20 && leftEnd >= 0.28 && rightStart >= 0.44 && rightEnd >= 0.70) {
      evidence.push({ leftStart, leftEnd, rightStart, rightEnd });
    }
  }
  // This is a supplement to the mature single-page detector, not a replacement.
  // Require repeated page-level evidence before treating an inner gutter as a
  // real column boundary; isolated formula/table gaps remain on the old path.
  const median = (values) => {
    const a = values.filter(Number.isFinite).sort((x, y) => x - y);
    return a.length ? a[Math.floor(a.length / 2)] : NaN;
  };

  // OCR engines often return a two-column raster page as already-separated
  // line records, so there is no merged same-y row from which to measure the
  // gutter.  Keep this fallback OCR-only: native PDF text continues to require
  // the stronger merged-row evidence above.  Repeated long prose anchors in
  // both outer columns establish the page profile; short formula/table rows
  // cannot do so by themselves.
  if (evidence.length < 4) {
    if (!lines.some((line) => Boolean(line?.ocrSource))) return lines;
    const prose = lines.filter((line) => String(line?.text || '').replace(/\s+/g, ' ').trim().length >= 28);
    const leftAnchors = prose.filter((line) => Number(line?.xStartRatio ?? 1) <= 0.22
      && Number(line?.xEndRatio ?? 1) >= 0.26
      && Number(line?.xEndRatio ?? 1) <= 0.53);
    const rightAnchors = prose.filter((line) => Number(line?.xStartRatio ?? 0) >= 0.47
      && Number(line?.xStartRatio ?? 0) <= 0.70
      && Number(line?.xEndRatio ?? 0) >= 0.70);
    if (leftAnchors.length < 4 || rightAnchors.length < 4) return lines;
    const separatedLeftStart = median(leftAnchors.map((line) => Number(line.xStartRatio)));
    const separatedLeftEnd = median(leftAnchors.map((line) => Number(line.xEndRatio)));
    const separatedRightStart = median(rightAnchors.map((line) => Number(line.xStartRatio)));
    const separatedRightEnd = median(rightAnchors.map((line) => Number(line.xEndRatio)));
    if (![separatedLeftStart, separatedLeftEnd, separatedRightStart, separatedRightEnd].every(Number.isFinite)) return lines;
    if (separatedRightStart - separatedLeftStart < 0.28 || separatedRightStart < 0.47 || separatedRightStart > 0.66) return lines;
    const boundary = Math.max(0.465, Math.min(0.515, separatedRightStart - 0.025));
    const profileLeftEnd = Math.max(boundary - 0.012, separatedLeftEnd);
    const profileRightEnd = Math.max(0.72, separatedRightEnd);
    return lines.map((line) => {
      const start = Number(line?.xStartRatio ?? NaN);
      const end = Number(line?.xEndRatio ?? NaN);
      if (!Number.isFinite(start) || !Number.isFinite(end)) return line;
      if (end <= boundary + 0.012) {
        return { ...line, equationTwoColumn: true, equationColumnIndex: 0, equationColumnStartRatio: separatedLeftStart, equationColumnEndRatio: profileLeftEnd };
      }
      if (start >= boundary - 0.012) {
        return { ...line, equationTwoColumn: true, equationColumnIndex: 1, equationColumnStartRatio: separatedRightStart, equationColumnEndRatio: profileRightEnd };
      }
      return line;
    });
  }

  const leftStart = median(evidence.map((e) => e.leftStart));
  const leftEnd = median(evidence.map((e) => e.leftEnd));
  const rightStart = median(evidence.map((e) => e.rightStart));
  const rightEnd = median(evidence.map((e) => e.rightEnd));
  if (![leftStart, leftEnd, rightStart, rightEnd].every(Number.isFinite)) return lines;
  if (!(leftStart < leftEnd && leftEnd < rightStart && rightStart < rightEnd)) return lines;

  const out = [];
  for (const line of lines) {
    const parts = Array.isArray(line.parts) ? [...line.parts].sort((a, b) => Number(a.xStartRatio || 0) - Number(b.xStartRatio || 0)) : [];
    let best = null;

    // Once the page-level column profile is established, prefer that stable
    // right-column start over the instantaneous whitespace of a short formula.
    // In left-numbered two-column/2-up pages the first object in the right
    // column can itself be the equation tag, so the largest gap on that row may
    // occur *after* the tag and would otherwise attach it to the left column.
    const profileThreshold = rightStart - 0.025;
    const profileIndex = parts.findIndex((part, index) => index > 0 && Number(part.xStartRatio || 0) >= profileThreshold);
    if (profileIndex > 0) {
      const a = Number(parts[profileIndex - 1].xEndRatio || 0);
      const b = Number(parts[profileIndex].xStartRatio || 0);
      if (Number.isFinite(a) && Number.isFinite(b) && b > a + 0.02) {
        best = { index: profileIndex - 1, gap: b - a, midpointDistance: Math.abs(((a + b) / 2) - 0.5) };
      }
    }

    if (!best) {
      for (let index = 0; index + 1 < parts.length; index += 1) {
        const a = Number(parts[index].xEndRatio || 0);
        const b = Number(parts[index + 1].xStartRatio || 0);
        const gap = b - a;
        if (a < 0.38 || a > 0.58 || b < 0.42 || b > 0.64 || gap < 0.035) continue;
        const midpointDistance = Math.abs(((a + b) / 2) - 0.5);
        if (midpointDistance > 0.09) continue;
        if (!best || midpointDistance < best.midpointDistance - 0.005
            || (Math.abs(midpointDistance - best.midpointDistance) <= 0.005 && gap > best.gap)) {
          best = { index, gap, midpointDistance };
        }
      }
    }
    if (!best) { out.push(line); continue; }
    const left = equationLineFragmentForColumns(line, parts.slice(0, best.index + 1), 0, leftStart, leftEnd);
    const right = equationLineFragmentForColumns(line, parts.slice(best.index + 1), 1, rightStart, rightEnd);
    if (left && right) out.push(left, right); else out.push(line);
  }
  // A printed tag can occupy only the gutter at the end of a left-column
  // display. Its own PDF.js text run may have no words beside it, and a
  // same-y right-column fragment may cause the splitter to assign the tag to
  // the *right* column. Reclassify only isolated tags located wholly before
  // the actual right-column text start. Do not use the median left text end:
  // equations can protrude farther into the gutter than ordinary prose.
  const localRightEdge = rightStart - 0.025;
  return out.map((line) => {
    const start = Number(line.xStartRatio);
    const end = Number(line.xEndRatio);
    if (!(start >= 0.37 && start < localRightEdge && end <= localRightEdge + 0.010
        && end >= rightStart - 0.16)) return line;
    const candidates = equationLabelCandidatesInLine(line.text);
    if (candidates.length !== 1 || !isStandaloneEquationTagLine(line, candidates[0].label)) return line;
    return { ...line, equationTwoColumn: true, equationColumnIndex: 0,
      equationColumnStartRatio: leftStart,
      equationColumnEndRatio: Math.max(leftEnd, end + 0.004) };
  });
}

function equationCandidateAlignedToLocalColumnSide(item, side = equationNumberingSide, columnOverride = null) {
  if (!item?.equationTwoColumn) return false;
  const targetColumn = Number.isInteger(columnOverride) ? columnOverride : (side === 'left' ? 1 : 0);
  if (item.equationColumnIndex !== targetColumn) return false;
  const start = Number(item?.candidateXStartRatio);
  const end = Number(item?.candidateXEndRatio);
  const columnStart = Number(item?.equationColumnStartRatio);
  const columnEnd = Number(item?.equationColumnEndRatio);
  if (![start, end, columnStart, columnEnd].every(Number.isFinite) || columnEnd <= columnStart) return false;
  const width = columnEnd - columnStart;
  const tolerance = Math.min(0.10, Math.max(0.055, width * 0.25));
  if (side === 'left') return end <= columnStart + tolerance || start <= columnStart + tolerance * 0.65;
  return start >= columnEnd - tolerance || end >= columnEnd - tolerance * 0.65;
}

function twoColumnEquationSupplementCandidates(lines, page, side = equationNumberingSide, columnOverride = null) {
  const pageOcrConfidence = equationOcrPageConfidence(page);
  const out = [];
  const targetColumn = Number.isInteger(columnOverride) ? columnOverride : (side === 'left' ? 1 : 0);
  const referenceProse = /\b(?:equation|eq\.?|see|from|by|using|satisfies|implies|according\s+to|as\s+in|in\s+view\s+of|contradicts?|rewrit(?:e|ten)|follows?\s+from|inequality\s+(?:like|in)|as\s+required|cf\.?|recall|apply(?:ing)?|combin(?:e|ing)|substitut(?:e|ing)|insert|notice)\b/i;
  for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
    const line = lines[lineIndex];
    if (!line?.equationTwoColumn || line.equationColumnIndex !== targetColumn) continue;
    const candidates = equationLabelCandidatesInLine(line.text);
    for (const candidate of candidates) {
      const parsed = parsedEquationNumber(candidate.label);
      if (!parsed || isLikelyCalendarYearEquationLabel(candidate.label)) continue;
      const tokenGeometry = equationCandidateTokenGeometry(line, candidate);
      const record = {
        label: candidate.label,
        page,
        ratio: line.ratio,
        text: line.text,
        xStartRatio: line.xStartRatio,
        xEndRatio: line.xEndRatio,
        candidateXStartRatio: tokenGeometry.xStartRatio,
        candidateXEndRatio: tokenGeometry.xEndRatio,
        numeric: parsed,
        bareSource: Boolean(candidate.bare),
        explicitParenthesized: !candidate.bare,
        candidateAtLineStart: !String(line.text || '').slice(0, Math.max(0, Number(candidate.index) || 0)).trim(),
        candidateAtLineEnd: !String(line.text || '').slice(Math.max(0, Number(candidate.end) || 0)).trim(),
        standaloneTag: isStandaloneEquationTagLine(line, candidate.label),
        nearbyDisplayMath: hasNearbyDisplayMath(lines, lineIndex),
        mathSignals: equationLineMathSignalCount(line.text),
        ocrSource: Boolean(line.ocrSource),
        ocrLineConfidence: Number.isFinite(line.confidence) ? Number(line.confidence) : null,
        ocrPageConfidence: Number.isFinite(pageOcrConfidence) ? Number(pageOcrConfidence) : null,
        attachedFunctionCall: Boolean(candidate.attachedFunctionCall),
        enumeratedConditionList: equationEnumeratedConditionListContext(lines, lineIndex, candidate),
        equationTwoColumn: true,
        equationColumnIndex: targetColumn,
        equationColumnStartRatio: line.equationColumnStartRatio,
        equationColumnEndRatio: line.equationColumnEndRatio,
      };
      const tagAtLocalMargin = side === 'left' ? record.candidateAtLineStart : record.candidateAtLineEnd;
      if (record.attachedFunctionCall) continue;
      if (record.bareSource && (bareEquationInTabularRow(lines, lineIndex) || bareEquationHasMeasurementSuffix(line, candidate))) continue;
      if (!tagAtLocalMargin || !equationCandidateAlignedToLocalColumnSide(record, side, targetColumn)) continue;
      if (referenceProse.test(String(record.text || ''))) continue;
      if (record.bareSource) {
        const extremeTopBareMarker = record.standaloneTag
          && (Number(record.ratio) <= 0.040
            || (!record.nearbyDisplayMath && Number(record.ratio) <= 0.070 && bareEquationHasNearbyHeadingContext(lines, lineIndex)));
        if (extremeTopBareMarker) continue;
        const remainder = String(record.text || '').replace(/^\s*\d+(?:\.\d+)+\s*/, '').trim();
        const words = remainder.match(/\b[A-Za-z]{3,}\b/g) || [];
        const han = remainder.match(/\p{Script=Han}/gu) || [];
        const structuredProse = /^(?:\([ivxlcdm]+\)\s*)?(?:theorem|lemma|proposition|corollary|definition|remark|example|claim|exercise|problem|suppose|let|if|give|prove|show|using|chapter|section)\b/i.test(remainder)
          || words.length >= 3 || han.length >= 4;
        if (structuredProse) continue;
      }
      // A short, one-line display can have just one extracted operator (for
      // example "y ~ M(...). (1)") and no neighboring math line. Its explicit
      // tag still belongs to the *local* column margin, not the physical PDF
      // edge. Require a visible operator, few prose words, and an end tag;
      // do not relax the general margin or inline-reference classifier.
      const mathematicalFunctionWords = /^(?:det|tr|rank|lim|sup|inf|log|exp|sin|cos|max|min|grad|div|arg)$/i;
      const proseWords = (String(record.text || '').match(/[A-Za-z]{3,}/g) || [])
        .filter((word) => !mathematicalFunctionWords.test(word));
      const shortLocalDisplay = !record.bareSource && record.candidateAtLineEnd
        && record.mathSignals >= 1
        && /[=±×∼≈<>≤≥∈∉∑∫√^_~|]/u.test(String(record.text || ''))
        && proseWords.length <= 1;
      if (!record.standaloneTag && !record.nearbyDisplayMath && record.mathSignals < 2 && !shortLocalDisplay) continue;
      if ((String(record.text || '').match(/[A-Za-z]{3,}/g) || []).length >= 8 && record.mathSignals < 2) continue;
      record.shortLocalDisplay = shortLocalDisplay;
      record.confidence = Math.max(12, equationTargetScore(record.text, record.label, null, 0, null, Number(record.ratio)) + 7);
      out.push(record);
    }
  }
  return out;
}

function supplementTwoColumnEquations(index, rawPageLines) {
  // Two-column and 2-up mathematical pages can place equation numbers on the
  // local margin of each column/page. The mature detector already sees the
  // physical outer margin. Recover only the corresponding inner local margin:
  // right-numbered documents -> right edge of the left column; left-numbered
  // documents -> left edge of the right column.
  const side = equationNumberingSide === 'left' ? 'left' : 'right';
  const all = [];
  const pageProfiles = new Map();
  for (const [page, rawLines] of rawPageLines.entries()) {
    const split = equationColumnAwareSupplementLines(rawLines);
    const leftProfile = split.find((line) => line?.equationTwoColumn && line.equationColumnIndex === 0);
    const rightProfile = split.find((line) => line?.equationTwoColumn && line.equationColumnIndex === 1);
    if (!leftProfile || !rightProfile) continue;
    pageProfiles.set(page, {
      leftStart: Number(leftProfile.equationColumnStartRatio),
      leftEnd: Number(leftProfile.equationColumnEndRatio),
      rightStart: Number(rightProfile.equationColumnStartRatio),
      rightEnd: Number(rightProfile.equationColumnEndRatio),
    });
    all.push(...twoColumnEquationSupplementCandidates(split, page, side));
    // The same-y row merger can attach left-column algorithm prose to a
    // legitimate right-column equation. Evaluate the outer column again using
    // its OWN text, but only for strongly mathematical tagged displays. A
    // two-sided numbering sequence must corroborate any newly added label.
    const outerColumn = side === 'left' ? 0 : 1;
    for (const record of twoColumnEquationSupplementCandidates(split, page, side, outerColumn)) {
      if (!record.explicitParenthesized || record.standaloneTag
          || (record.mathSignals < 2 && !record.shortLocalDisplay)
          || record.enumeratedConditionList || equationReferenceProseContext(record.text)) continue;
      if (side === 'right' && Number(record.candidateXStartRatio) < 0.78) continue;
      if (side === 'left' && Number(record.candidateXEndRatio) > 0.22) continue;
      all.push({ ...record, recoveredOuterColumn: true });
    }
  }
  const unique = [];
  const seen = new Set();
  for (const item of all) {
    const key = `${item.page}:${item.label}`;
    if (seen.has(key) || index.has(item.label)) continue;
    seen.add(key);
    unique.push(item);
  }
  if (!unique.length) return pageProfiles;

  const trustedNumeric = [];
  for (const [label, candidates] of index.entries()) {
    const parsed = parsedEquationNumber(label);
    if (parsed && candidates?.length) trustedNumeric.push(parsed);
  }
  const compatible = unique.filter((item) => {
    if (!trustedNumeric.length) return true;
    const p = item.numeric;
    return trustedNumeric.some((q) => p.prefix === q.prefix || (!p.prefix && !q.prefix));
  });
  // Keep the repeated-candidate requirement for general two-column
  // supplementation. One visibly mathematical *integer* label may stand alone
  // at a local gutter: allow it only when a trusted consecutive integer
  // sequence already establishes exactly which number is missing. This
  // recovers the first equation of a two-column paper without promoting an
  // isolated prose citation or a table's parenthesized decimal.
  // A lone outer-column recovery must be bracketed by two already trusted
  // printed numbers. It is not evidence for a new numbering family itself.
  const knownIntegersForOuter = new Set(trustedNumeric.filter((item) => !item.prefix).map((item) => item.last));
  const outerVerified = compatible.filter((item) => item.recoveredOuterColumn
    && !item.numeric?.prefix
    && knownIntegersForOuter.has(item.numeric.last - 1)
    && knownIntegersForOuter.has(item.numeric.last + 1));
  const innerCompatible = compatible.filter((item) => !item.recoveredOuterColumn);
  let promoted = [...innerCompatible, ...outerVerified];
  if (innerCompatible.length < 2) {
    const knownIntegers = new Set(trustedNumeric.filter((item) => !item.prefix).map((item) => item.last));
    const corroborated = innerCompatible.filter((item) => {
      const n = item.numeric?.last;
      if (!item.shortLocalDisplay || item.numeric?.prefix || !Number.isInteger(n) || n < 1) return false;
      const nearSuccessors = [...knownIntegers].filter((value) => value > n && value <= n + 6);
      const supportedLeadingGap = knownIntegers.has(n + 1) && nearSuccessors.length >= 3
        && [...knownIntegers].every((value) => value > n);
      return (knownIntegers.has(n + 1) && knownIntegers.has(n + 2))
        || (knownIntegers.has(n - 1) && knownIntegers.has(n + 1))
        || supportedLeadingGap;
    });
    if (corroborated.length === 1) promoted = [...corroborated, ...outerVerified];
    else if (!outerVerified.length) return pageProfiles;
    else promoted = outerVerified;
  }
  for (const item of promoted) index.set(item.label, [item]);

  return pageProfiles;
}

function annotateEquationColumnsForOrder(index, pageProfiles) {
  if (!(pageProfiles instanceof Map) || !pageProfiles.size) return;
  // The supplementary tag already knows its *local* column. Do not overwrite
  // that fact just because the left-column gutter happens to lie within the
  // right-column start tolerance (e.g. the first (1) of a two-column paper).
  // For trusted native labels, classify by the physical token's own bounds,
  // rather than assigning every label on the page to the outer column.
  for (const candidates of index.values()) {
    for (const candidate of candidates || []) {
      const profile = pageProfiles.get(Number(candidate?.page));
      if (!profile) continue;
      if (candidate.equationTwoColumn && Number.isInteger(candidate.equationColumnIndex)) continue;
      const start = Number(candidate?.candidateXStartRatio ?? candidate?.xStartRatio);
      const end = Number(candidate?.candidateXEndRatio ?? candidate?.xEndRatio);
      if (![start, end, profile.leftEnd, profile.rightStart].every(Number.isFinite)) continue;
      const gap = profile.rightStart - profile.leftEnd;
      if (gap <= 0) continue;
      // A small tolerance accommodates fonts whose bounding boxes barely
      // overrun a column, but never use a broad tolerance that crosses the
      // gutter and moves a left-column label after right-column equations.
      let columnIndex = null;
      if (end <= profile.leftEnd + Math.min(0.012, gap * 0.35)) columnIndex = 0;
      else if (start >= profile.rightStart - Math.min(0.012, gap * 0.35)) columnIndex = 1;
      if (columnIndex === null) continue;
      candidate.equationTwoColumn = true;
      candidate.equationColumnIndex = columnIndex;
      candidate.equationColumnStartRatio = columnIndex === 0 ? profile.leftStart : profile.rightStart;
      candidate.equationColumnEndRatio = columnIndex === 0 ? profile.leftEnd : profile.rightEnd;
    }
  }
}

function equationCandidateAlignedToNumberingSide(item, side = equationNumberingSide) {
  const start = Number(item?.candidateXStartRatio ?? item?.xStartRatio);
  const end = Number(item?.candidateXEndRatio ?? item?.xEndRatio);
  if (side === 'left') return (Number.isFinite(end) && end <= 0.34) || (Number.isFinite(start) && start <= 0.28);
  return (Number.isFinite(start) && start >= 0.62) || (Number.isFinite(end) && end >= 0.74);
}

function chooseCanonicalEquationCandidate(candidates) {
  const usable = (candidates || []).filter(Boolean);
  if (!usable.length) return null;
  return [...usable].sort((a, b) => {
    // The user-triggered margin observation has actual page-image geometry.
    // This takes precedence over a native-text target of the same label,
    // which may be an inline citation or have corrupt placement.
    const aVerified = a.meticulousPageVerified === true && Number.isFinite(a.ratio) && a.ratio >= 0 && a.ratio < 0.999;
    const bVerified = b.meticulousPageVerified === true && Number.isFinite(b.ratio) && b.ratio >= 0 && b.ratio < 0.999;
    // Only the revised outer-margin + uncropped-prose check certifies a new
    // navigation location. Historical v381-v384 coordinates remain preserved
    // for an unrescanned label but cannot outrank a newly vetted position.
    const aVetted = aVerified && a.marginLocationVerifiedV385 === true;
    const bVetted = bVerified && b.marginLocationVerifiedV385 === true;
    // v386 page-frame normalization fixes vertical drift from OCR engines
    // using a different internal image size. Never prefer older v385 geometry
    // when the same physical label has newly verified v386 measurements.
    const aNew = aVerified && a.marginLocationVerifiedV386 === true;
    const bNew = bVerified && b.marginLocationVerifiedV386 === true;
    if (aNew !== bNew) return aNew ? -1 : 1;
    if (aVetted !== bVetted) return aVetted ? -1 : 1;
    if (aVerified !== bVerified) return aVerified ? -1 : 1;
    // Fresh actual hOCR geometry supersedes pre-v384 cached margin candidates
    // whose coordinates may have been fallback estimates.
    const aMeasured = aVerified && a.ocrGeometryMeasured === true;
    const bMeasured = bVerified && b.ocrGeometryMeasured === true;
    if (aMeasured !== bMeasured) return aMeasured ? -1 : 1;
    // Compare the equation-label token itself, not the whole line, and prefer
    // the document's inferred numbering margin. This handles both modern
    // right-numbered papers and older left-numbered papers.
    const aAligned = equationCandidateAlignedToNumberingSide(a);
    const bAligned = equationCandidateAlignedToNumberingSide(b);
    if (aAligned !== bAligned) return bAligned ? 1 : -1;
    const aEnd = Number(a.candidateXEndRatio ?? a.xEndRatio);
    const bEnd = Number(b.candidateXEndRatio ?? b.xEndRatio);
    const aStart = Number(a.candidateXStartRatio ?? a.xStartRatio);
    const bStart = Number(b.candidateXStartRatio ?? b.xStartRatio);
    if (equationNumberingSide === 'left') {
      const aGeom = Number.isFinite(aStart) ? aStart : (Number.isFinite(aEnd) ? aEnd : 2);
      const bGeom = Number.isFinite(bStart) ? bStart : (Number.isFinite(bEnd) ? bEnd : 2);
      if (Math.abs(aGeom - bGeom) > 0.02) return aGeom - bGeom;
    } else {
      const aGeom = Number.isFinite(aEnd) ? aEnd : (Number.isFinite(aStart) ? aStart : -1);
      const bGeom = Number.isFinite(bEnd) ? bEnd : (Number.isFinite(bStart) ? bStart : -1);
      if (Math.abs(aGeom - bGeom) > 0.02) return bGeom - aGeom;
    }
    const aPos = equationDocumentPosition(a);
    const bPos = equationDocumentPosition(b);
    if (Math.abs(aPos - bPos) > 1e-6) return aPos - bPos;
    return (Number(b.confidence) || 0) - (Number(a.confidence) || 0);
  })[0];
}

// The label is display text, not a document-wide primary key. A book may
// restart (1), (2), ... at every lecture, or reuse (1.1) in separate parts.
// Preserve *independently printed* native-margin targets, never inline mentions
// or unsupported OCR guesses. For two candidates on the same page, retain a
// single best measured position; an ordinary reference does not make a second
// occurrence just because it repeats the label.
function equationVerifiedPrintedOccurrence(item) {
  if (item?.confirmedColonMargin) return true;
  if (!item || !Number.isFinite(item.confidence) || item.confidence < 8
      || item.sequenceOnly || item.attachedFunctionCall || item.enumeratedConditionList
      || item.axisNumericCluster || item.tabularNumericCell || item.measurementValue
      || item.ocrTopRunningHeader || item.nearbyHeadingContext || item.sameRowHeadingContext
      || equationReferenceProseContext(item.text)) return false;
  if (item.ocrSource && !item.nativeGapCorroborated && !item.meticulousPageVerified) return false;
  if (!item.explicitParenthesized || !equationCandidateAlignedToNumberingSide(item)) return false;
  const start = Number(item.candidateXStartRatio);
  const end = Number(item.candidateXEndRatio);
  if (!Number.isFinite(start) || !Number.isFinite(end)) return false;
  return equationNumberingSide === 'left'
    ? item.candidateAtLineStart && start >= 0.02 && end <= 0.22
    : item.candidateAtLineEnd && start >= 0.74 && end <= 0.995;
}

function canonicalizeEquationIndex(index) {
  const out = new Map();
  for (const [label, candidates] of index.entries()) {
    const canonical = chooseCanonicalEquationCandidate(candidates);
    if (!canonical) continue;
    const trusted = (candidates || []).filter(equationVerifiedPrintedOccurrence);
    const byPage = new Map();
    for (const record of trusted) {
      const page = Number(record.page);
      const old = byPage.get(page);
      // The same-page choice must use the same evidence hierarchy as the
      // document-wide canonical target. Raw confidence is not comparable to
      // fresh page-frame verification: an old high-score location can be stale.
      if (!old || chooseCanonicalEquationCandidate([old, record]) === record) byPage.set(page, record);
    }
    if (!byPage.size) byPage.set(Number(canonical.page), canonical);
    // Retain a canonical result on its own page even if the strict corroboration
    // guard found no repeated family. Never add an untrusted *extra* page.
    else if (!byPage.has(Number(canonical.page)) && !canonical.ocrSource
        && equationVerifiedPrintedOccurrence(canonical)) byPage.set(Number(canonical.page), canonical);
    out.set(label, [...byPage.values()].sort((a,b)=>equationDocumentPosition(a)-equationDocumentPosition(b)));
  }
  return out;
}

function recoverSequentialEquationGaps(index, candidatePool) {
  const best = [];
  for (const [label, candidates] of index.entries()) {
    const parsed = parsedEquationNumber(label);
    if (!parsed || !candidates?.length) continue;
    const candidate = chooseCanonicalEquationCandidate(candidates);
    if (!candidate) continue;
    best.push({ label, parsed, candidate });
  }
  best.sort((a, b) => equationDocumentPosition(a.candidate) - equationDocumentPosition(b.candidate));
  for (let i = 0; i + 1 < best.length; i += 1) {
    const left = best[i];
    const right = best[i + 1];
    if (left.parsed.prefix !== right.parsed.prefix) continue;
    const gap = right.parsed.last - left.parsed.last;
    if (gap < 2 || gap > 4) continue;
    const leftPos = equationDocumentPosition(left.candidate);
    const rightPos = equationDocumentPosition(right.candidate);
    for (let missing = left.parsed.last + 1; missing < right.parsed.last; missing += 1) {
      const separator = left.parsed.separator ?? '.';
      const expected = left.parsed.prefix ? `(${left.parsed.prefix}${separator}${missing})` : `(${missing})`;
      if (index.has(expected)) continue;
      const matches = (candidatePool.get(expected) || []).filter((item) => {
        const pos = equationDocumentPosition(item);
        return pos > leftPos && pos < rightPos;
      });
      if (!matches.length) continue;
      const ordinaryMatches = matches.filter((item) => !item?.recoveredMarginGapCandidate);
      const usableMatches = ordinaryMatches.length ? ordinaryMatches : matches;
      // The prose-like margin fallback is intentionally weaker than the normal
      // candidate pool. It may fill a gap only when the evidence is unique;
      // never choose arbitrarily between two low-confidence margin rows.
      if (!ordinaryMatches.length && usableMatches.length !== 1) continue;
      const canonicalMatch = chooseCanonicalEquationCandidate(usableMatches);
      if (!canonicalMatch) continue;
      const recovered = { ...canonicalMatch, confidence: Math.max(10, Number(canonicalMatch.confidence) || 0), recoveredBySequence: true };
      index.set(expected, [recovered]);
    }
  }
}

function equationCandidateAttachedToFunctionCall(source, index) {
  const prefix = String(source || '').slice(0, Math.max(0, Number(index) || 0));
  if (!prefix) return false;
  // A gapless parenthesis immediately following an identifier is function
  // application (g(1), f_1(2), Γ(3), h′(4)), not a margin equation tag.
  // PDF.js inserts a space between separate text items, so a genuine detached
  // equation number such as "... = 0 (1)" remains on the normal path.
  return /(?:[\p{L}\p{N}_\]}'’′]|\\[A-Za-z]+)$/u.test(prefix);
}

function equationLabelCandidatesInLine(text) {
  const source = String(text || '');
  const out = [];
  // Keep candidate offsets in the original PDF.js line. Whole-line NFKC
  // changes UTF-16 length for mathematical alphanumerics (for example 𝜌 -> ρ
  // or 𝑓 -> f), so an index measured after normalization can point into the
  // formula rather than the visible right-margin label. Normalize only the tag
  // payload; match offsets must stay in the string used by line.parts.
  const re = /[（(]\s*([^()（）]{1,32}?)\s*[)）]/g;
  let match;
  while ((match = re.exec(source))) {
    // A dangling second close-paren, as in a line extracted as "(2))"
    // after prose ending in "in view of", is a broken reference continuation,
    // not a printed standalone margin equation.
    if (/^\s*[)）]/u.test(source.slice(match.index + match[0].length))) continue;
    const rawInner = normalizeEquationTagCommands(String(match[1] || '').normalize('NFKC'));
    const numericInner = compactNumericEquationTagInner(rawInner);
    const symbolicInner = String(rawInner || '').replace(/\s+/g, '');
    // Keep one shared parenthesized-tag grammar for the Equation index: numeric
    // dotted/hyphen labels and the deliberately small symbolic tag alphabet.
    // Numeric extraction rejects digit-whitespace-digit so a broken text layer
    // cannot silently turn "2 2" into equation (22).
    const numeric = isPlausibleEquationTagInner(numericInner);
    const symbolic = isSymbolicEquationTagInner(symbolicInner);
    if (!numeric && !symbolic) continue;
    const label = normalizedEquationLabel(`(${numeric ? numericInner : symbolicInner})`);
    if (numeric && isLikelyCalendarYearEquationLabel(label)) continue;
    out.push({
      label,
      index: match.index,
      end: match.index + match[0].length,
      attachedFunctionCall: Boolean(numeric && equationCandidateAttachedToFunctionCall(source, match.index)),
    });
  }

  // Digitized old journals occasionally expose a visibly parenthesized margin
  // tag with one corrupted closing glyph in the text layer, e.g. "(2.6J".
  // Normalize only the candidate itself; never normalize preceding formula text
  // when deriving geometry offsets.
  const damagedLeadingParen = source.match(/^\s*[（(]\s*([0-9０-９]+\s*(?:(?:[.．]\s*[0-9０-９]+)+|(?:[-－]\s*[0-9０-９]+)+))\s*[J\]\}](?=\s|$)/u);
  if (damagedLeadingParen) {
    const raw = damagedLeadingParen[0];
    const inner = String(damagedLeadingParen[1] || '').normalize('NFKC');
    const label = normalizedEquationLabel(inner);
    if (!isLikelyCalendarYearEquationLabel(label) && !out.some((item) => item.label === label)) {
      const index = source.indexOf(raw);
      out.push({ label, index: Math.max(0, index), end: Math.max(0, index) + raw.length, extractionRepaired: true });
    }
  }
  // Older journals often print a bare hierarchical number at the left margin
  // on the same visual line as the display formula, e.g. "1.2   <formula>" or
  // with extraction spacing such as "1 . 14   <formula>". Admit only a dotted
  // leading token here; geometry and mathematical context below still decide
  // whether it is a real equation target. This deliberately does not admit a
  // bare integer prefix, which would collide heavily with section numbering.
  const leadingBare = source.match(/^\s*((?:[0-9０-９]+\s*(?:[.．]\s*[0-9０-９]+)+|[A-Za-z]{1,2}\s*(?:(?:[.．\-－]\s*[0-9０-９]+)+|[0-9０-９]+)))(?=\s|$)/u);
  if (leadingBare) {
    const raw = leadingBare[1];
    const compact = raw.normalize('NFKC').replace(/\s+/g, '');
    const label = normalizedEquationLabel(compact);
    // Compact A1/A2 tokens are ordinary identifiers in prose. Accept them
    // without parentheses only if the entire line contains the token.
    const compactAppendix = /^[A-Za-z]{1,2}\d{1,4}[a-z]?$/.test(compact);
    if ((!compactAppendix || source.trim() === raw.trim()) && isPlausibleEquationTagInner(compact)
        && !isLikelyCalendarYearEquationLabel(label) && !out.some((item) => item.label === label)) {
      const index = source.indexOf(raw);
      out.push({ label, index: Math.max(0, index), end: Math.max(0, index) + raw.length, bare: true });
    }
  }

  // Some older mathematical fonts map the printed decimal separator to
  // ":" in PDF.js (for example a visibly numbered display 3.7 becomes
  // "3:7"). Do not rewrite the entire line: source offsets are needed for
  // precise click/navigation geometry, and a colon in prose can be a ratio or
  // a clock time. This candidate is published only after the independent
  // document-level left-margin family and page-geometry checks below.
  const leadingColon = source.match(/^\s*(\d{1,3}\s*[:：]\s*\d{1,3})(?=\s|$)/u);
  if (leadingColon) {
    const raw = leadingColon[1];
    const label = normalizedEquationLabel(raw.normalize('NFKC').replace(/\s*:\s*/g, '.'));
    if (isPlausibleEquationTagInner(label.slice(1, -1))
        && !out.some((item) => item.label === label)) {
      const index = source.indexOf(raw);
      out.push({ label, index, end: index + raw.length, bare: true, colonEncoded: true });
    }
  }

  // PDF.js sometimes drops the visible parentheses around a margin equation
  // number and exposes only a standalone token such as "13.30".
  // Record that narrow form as a candidate; geometry / neighboring display
  // math still decides whether it is reliable below.
  const trimmedSource = source.trim();
  const trimmed = trimmedSource.normalize('NFKC');
  const compactBare = /\s/.test(trimmed) ? '' : trimmed;
  if (isPlausibleEquationTagInner(compactBare) && /[.\-]/.test(compactBare)) {
    const label = normalizedEquationLabel(compactBare);
    if (!isLikelyCalendarYearEquationLabel(label) && !out.some((item) => item.label === label)) {
      const index = source.indexOf(trimmedSource);
      out.push({ label, index: Math.max(0, index), end: Math.max(0, index) + trimmedSource.length, bare: true });
    }
  }
  return out;
}

function equationTargetScore(lineText, label, originPage, page, originRatio = null, candidateRatio = null) {
  const text = String(lineText || '').trim();
  const compact = text.replace(/\s+/g, '').normalize('NFKC');
  const pos = compact.lastIndexOf(label);
  let score = 0;
  if (pos >= 0 && pos + label.length >= compact.length - 1) score += 12;
  if (compact === label) score += 10;
  score += Math.min(10, (text.match(/[=≤≥≠≈∫∑∏√∂∇∞^_+−-]/g) || []).length * 1.5);
  if (/^(?:theorem|lemma|proposition|corollary|definition|remark|example|claim|proof|section)\b/i.test(text)) score -= 20;
  if (/\b(?:theorem|lemma|proposition|corollary|definition|remark|example|claim|section)\s+\d/i.test(text)) score -= 10;
  // Parenthesized equation numbers inside prose are references, not targets.
  // Prefer display-math/right-margin style lines and strongly demote prose
  // phrases that merely cite an equation.
  if (/\b(?:equation|eq\.?|see|from|by|using|satisfies|implies|according\s+to|as\s+in|in\s+view\s+of|contradicts?|rewrit(?:e|ten)|follows?\s+from|inequality\s+(?:like|in)|as\s+required)\b/i.test(text)) score -= 18;
  if (page === originPage) score += 0.5;
  if (page === originPage && Number.isFinite(originRatio) && Number.isFinite(candidateRatio)) {
    const delta = Math.abs(candidateRatio - originRatio);
    if (delta < 0.018) score -= 1000;
    else if (delta < 0.05) score -= 12;
  }
  score -= Math.min(4, text.length / 160);
  return score;
}

function equationCandidateConfidence(line, label) {
  const text = String(line?.text || '').trim();
  if (!text || isLikelyCalendarYearEquationLabel(label)) return -Infinity;
  const compact = text.replace(/\s+/g, '').normalize('NFKC');
  const normalized = normalizedEquationLabel(label);
  const isOnlyTag = compact === normalized || compact === normalized.slice(1, -1);
  const mathSignals = (text.match(/[=≤≥≠≈≡∈∉⊂⊆⊇→↔∫∑∏√∂∇∞^_+−×·/\-]/g) || []).length;
  const xStart = Number(line?.xStartRatio);
  const xEnd = Number(line?.xEndRatio);
  const nearRight = (Number.isFinite(xStart) && xStart >= 0.62) || (Number.isFinite(xEnd) && xEnd >= 0.78);
  const nearBottom = Number(line?.ratio) >= 0.90;
  const proseHeavy = text.length > 55 && mathSignals === 0;
  const isolatedRightTag = isOnlyTag && Number.isFinite(xStart) && xStart >= 0.62;
  if (isOnlyTag && nearBottom && !isolatedRightTag) return -Infinity;
  // A numeric parenthesis embedded in prose is a reference/date/section-like
  // token, not an equation target. Pure tag lines are accepted only when the
  // glyph geometry places them at the display-math right margin.
  if (mathSignals === 0 && !isolatedRightTag) return -Infinity;
  if (proseHeavy && !isolatedRightTag) return -Infinity;
  let confidence = equationTargetScore(text, normalized, null, 0, null, Number(line?.ratio));
  if (mathSignals >= 2) confidence += 5;
  else if (mathSignals === 1) confidence += 2;
  if (nearRight) confidence += 6;
  if (isOnlyTag && nearRight) confidence += 5;
  if (Number.isFinite(xStart) && xStart < 0.18 && mathSignals === 0) confidence -= 6;
  return confidence;
}

function equationLineMathSignalCount(text) {
  return (String(text || '').match(/[=≤≥≠≈≡∈∉⊂⊆⊇→↔∫∑∏√∂∇∞^_+−×·/\-]/g) || []).length;
}

function hasNearbyDisplayMath(lines, lineIndex) {
  const line = lines[lineIndex];
  if (!line) return false;
  const ratio = Number(line.ratio);
  for (const neighborIndex of [lineIndex - 1, lineIndex + 1]) {
    const neighbor = lines[neighborIndex];
    if (!neighbor) continue;
    const neighborRatio = Number(neighbor.ratio);
    if (Number.isFinite(ratio) && Number.isFinite(neighborRatio) && Math.abs(neighborRatio - ratio) > 0.045) continue;
    if (equationLineMathSignalCount(neighbor.text) >= 2) return true;
  }
  return false;
}

function bareEquationHasNearbyHeadingContext(lines, lineIndex) {
  const line = lines[lineIndex];
  if (!line) return false;
  const ratio = Number(line.ratio);
  for (const neighborIndex of [lineIndex - 2, lineIndex - 1, lineIndex + 1, lineIndex + 2]) {
    const neighbor = lines[neighborIndex];
    if (!neighbor) continue;
    const neighborRatio = Number(neighbor.ratio);
    if (Number.isFinite(ratio) && Number.isFinite(neighborRatio) && Math.abs(neighborRatio - ratio) > 0.014) continue;
    const text = String(neighbor.text || '').trim();
    if (!text || equationLineMathSignalCount(text) >= 2 || /[.!?。！？]$/.test(text)) continue;
    const asciiWords = text.match(/\b[A-Za-z]{3,}\b/g) || [];
    const titleCaseWords = text.match(/\b[A-Z][A-Za-z]{2,}\b/g) || [];
    const hanChars = text.match(/\p{Script=Han}/gu) || [];
    if (hanChars.length >= 3) return true;
    if (/^[A-Z]{4,}(?:\s+[A-Z]{3,})*[.:]?$/u.test(text) && asciiWords.length >= 1) return true;
    if (/^[A-Z]/.test(text) && asciiWords.length >= 2 && titleCaseWords.length >= 1) return true;
  }
  return false;
}

function bareEquationHasSameRowHeadingContext(lines, lineIndex) {
  const line = lines?.[lineIndex];
  if (!line) return false;
  const ratio = Number(line.ratio);
  const lineEnd = Number(line.xEndRatio);
  for (let index = 0; index < (lines || []).length; index += 1) {
    if (index === lineIndex) continue;
    const other = lines[index];
    const otherRatio = Number(other?.ratio);
    if (!Number.isFinite(ratio) || !Number.isFinite(otherRatio) || Math.abs(otherRatio - ratio) > 0.0045) continue;
    const otherStart = Number(other?.xStartRatio);
    if (Number.isFinite(lineEnd) && Number.isFinite(otherStart) && otherStart < lineEnd - 0.01) continue;
    const text = String(other?.text || '').trim();
    if (!text || equationLineMathSignalCount(text) >= 2 || /[.!?。！？]$/.test(text)) continue;
    const asciiWords = text.match(/\b[A-Za-z]{3,}\b/g) || [];
    const titleCaseWords = text.match(/\b[A-Z][A-Za-z]{2,}\b/g) || [];
    const hanChars = text.match(/\p{Script=Han}/gu) || [];
    if (hanChars.length >= 3) return true;
    // Fragmented CJK subsection headings may contain only two characters
    // (e.g. a compact topic name). Require close physical continuation on
    // the same baseline, never a separate display-math line.
    if (hanChars.length >= 2 && text.length <= 24
      && Number.isFinite(lineEnd) && Number.isFinite(otherStart)
      && otherStart - lineEnd <= 0.09) return true;
    if (/^[A-Z]{4,}(?:\s+[A-Z]{3,})*[.:]?$/u.test(text) && asciiWords.length >= 1) return true;
    if (/^[A-Z]/.test(text) && asciiWords.length >= 2 && titleCaseWords.length >= 1) return true;
  }
  return false;
}

function isStandaloneEquationTagLine(line, label) {
  const text = String(line?.text || '').trim().replace(/\s+/g, '').normalize('NFKC');
  const normalized = normalizedEquationLabel(label);
  return text === normalized || text === normalized.slice(1, -1);
}

function bareEquationInHorizontalNumericCluster(lines, lineIndex) {
  const line = lines[lineIndex];
  if (!line) return false;
  const text = String(line.text || '').trim().replace(/\s+/g, '');
  if (!/^[+-]?\d+(?:\.\d+)?$/.test(text)) return false;
  const ratio = Number(line.ratio);
  const centers = [];
  for (const other of lines) {
    const otherRatio = Number(other?.ratio);
    if (Number.isFinite(ratio) && Number.isFinite(otherRatio) && Math.abs(otherRatio - ratio) > 0.0045) continue;
    const otherText = String(other?.text || '').trim().replace(/\s+/g, '');
    if (!/^[+-]?\d+(?:\.\d+)?$/.test(otherText)) continue;
    const start = Number(other?.xStartRatio); const end = Number(other?.xEndRatio);
    if (!Number.isFinite(start) || !Number.isFinite(end)) continue;
    centers.push((start + end) / 2);
  }
  if (centers.length < 3) return false;
  return Math.max(...centers) - Math.min(...centers) >= 0.16;
}

// Plot axes frequently expose decimal ticks as separate text lines, one per
// horizontal scan row. A same-row tabular guard cannot see this vertical run.
// Reject only a tightly spaced, monotonically ordered group of >=4 small
// decimals at the same horizontal coordinate; isolated old-paper bare dotted
// equation labels remain eligible for the existing margin/math checks.
function bareEquationInVerticalNumericTicks(lines, lineIndex) {
  const current = lines?.[lineIndex];
  const valueText = String(current?.text || '').trim();
  if (!/^0\.\d{1,3}$/.test(valueText)) return false;
  const center = (Number(current?.xStartRatio) + Number(current?.xEndRatio)) / 2;
  const ratio = Number(current?.ratio);
  if (!Number.isFinite(center) || !Number.isFinite(ratio)) return false;
  const ticks = (lines || []).filter((other) => {
    const text = String(other?.text || '').trim();
    const start = Number(other?.xStartRatio); const end = Number(other?.xEndRatio);
    const y = Number(other?.ratio);
    return /^0\.\d{1,3}$/.test(text)
      && Number.isFinite(start) && Number.isFinite(end) && Number.isFinite(y)
      && Math.abs((start + end) / 2 - center) <= 0.012
      && Math.abs(y - ratio) <= 0.09;
  }).map((line) => ({ ratio: Number(line.ratio), value: Number(line.text) }))
    .sort((a, b) => a.ratio - b.ratio);
  for (let start = 0; start < ticks.length; start += 1) {
    const run = [ticks[start]];
    for (let next = start + 1; next < ticks.length; next += 1) {
      const delta = ticks[next].ratio - ticks[next - 1].ratio;
      if (delta < 0.0025 || delta > 0.025) break;
      run.push(ticks[next]);
      if (run.length >= 4
        && run.some((item) => Math.abs(item.ratio - ratio) < 0.00001)
        && (run.every((item, index) => index === 0 || item.value < run[index - 1].value)
          || run.every((item, index) => index === 0 || item.value > run[index - 1].value))) {
        // Equally spaced scale ticks, not arbitrary changing measurements in a
        // technical table. Require comparable numeric steps as well as y steps.
        const numericSteps = run.slice(1).map((item, i) => Math.abs(item.value - run[i].value));
        const smallestStep = Math.min(...numericSteps);
        if (smallestStep > 0.00001 && Math.max(...numericSteps) / smallestStep <= 1.25) return true;
      }
    }
  }
  return false;
}

function bareEquationHasMeasurementSuffix(line, candidate) {
  if (!candidate?.bare) return false;
  const source = String(line?.text || '').normalize('NFKC');
  const before = source.slice(0, Math.max(0, Number(candidate?.index) || 0)).trim();
  if (before) return false;
  const remainder = source.slice(Math.max(0, Number(candidate?.end) || 0)).trim();
  if (!remainder) return false;
  // Technical/performance tables often begin with a decimal measurement such as
  // "1.242 s / 22.8% faster" or "1.40 GiB/s".  A bare dotted token in this
  // position is a value, not a lost-parenthesis equation label.  Keep the unit
  // vocabulary deliberately narrow so old journal tags remain eligible.
  return /^(?:%|(?:ns|us|µs|ms|sec|secs|second|seconds|s|KB|MB|GB|KiB|MiB|GiB|B|Hz|kHz|MHz|GHz|fps)\b)/i.test(remainder);
}

function bareEquationInTabularRow(lines, lineIndex) {
  const line = lines[lineIndex];
  if (!line) return false;
  const compact = String(line.text || '').trim().replace(/\s+/g, ' ');
  // This guard is only for a bare numeric cell (optionally followed by a short
  // measurement unit). Parenthesized margin labels never enter this path.
  if (!/^[+-]?\d+(?:\.\d+)?(?:\s*(?:ms|s|sec|µs|us|ns|%|MB|GB|KB|MiB|GiB))?$/i.test(compact)) return false;
  const ratio = Number(line.ratio);
  const row = [];
  for (const other of lines || []) {
    const otherRatio = Number(other?.ratio);
    if (Number.isFinite(ratio) && Number.isFinite(otherRatio) && Math.abs(otherRatio - ratio) > 0.0045) continue;
    const text = String(other?.text || '').trim().replace(/\s+/g, ' ');
    const start = Number(other?.xStartRatio); const end = Number(other?.xEndRatio);
    if (!text || text.length > 40 || !Number.isFinite(start) || !Number.isFinite(end)) continue;
    row.push({ text, center: (start + end) / 2, math: equationLineMathSignalCount(text) });
  }
  if (row.length < 3 || row.some((cell) => cell.math >= 2)) return false;
  const spread = Math.max(...row.map((cell) => cell.center)) - Math.min(...row.map((cell) => cell.center));
  if (spread < 0.18) return false;
  const numericCells = row.filter((cell) => /^[+-]?\d+(?:\.\d+)?(?:\s*(?:ms|s|sec|µs|us|ns|%|MB|GB|KB|MiB|GiB))?$/i.test(cell.text)).length;
  const plainKeyCell = row.some((cell) => /^[A-Za-z][A-Za-z0-9_.+\-]*(?:\([^)]{0,24}\))?$/.test(cell.text));
  return numericCells >= 3 || (numericCells >= 2 && plainKeyCell);
}

function equationCandidateTokenGeometry(line, candidate) {
  const start = Number(candidate?.index || 0);
  const end = Number(candidate?.end || start);
  const overlaps = (line?.parts || []).filter((part) => Number(part.end) > start && Number(part.start) < end);
  if (overlaps.length) {
    const first = overlaps[0];
    const last = overlaps[overlaps.length - 1];
    const startSpan = Math.max(1, Number(first.end) - Number(first.start));
    const endSpan = Math.max(1, Number(last.end) - Number(last.start));
    const startFraction = Math.min(1, Math.max(0, (start - Number(first.start)) / startSpan));
    const endFraction = Math.min(1, Math.max(0, (end - Number(last.start)) / endSpan));
    const xStart = Number(first.xStartRatio) + (Number(first.xEndRatio) - Number(first.xStartRatio)) * startFraction;
    const xEnd = Number(last.xStartRatio) + (Number(last.xEndRatio) - Number(last.xStartRatio)) * endFraction;
    return { xStartRatio: xStart, xEndRatio: xEnd };
  }
  const lineText = String(line?.text || '');
  const lineSpan = Math.max(0, Number(line?.xEndRatio) - Number(line?.xStartRatio));
  const textLength = Math.max(1, lineText.length);
  const startFraction = Math.min(1, Math.max(0, start / textLength));
  const endFraction = Math.min(1, Math.max(startFraction, end / textLength));
  return {
    xStartRatio: Number(line?.xStartRatio) + lineSpan * startFraction,
    xEndRatio: Number(line?.xStartRatio) + lineSpan * endFraction
  };
}

function legacyBareEquationMathLead(item) {
  if (!item?.bareSource || !item?.candidateAtLineStart || !item?.numeric?.prefix) return false;
  if (item?.nearbyHeadingContext || item?.axisNumericCluster || item?.tabularNumericCell) return false;
  if (Number(item?.candidateXEndRatio) > 0.24) return false;
  const text = String(item?.text || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  const remainder = text.replace(/^\s*\d{1,3}\s*(?:[.．]\s*\d{1,3}){1,4}\s*[.:)]?\s*/u, '');
  if (!remainder || /(?:\.\s*){3,}/.test(remainder)) return false;
  const lead = remainder.slice(0, 72);
  const mathematicalLead = /^(?:[A-Z]\s*(?:\(|\b)|spt\b|lim\b|sup\b|inf\b|det\b|tr\b|div\b|grad\b)/.test(lead);
  const visibleMath = /[=<>≤≥∈∉⊂⊃∩∪∑∫√^~{}()[\]|+]/u.test(lead);
  return mathematicalLead && visibleMath;
}

function inferEquationNumberingSide(records) {
  let leftScore = 0;
  let rightScore = 0;
  for (const item of records || []) {
    const start = Number(item.candidateXStartRatio);
    const end = Number(item.candidateXEndRatio);
    const contextStrong = Boolean(item.standaloneTag || item.nearbyDisplayMath || item.mathSignals >= 2 || legacyBareEquationMathLead(item));
    if (!contextStrong) continue;
    if (item.ocrSource && !item.standaloneTag && !item.candidateAtLineStart && !item.candidateAtLineEnd) continue;
    const weight = item.numeric && item.numeric.prefix ? 2 : 1.5;
    if ((Number.isFinite(end) && end <= 0.34) || (Number.isFinite(start) && start <= 0.28)) leftScore += weight;
    if ((Number.isFinite(start) && start >= 0.62) || (Number.isFinite(end) && end >= 0.74)) rightScore += weight;
  }
  if (leftScore >= 4 && leftScore > rightScore * 1.35) return 'left';
  return 'right';
}

function equationReferenceProseContext(text) {
  const source = String(text || '').normalize('NFKC');
  if (!source) return false;
  // A parenthesized number can sit exactly on the inferred numbering edge when
  // an old PDF's text layer wraps prose into a short visual line. Geometry is
  // therefore not sufficient by itself. Reject only explicit lexical contexts
  // that grammatically *refer to* an equation; genuine display tags normally
  // sit beside formula text rather than after "properties", "expansion", "of",
  // etc., or before a prose continuation such as "we have" / "this shows".
  const tag = String.raw`[（(]\s*(?:\d{1,4}(?:(?:[.．\-－]\s*\d{1,4})+)?|(?:[A-Za-z]{1,2}|[IVXLCDM]{3,8})(?:(?:[.．\-－]\s*\d{1,4})+|\d{1,4}))(?:[a-z])?\s*[)）]`;
  const before = new RegExp(String.raw`\b(?:equation|eq\.?|see|from|by|using|refer\s+to|according\s+to|as\s+in|in\s+view\s+of|follows?\s+from|recall(?:ing)?|substitut(?:e|ing)|insert(?:ing)?|apply(?:ing)?|combin(?:e|ing)|properties?|assumptions?|hypotheses?|requirements?|expansion|formula|identity|estimate|relation|conditions?|case|version|form|of|into)\s*${tag}`, 'i');
  const after = new RegExp(String.raw`${tag}\s*(?:[.,;:]\s*)?(?:and|or|but|then|hence|therefore|thus|where|which|that|is|are|was|were|holds?|gives?|implies?|shows?|yields?|we|this|it)\b`, 'i');
  return before.test(source) || after.test(source);
}

function equationEnumeratedConditionListContext(lines, lineIndex, candidate) {
  const line = lines?.[lineIndex];
  if (!line || candidate?.bare) return false;
  const parsed = parsedEquationNumber(candidate?.label);
  if (!parsed || parsed.prefix) return false;
  const before = String(line.text || '').slice(0, Math.max(0, Number(candidate?.index) || 0)).trim();
  if (before) return false;
  const currentNumber = Number(parsed.last);
  const currentRatio = Number(line.ratio);
  const currentX = Number(line.xStartRatio);
  if (!Number.isInteger(currentNumber) || !Number.isFinite(currentRatio) || !Number.isFinite(currentX)) return false;

  const nearby = [];
  for (const sibling of lines || []) {
    const ratio = Number(sibling?.ratio);
    const x = Number(sibling?.xStartRatio);
    if (!Number.isFinite(ratio) || !Number.isFinite(x)) continue;
    if (Math.abs(ratio - currentRatio) > 0.13 || Math.abs(x - currentX) > 0.045) continue;
    const match = String(sibling?.text || '').match(/^\s*[（(]\s*(\d{1,2})\s*[)）]\s*(.*)$/u);
    if (!match) continue;
    const number = Number(match[1]);
    if (!Number.isInteger(number) || Math.abs(number - currentNumber) > 5) continue;
    const tail = String(match[2] || '').trim();
    const han = tail.match(/\p{Script=Han}/gu) || [];
    const words = tail.match(/\b[A-Za-z]{3,}\b/g) || [];
    nearby.push({
      number,
      proseLike: han.length >= 2 || words.length >= 3,
      punctuated: /[;；]\s*$/.test(tail),
    });
  }
  const unique = [...new Map(nearby.map((item) => [item.number, item])).values()].sort((a, b) => a.number - b.number);
  for (let start = 0; start < unique.length; start += 1) {
    let end = start;
    while (end + 1 < unique.length && unique[end + 1].number === unique[end].number + 1) end += 1;
    const run = unique.slice(start, end + 1);
    if (run.length >= 3 && run.some((item) => item.number === currentNumber)) {
      const proseCount = run.filter((item) => item.proseLike).length;
      const punctuatedCount = run.filter((item) => item.punctuated).length;
      if (proseCount >= 2 || (proseCount >= 1 && punctuatedCount >= 2)) return true;
      // A definition can specify three purely symbolic, numbered *conditions*.
      // Without prose words or trailing semicolons the earlier run detector
      // indexed (1), (2), (3) as displayed equations. A leading "Definition
      // ... if" or "following conditions" supplies independent list context.
      const listIntroducer = (lines || []).some((earlier) => {
        const beforeRatio = Number(earlier?.ratio);
        if (!Number.isFinite(beforeRatio) || beforeRatio >= currentRatio
          || currentRatio - beforeRatio > 0.095) return false;
        const priorText = String(earlier?.text || '').trim();
        return /(?:\bdefinition\b.*\bif\s*$|\b(?:following\s+)?(?:conditions|properties|requirements)\s*(?:are|hold|:)?\s*$)/i.test(priorText);
      });
      if (listIntroducer) return true;
    }
    start = end;
  }
  return false;
}

// Colon-encoded numbers are NOT ordinary numeric tokens. Only a coherent
// family at a common physical page edge can establish this damaged font
// encoding. This avoids interpreting times, ratios, or manuscript headings as
// automatic equation targets. The rule applies across books, not filenames.
function equationColonMarginFamily(records) {
  const possible = (records || []).filter((item) => item?.colonEncoded
    && item?.candidateAtLineStart
    && Number(item?.candidateXStartRatio) >= 0.025
    && Number(item?.candidateXStartRatio) <= 0.17
    && Number(item?.candidateXEndRatio) <= 0.21
    && Number(item?.ratio) >= 0.055
    && Number(item?.ratio) <= 0.97
    && !item?.ocrSource
    && !item?.nearbyHeadingContext && !item?.sameRowHeadingContext
    && !item?.axisNumericCluster && !item?.tabularNumericCell
    && !item?.measurementValue && !item?.ocrTopRunningHeader
    && !item?.attachedFunctionCall);
  const labels = new Set(possible.map((item) => item.label));
  const pages = new Set(possible.map((item) => item.page));
  // Require recurring *distinct* labels on several pages. An isolated "1:2"
  // alongside a formula can simply be a ratio; a table of daily times should
  // not define an equation-numbering convention either.
  if (labels.size < 6 || pages.size < 3) return null;
  const starts = possible.map((item) => Number(item.candidateXStartRatio)).sort((a, b) => a - b);
  const mid = starts[Math.floor(starts.length / 2)];
  const aligned = possible.filter((item) => Math.abs(Number(item.candidateXStartRatio) - mid) <= 0.025);
  if (aligned.length < Math.max(6, Math.ceil(possible.length * 0.80))) return null;
  const formulaLike = aligned.filter((item) => {
    const remainder = String(item.text || '').replace(/^\s*\d{1,3}\s*[:：]\s*\d{1,3}\s*/, '').trim();
    if (!remainder) return Boolean(item.standaloneTag || item.nearbyDisplayMath);
    // Broken font mappings often turn =, + and <= into D, C and control
    // glyphs, so literal math-operator counts alone are not meaningful.
    return /[()\[\]{}∫∑∏√≤≥=<>\u0000-\u001f]/u.test(remainder)
      || /\b(?:lim|sup|inf|div|det|grad|tr)\b/u.test(remainder);
  });
  if (formulaLike.length < Math.max(5, Math.ceil(aligned.length * 0.55))) return null;
  return { x: mid };
}

function equationColonMarginCandidateReliable(item, profile) {
  if (!profile || !item?.colonEncoded || item.ocrSource || !item.candidateAtLineStart
    || !item.numeric?.prefix || item.attachedFunctionCall || item.enumeratedConditionList
    || item.nearbyHeadingContext || item.sameRowHeadingContext || item.axisNumericCluster
    || item.tabularNumericCell || item.measurementValue || item.ocrTopRunningHeader
    || !Number.isFinite(Number(item.candidateXStartRatio))
    || Math.abs(Number(item.candidateXStartRatio) - profile.x) > 0.025
    || Number(item.candidateXEndRatio) > 0.21
    || Number(item.ratio) < 0.055 || Number(item.ratio) > 0.97) return false;
  const remainder = String(item.text || '').replace(/^\s*\d{1,3}\s*[:：]\s*\d{1,3}\s*/, '').trim();
  const words = remainder.match(/\b[A-Za-z]{3,}\b/g) || [];
  const han = remainder.match(/\p{Script=Han}/gu) || [];
  if (/^(?:chapter|section|theorem|lemma|definition|remark|example|proposition|corollary|exercise|proof)\b/i.test(remainder)
    || (words.length >= 6 && Number(item.mathSignals) < 2)
    || (han.length >= 8 && Number(item.mathSignals) < 2)) return false;
  if (remainder && !/[()\[\]{}∫∑∏√≤≥=<>\u0000-\u001f]/u.test(remainder)
      && !/\b(?:D|lim|sup|inf|div|det|grad|tr)\b/u.test(remainder)
      && (Number(item.mathSignals) || 0) < 1) return false;
  return true;
}

function equationCandidateConfidenceForSide(item, allowExplicitReferenceContext = false) {
  if (item?.attachedFunctionCall || item?.enumeratedConditionList) return -Infinity;
  const text = String(item?.text || '').trim();
  const label = normalizedEquationLabel(item?.label || '');
  if (!text || !label || isLikelyCalendarYearEquationLabel(label)) return -Infinity;
  const compact = text.replace(/\s+/g, '').normalize('NFKC');
  const isOnlyTag = compact === label || compact === label.slice(1, -1);
  const mathSignals = Number(item.mathSignals) || 0;
  const aligned = equationCandidateAlignedToNumberingSide(item);
  const legacyBareMathLead = legacyBareEquationMathLead(item);
  const nearBottom = Number(item.ratio) >= 0.90;
  const proseHeavy = text.length > 55 && mathSignals === 0;
  const explicitMarginTag = Boolean(item?.explicitParenthesized && aligned);
  const referenceProse = /\b(?:equation|eq\.?|see|from|by|using|satisfies|implies|according\s+to|as\s+in|in\s+view\s+of|contradicts?|rewrit(?:e|ten)|follows?\s+from|inequality\s+(?:like|in)|as\s+required)\b/i.test(text);
  const bibliographyLike = /\b(?:Ann\.?|Journal|Math\.?|Proc\.?|Trans\.?|Springer|Press)\b/i.test(text);
  const bareHeadingLike = Boolean(item?.bareSource) && /^\s*\d+(?:\.\d+)+\s+[A-Za-z][A-Za-z]/.test(text);
  const bareRemainder = Boolean(item?.bareSource)
    ? text.replace(/^\s*\d+(?:\.\d+)+\s*/, '')
    : '';
  const bareWords = bareRemainder.match(/\b[A-Za-z]{3,}\b/g) || [];
  const bareHanChars = bareRemainder.match(/\p{Script=Han}/gu) || [];
  const bareStructuredProse = Boolean(item?.bareSource) && (
    /^(?:\([ivxlcdm]+\)\s*)?(?:theorem|lemma|proposition|corollary|definition|remark|example|claim|exercise|problem|suppose|let|if|give|prove|show|using)\b/i.test(bareRemainder) ||
    bareWords.length >= 3 ||
    bareHanChars.length >= 4
  );
  const parsed = parsedEquationNumber(label);
  // Appendix section headings such as "(A.1) Preliminary notation" are not
  // equations. A non-isolated alphabetic tag needs nearby *display math* or
  // mathematical symbols; otherwise a prose heading could become a target.
  if (parsed?.appendix && !item?.standaloneTag && mathSignals === 0 && !item?.nearbyDisplayMath) return -Infinity;
  const explicitReferenceContext = Boolean(parsed && item?.explicitParenthesized && equationReferenceProseContext(text));
  const integerTag = Boolean(parsed && !parsed.prefix);
  // Older mathematical fonts encode indexed variables as "ij", "kl", etc.
  // Two-letter formula subscripts are not two prose words. In particular, do
  // not discard a valid left-margin (5) solely because its line contains ij.
  const alphaWords = (text.match(/[A-Za-z]{3,}|\p{Script=Han}{2,}/gu) || [])
    .filter((word) => !/^(?:sup|inf|lim|div|det|grad)$/i.test(word));
  const codeLike = (/(?:=>|\b(?:if|else|while|return|var|new|class|public|private|static|int|string)\b)/i.test(text)
    || (/\bfor\b/i.test(text) && /[{};]/.test(text)))
    && (text.match(/[(){}\[\]]/g) || []).length >= 4;
  const onNumberingEdge = equationNumberingSide === 'left' ? Boolean(item?.candidateAtLineStart) : Boolean(item?.candidateAtLineEnd);
  const strongMarginGeometry = equationNumberingSide === 'left'
    ? Number(item?.candidateXEndRatio) <= 0.22
    : Number(item?.candidateXStartRatio) >= 0.75;
  const parenthesizedNumericCount = (text.match(/\(\s*\d+(?:(?:\.\d+)+|(?:-\d+)+)?\s*\)/g) || []).length;
  const leadingIntegerRemainder = integerTag && item?.explicitParenthesized && item?.candidateAtLineStart
    ? text.replace(/^\s*\(\s*\d+\s*\)\s*/, '')
    : '';
  const leadingIntegerWords = leadingIntegerRemainder.match(/\b[A-Za-z]{3,}\b/g) || [];
  const leadingIntegerHanChars = leadingIntegerRemainder.match(/\p{Script=Han}/gu) || [];
  const shortNumberedProseHeading = Boolean(
    integerTag
    && item?.explicitParenthesized
    && item?.candidateAtLineStart
    && !item?.candidateAtLineEnd
    && mathSignals === 0
    && !item?.nearbyDisplayMath
    && /^\s*[A-Za-z]{4,}(?:\s+[A-Za-z]{2,})?\s*[.:]?\s*$/.test(leadingIntegerRemainder)
  );
  const punctuatedStandaloneIntegerList = Boolean(
    integerTag
    && item?.explicitParenthesized
    && item?.candidateAtLineStart
    && !item?.candidateAtLineEnd
    && mathSignals === 0
    && !item?.nearbyDisplayMath
    && /^\s*[.:;]\s*$/.test(leadingIntegerRemainder)
  );
  if (shortNumberedProseHeading || punctuatedStandaloneIntegerList) return -Infinity;
  // A parenthesized token embedded inside formula text is not the printed margin tag.
  // Old PDF text layers can expose exponent fragments such as \(3-2) or symbolic
  // operators such as (*) at the physical margin; require non-standalone tags to
  // occupy the inferred textual numbering edge before they can become targets.
  if (item?.explicitParenthesized && !item?.standaloneTag && !onNumberingEdge) return -Infinity;
  if (explicitReferenceContext && !isOnlyTag && !allowExplicitReferenceContext) return -Infinity;
  if (integerTag && item?.explicitParenthesized && item?.candidateAtLineStart && !item?.candidateAtLineEnd
    && (leadingIntegerWords.length >= 4 || leadingIntegerHanChars.length >= 6)) return -Infinity;
  if (integerTag && item?.explicitParenthesized && !item?.standaloneTag && !onNumberingEdge && !strongMarginGeometry && !item?.nearbyDisplayMath) return -Infinity;
  if (parenthesizedNumericCount >= 2 && !item?.standaloneTag && !onNumberingEdge) return -Infinity;
  if (item?.ocrSource && item?.explicitParenthesized && !item?.standaloneTag && !onNumberingEdge) return -Infinity;
  if (parsed && item?.explicitParenthesized && !item?.standaloneTag && !onNumberingEdge && !item?.nearbyDisplayMath && mathSignals < 2) return -Infinity;
  if (integerTag && item?.ocrSource && !item?.standaloneTag && !onNumberingEdge) return -Infinity;
  if (integerTag && !item?.standaloneTag && codeLike) return -Infinity;
  if (integerTag && !item?.standaloneTag && mathSignals === 0 && alphaWords.length >= 2) return -Infinity;
  if (integerTag && !item?.standaloneTag && item?.candidateAtLineStart && mathSignals < 2 && !item?.nearbyDisplayMath && alphaWords.length >= 2) return -Infinity;
  if (isOnlyTag && nearBottom && !aligned) return -Infinity;
  if (item?.bareSource && item?.standaloneTag && !strongMarginGeometry && !item?.nearbyDisplayMath) return -Infinity;
  // A visible parenthesized tag already placed on the inferred equation-number
  // margin is strong target evidence by itself. Older/scanned PDF text layers
  // often lose the formula operators, so requiring extracted math glyphs here
  // made the Equation index disagree with MathReader's clickable label layer.
  if (mathSignals === 0 && !(isOnlyTag && aligned) && !explicitMarginTag && !(legacyBareMathLead && aligned)) return -Infinity;
  if (proseHeavy && !(isOnlyTag && aligned) && !explicitMarginTag) return -Infinity;
  if (referenceProse && !isOnlyTag && mathSignals < 2) return -Infinity;
  if (bibliographyLike && mathSignals < 2) return -Infinity;
  if (bareStructuredProse && !legacyBareMathLead) return -Infinity;
  if (bareHeadingLike && mathSignals < 2 && !legacyBareMathLead) return -Infinity;
  let confidence = equationTargetScore(text, label, null, 0, null, Number(item.ratio));
  if (mathSignals >= 2) confidence += 5;
  else if (mathSignals === 1) confidence += 2;
  if (aligned) confidence += 7;
  if (isOnlyTag && aligned) confidence += 5;
  if (explicitMarginTag) confidence += 6;
  if (legacyBareMathLead && aligned) confidence += 4;
  return confidence;
}

function reconcileEquationNumberingFamilies(index) {
  const numericEntries = [];
  let hierarchical = 0;
  let integers = 0;
  let ocrHierarchical = 0;
  let ocrIntegers = 0;
  for (const label of index.keys()) {
    const parsed = parsedEquationNumber(label);
    if (!parsed) continue;
    const candidates = index.get(label) || [];
    const ocrSourced = candidates.some((item) => Boolean(item?.ocrSource));
    const confirmedLocalIntegerFamily = candidates.some((item) => Boolean(item?.confirmedLocalIntegerFamily));
    numericEntries.push({ label, parsed, ocrSourced, confirmedLocalIntegerFamily });
    if (parsed.prefix) {
      hierarchical += 1;
      if (ocrSourced) ocrHierarchical += 1;
    } else {
      integers += 1;
      if (ocrSourced) ocrIntegers += 1;
    }
  }
  const numericTotal = hierarchical + integers;
  // OCR frequently drops the separator in labels such as (1.3) -> (13). If an
  // OCR document already contains a substantial, clearly dominant hierarchical
  // family, isolated pure-integer OCR labels are more safely treated as damaged
  // tags than as a second numbering system. Integer-only OCR documents are not
  // affected because they have no hierarchical family at all.
  if (ocrHierarchical >= 8 && ocrHierarchical >= Math.max(8, Math.ceil(ocrIntegers * 1.5))) {
    for (const { label, parsed, ocrSourced, confirmedLocalIntegerFamily } of numericEntries) {
      if (!parsed.prefix && ocrSourced && !confirmedLocalIntegerFamily) index.delete(label);
    }
    integers = [...index.keys()].filter((label) => {
      const parsed = parsedEquationNumber(label);
      return parsed && !parsed.prefix;
    }).length;
  }
  // A long, overwhelmingly hierarchical sequence is a document-level numbering
  // profile. In that profile, a handful of isolated integer tags are usually
  // page numbers / damaged text-layer artifacts rather than a second equation
  // numbering system. Integer-only and genuinely mixed documents stay intact.
  if (hierarchical < 10 || numericTotal < 12 || hierarchical / numericTotal < 0.88 || integers > Math.max(12, Math.ceil(hierarchical * 0.08))) return index;
  for (const { label, parsed, confirmedLocalIntegerFamily } of numericEntries) {
    if (!parsed.prefix && !confirmedLocalIntegerFamily) index.delete(label);
  }
  return index;
}

// A single unparenthesized A1/J-00-like token is commonly a mathematical
// variable or a degraded OCR fragment. Do not promote it to an appendix
// equation without corroboration from another independent label in the same
// compact/hyphen family. Explicit parenthesized tags and dotted appendix
// families retain the existing conservative margin/geometry classifier.
function suppressIsolatedBareAppendixTokens(index) {
  const familyCounts = new Map();
  for (const label of index.keys()) {
    const parsed = parsedEquationNumber(label);
    if (!parsed?.appendix || parsed.separator === '.') continue;
    const key = equationSequenceFamilyKey(parsed);
    familyCounts.set(key, (familyCounts.get(key) || 0) + 1);
  }
  for (const [label, records] of [...index.entries()]) {
    const parsed = parsedEquationNumber(label);
    if (!parsed?.appendix || parsed.separator === '.') continue;
    if ((familyCounts.get(equationSequenceFamilyKey(parsed)) || 0) >= 2) continue;
    if ((records || []).length && (records || []).every((record) => record?.bareSource === true && record?.explicitParenthesized !== true)) {
      index.delete(label);
    }
  }
  return index;
}

function suppressSparseAmbiguousOcrEquationFamilies(index) {
  // Reapply OCR reliability at the final index boundary because later
  // supplementation/recovery passes can otherwise resurrect a candidate that
  // the primary classifier rejected on a low-quality page. Clean handwritten
  // pages can also receive deceptively strong page confidence while
  // hallucinating one or two parenthesized numbers. Prefer an empty index to a
  // precise-looking false target when there is no document-level numbering
  // family behind such ambiguous OCR evidence.
  for (const [label, records] of [...index.entries()]) {
    if (!parsedEquationNumber(label)) continue;
    const kept = (records || []).filter((record) => {
      // Apply this geometry safeguard to both OCR and native hidden-text
      // candidates. Late two-column recovery can otherwise resurrect a bare
      // section/page marker that the primary classifier already rejected.
      if (record?.bareSource && record?.standaloneTag && Number(record?.ratio) <= 0.040) return false;
      if (!record?.ocrSource || record?.nativeGapCorroborated) return true;
      const pageConfidence = Number(record.ocrPageConfidence);
      // Keep the v316 page-quality contract authoritative even after
      // two-column supplementation and sequence recovery.
      if (Number.isFinite(pageConfidence) && pageConfidence < 50) return false;
      // A bare dotted/hyphen token at the extreme top edge with no nearby
      // display math is a running page/section marker, not an equation target.
      if (record.bareSource && record.standaloneTag && Number(record.ratio) <= 0.035 && !record.nearbyDisplayMath) return false;
      return true;
    });
    if (kept.length) index.set(label, kept);
    else index.delete(label);
  }

  // Determine numbering-family support only after the final reliability pass;
  // candidates that were just rejected must not make a surviving hallucination
  // look like part of a real document-wide sequence.
  const ocrNumericLabels = new Set();
  for (const [label, records] of index) {
    if (!parsedEquationNumber(label)) continue;
    if ((records || []).some((record) => record?.ocrSource)) ocrNumericLabels.add(label);
  }
  if (ocrNumericLabels.size >= 3) return;

  for (const [label, records] of [...index.entries()]) {
    if (!parsedEquationNumber(label)) continue;
    const kept = (records || []).filter((record) => {
      if (!record?.ocrSource || record?.nativeGapCorroborated) return true;
      const pageConfidence = Number(record.ocrPageConfidence);
      // Mid-confidence OCR is usable, but one or two non-standalone numeric
      // labels are too weak to establish an equation-numbering system.
      if (!record.standaloneTag && Number.isFinite(pageConfidence) && pageConfidence < 65) return false;
      // A full-page scan can OCR a mathematical exponent as "(2)" on an
      // interior display line. If the entire OCR document has fewer than three
      // distinct numeric labels, a non-standalone integer tag needs the outer
      // equation margin or an independently established local-column family.
      // Nearby mathematical symbols alone are not enough: they are exactly
      // what makes a formula exponent look like a numbered display.
      const pureInteger = Boolean(parsedEquationNumber(label) && !parsedEquationNumber(label).prefix);
      const strongOuterEdge = equationNumberingSide === 'left'
        ? Number(record.candidateXEndRatio) <= 0.19
        : Number(record.candidateXStartRatio) >= 0.82;
      if (pureInteger && !record.standaloneTag && !record.confirmedLocalIntegerFamily
          && !record.equationTwoColumn && !strongOuterEdge) return false;
      // Even an isolated parenthesized token can look convincing on clean
      // handwriting. Without a numbering family, retain it only when the
      // existing equation-confidence model supplies strong independent support.
      if (record.standaloneTag && Number(record.confidence) < 30) return false;
      return true;
    });
    if (kept.length) index.set(label, kept);
    else index.delete(label);
  }
}
function suppressSparseAmbiguousNativeBareEquationFamilies(index) {
  // A scan-backed/hidden text layer can expose ordinary decimal values as
  // standalone tokens.  Do not let one or two unsupported interior decimals
  // establish an Equation numbering system merely because they happen to look
  // like dotted labels.  Preserve real small documents when the tag is on the
  // strong outer numbering margin, has nearby display math, or has any
  // explicit/strong equation evidence.
  const numeric = [];
  let strongEvidence = 0;
  for (const [label, records] of index.entries()) {
    if (!parsedEquationNumber(label)) continue;
    numeric.push({ label, records: records || [] });
    if ((records || []).some((record) => (
      record?.ocrSource
      || record?.explicitParenthesized
      || record?.nearbyDisplayMath
      || (Number(record?.mathSignals) || 0) >= 2
      || !record?.bareSource
      || !record?.standaloneTag
    ))) strongEvidence += 1;
  }
  if (!numeric.length || numeric.length > 2 || strongEvidence > 0) return index;
  for (const { label, records } of numeric) {
    const allUnsupportedInteriorBare = records.length > 0 && records.every((record) => {
      if (record?.ocrSource || !record?.bareSource || !record?.standaloneTag || record?.nearbyDisplayMath || (Number(record?.mathSignals) || 0) > 0) return false;
      const strongOuterMargin = equationNumberingSide === 'left'
        ? Number(record?.candidateXEndRatio) <= 0.16
        : Number(record?.candidateXStartRatio) >= 0.87;
      return !strongOuterMargin;
    });
    if (allUnsupportedInteriorBare) index.delete(label);
  }
  return index;
}

function reconcileOcrEquationSequenceOrder(index) {
  const byPrefix = new Map();
  for (const [label, candidates] of index.entries()) {
    const parsed = parsedEquationNumber(label);
    if (!parsed?.prefix || !(candidates || []).some((item) => Boolean(item?.ocrSource))) continue;
    const candidate = chooseCanonicalEquationCandidate(candidates);
    if (!candidate) continue;
    const familyKey = equationSequenceFamilyKey(parsed);
    const list = byPrefix.get(familyKey) || [];
    list.push({ label, parsed, candidate });
    byPrefix.set(familyKey, list);
  }
  for (const entries of byPrefix.values()) {
    if (entries.length < 4) continue;
    entries.sort((a, b) => equationDocumentPosition(a.candidate) - equationDocumentPosition(b.candidate));
    let last = -1;
    for (const entry of entries) {
      if (last >= 0 && entry.parsed.last < last) {
        index.delete(entry.label);
        continue;
      }
      last = Math.max(last, entry.parsed.last);
    }
  }
  return index;
}



function equationNativeImageGapPlan(index, pageCount, referenceEvidence = []) {
  const byPrefix = new Map();
  for (const [label, candidates] of index.entries()) {
    const parsed = parsedEquationNumber(label);
    if (!parsed || !Number.isInteger(parsed.last) || parsed.last < 1) continue;
    const candidate = chooseCanonicalEquationCandidate(candidates);
    if (!candidate || candidate.ocrSource) continue;
    const familyKey = equationSequenceFamilyKey(parsed);
    const list = byPrefix.get(familyKey) || [];
    list.push({ label, parsed, candidate });
    byPrefix.set(familyKey, list);
  }

  const expectedByPage = new Map();
  const baselinePriorityPages = new Set();
  const addExpected = (pageNum, label, baselinePriority = false) => {
    const page = Number(pageNum);
    if (!Number.isInteger(page) || page < 1 || page > pageCount) return;
    const labels = expectedByPage.get(page) || new Set();
    labels.add(label);
    expectedByPage.set(page, labels);
    if (baselinePriority) baselinePriorityPages.add(page);
  };
  const expectedLabel = (parsed, last) => parsed.prefix
    ? `(${parsed.prefix}${parsed.separator ?? '.'}${last})`
    : `(${last})`;

  for (const entries0 of byPrefix.values()) {
    if (entries0.length < 4) continue;
    const byLast = new Map();
    const entries = [...entries0].sort((a, b) => equationDocumentPosition(a.candidate) - equationDocumentPosition(b.candidate));
    for (const entry of entries) if (!byLast.has(entry.parsed.last)) byLast.set(entry.parsed.last, entry);
    const family = [...byLast.values()].sort((a, b) => equationDocumentPosition(a.candidate) - equationDocumentPosition(b.candidate));
    if (family.length < 4) continue;

    const first = family[0];
    const integerFamily = !first.parsed.prefix;
    if (integerFamily) {
      const numbers = family.map((entry) => entry.parsed.last);
      const span = Math.max(...numbers) - Math.min(...numbers) + 1;
      const establishedIntegerFamily = family.length >= 8 && Math.min(...numbers) <= 2 && Math.max(...numbers) >= 8 && span <= family.length + 3;
      if (!establishedIntegerFamily) continue;
      for (let i = 0; i + 1 < family.length; i += 1) {
        const left = family[i];
        const right = family[i + 1];
        if (right.parsed.last - left.parsed.last !== 2) continue;
        const pageDelta = Number(right.candidate.page) - Number(left.candidate.page);
        if (pageDelta < 0 || pageDelta > 1) continue;
        const missingLabel = expectedLabel(left.parsed, left.parsed.last + 1);
        addExpected(right.candidate.page, missingLabel);
        if (pageDelta === 0) addExpected(left.candidate.page, missingLabel);
      }
      continue;
    }

    if ((first.parsed.last >= 3 && first.parsed.last <= 4) || (first.parsed.last === 2 && family.length >= 5)) {
      // A mature family beginning at .3/.4 is strong evidence that the first
      // one to three printed labels may have disappeared from the hidden text
      // layer. Consult only the first anchor page and its immediate predecessor;
      // image OCR must still read the exact missing label before it is added.
      for (let missing = 1; missing < first.parsed.last; missing += 1) {
        const label = expectedLabel(first.parsed, missing);
        addExpected(first.candidate.page, label, true);
        addExpected(Number(first.candidate.page) - 1, label, true);
      }
    }

    for (let i = 0; i + 1 < family.length; i += 1) {
      const left = family[i];
      const right = family[i + 1];
      const gap = right.parsed.last - left.parsed.last;
      const leftPage = Number(left.candidate.page);
      const rightPage = Number(right.candidate.page);
      const pageDelta = rightPage - leftPage;
      const ordinaryGap = gap >= 2 && gap <= 4 && pageDelta >= 0 && pageDelta <= 2;
      const establishedLongGap = gap >= 5 && gap <= 12 && family.length >= 10 && pageDelta >= 0 && pageDelta <= 5;
      if (!ordinaryGap && !establishedLongGap) continue;
      // Same-page holes stay the primary path. Established scan-backed families
      // may lose a longer run from the hidden text layer; image OCR still has
      // to read every exact label on the equation-number margin before adding it.
      if (pageDelta > 0 && family.length < 4) continue;
      for (let missing = left.parsed.last + 1; missing < right.parsed.last; missing += 1) {
        const label = expectedLabel(left.parsed, missing);
        for (let candidatePage = leftPage; candidatePage <= rightPage; candidatePage += 1) {
          addExpected(candidatePage, label, pageDelta === 0);
        }
      }
    }
  }

  // Freeze the legacy/native v326 posterior plan before adding any recovery
  // hints derived from rejected prose references. This keeps the established
  // 24-page OCR budget intact; reference recovery may only add a small,
  // separately bounded supplement and can never crowd out an existing page.
  const byEvidence = (a, b) => (expectedByPage.get(b)?.size || 0) - (expectedByPage.get(a)?.size || 0) || a - b;
  const basePriorityPages = [...expectedByPage.keys()].filter((page) => baselinePriorityPages.has(page)).sort(byEvidence);
  const baseSupplementalPages = [...expectedByPage.keys()].filter((page) => !baselinePriorityPages.has(page)).sort(byEvidence);
  const basePages = [...basePriorityPages, ...baseSupplementalPages].slice(0, 24);

  // A text layer can preserve only an inline prose reference to a printed
  // equation while dropping the real margin tag. Keep such references out of
  // the Equation index, but use the earliest one as a bounded *query* for image
  // OCR. Exact OCR of the missing label is still required before publication.
  // Normally require an established native family or two distinct rejected
  // references. A single reference is also enough when it is a candidate that
  // v326 would itself have indexed; exact image OCR still has to confirm the
  // printed tag. Never do this for bare integer numbering, where prose
  // enumerations are much more ambiguous.
  const referenceRecoveryPages = new Set();
  const referencePageScores = new Map();
  const addReferenceExpected = (pageNum, label, distance) => {
    const page = Number(pageNum);
    if (!Number.isInteger(page) || page < 1 || page > pageCount) return;
    addExpected(page, label);
    referenceRecoveryPages.add(page);
    // Prefer pages supported by several rejected labels, then the pages nearest
    // to the prose reference. The exact label still has to be read by OCR.
    const score = Math.max(1, 3 - Number(distance || 0));
    referencePageScores.set(page, (referencePageScores.get(page) || 0) + score);
  };
  const referenceFamilies = new Map();
  for (const record of referenceEvidence || []) {
    const parsed = record?.numeric || parsedEquationNumber(record?.label);
    if (!parsed?.prefix || !Number.isInteger(parsed.last)) continue;
    const key = equationSequenceFamilyKey(parsed);
    const byLabel = referenceFamilies.get(key) || new Map();
    const existing = byLabel.get(record.label);
    if (!existing || equationDocumentPosition(record) < equationDocumentPosition(existing)) byLabel.set(record.label, record);
    referenceFamilies.set(key, byLabel);
  }
  for (const [familyKey, byLabel] of referenceFamilies) {
    const nativeCount = new Set((byPrefix.get(familyKey) || []).map((entry) => entry.label)).size;
    const strongRejectedReference = [...byLabel.values()].some((record) => Boolean(record.referenceRecoveryStrong));
    if (nativeCount < 2 && byLabel.size < 2 && !strongRejectedReference) continue;
    for (const [label, record] of byLabel) {
      if (index.has(label)) continue;
      const referencePage = Number(record.page);
      if (!Number.isInteger(referencePage)) continue;
      // In old journal scans the printed tag is normally on the same page as
      // its first surviving prose reference or on one of the two preceding
      // pages. Wider windows add cost without useful localization evidence.
      for (let distance = 0; distance <= 2; distance += 1) {
        addReferenceExpected(referencePage - distance, label, distance);
      }
    }
  }

  // Preserve every page selected by the v326/native gap plan. A document with
  // strong rejected-reference evidence may add at most twelve tightly localized
  // pages (three pages per reference cluster in the common case), so the
  // posterior image pass remains bounded and previous recovery coverage is not
  // displaced.
  const basePageSet = new Set(basePages);
  const referencePages = [...referenceRecoveryPages]
    .filter((page) => !basePageSet.has(page))
    .sort((a, b) => (referencePageScores.get(b) || 0) - (referencePageScores.get(a) || 0) || a - b)
    .slice(0, 12);
  const pages = [...new Set([...basePages, ...referencePages])];
  // A first appendix equation can be missing even though the native text
  // preserves its immediate successors. An established A.2, A.3, A.4, A.5
  // family with A.2 and A.3 on the same page warrants a *query* for A.1.
  // Preserve the older 24-page gap plan and the 12-page reference supplement;
  // permit at most four ADDITIONAL leading-appendix pages per document.
  let extraLeadingPages = 0;
  for (const entries of byPrefix.values()) {
    if (entries.length < 4) continue;
    const distinct = new Map();
    for (const entry of entries) {
      const existing = distinct.get(entry.parsed.last);
      if (!existing || equationDocumentPosition(entry.candidate) < equationDocumentPosition(existing.candidate)) {
        distinct.set(entry.parsed.last, entry);
      }
    }
    const family = [...distinct.values()].sort((a, b) => equationDocumentPosition(a.candidate) - equationDocumentPosition(b.candidate));
    const first = family[0];
    const second = family[1];
    if (!first?.parsed.appendix || first.parsed.last !== 2 || first.parsed.separator !== '.' ||
        first.parsed.suffix || second?.parsed.last !== 3 ||
        Number(first.candidate.page) !== Number(second.candidate.page)) continue;
    const label = expectedLabel(first.parsed, 1);
    const page = Number(first.candidate.page);
    if (index.has(label) || !Number.isInteger(page) || page < 1 || page > pageCount) continue;
    if (!pages.includes(page)) {
      if (extraLeadingPages >= 4) continue;
      pages.push(page);
      extraLeadingPages += 1;
    }
    // Only an actually observed, geometry-validated margin label can enter
    // the Equation index. The sequence itself is never published as evidence.
    addExpected(page, label);
  }
  pages.sort((a, b) => a - b);
  const allowedPages = new Set(pages);
  for (const page of [...expectedByPage.keys()]) if (!allowedPages.has(page)) expectedByPage.delete(page);
  return { pages, expectedByPage };
}

async function equationPageContainsRasterImage(sourceDoc, pageNum) {
  try {
    const page = await sourceDoc.getPage(pageNum);
    const opList = await page.getOperatorList();
    const ops = pdfjsLib?.OPS || {};
    const imageOps = new Set([
      ops.paintImageMaskXObject,
      ops.paintImageMaskXObjectGroup,
      ops.paintImageXObject,
      ops.paintInlineImageXObject,
      ops.paintInlineImageXObjectGroup,
      ops.paintImageXObjectRepeat,
    ].filter(Number.isFinite));
    return imageOps.size > 0 && (opList?.fnArray || []).some((fn) => imageOps.has(fn));
  } catch (_) {
    return false;
  }
}

async function equationDocumentLooksImageBacked(sourceDoc, index) {
  if (!sourceDoc?.numPages || documentTextMode !== 'native' || documentOcrActive) return false;
  const anchorPages = [];
  for (const candidates of index.values()) {
    const candidate = chooseCanonicalEquationCandidate(candidates);
    const page = Number(candidate?.page);
    if (Number.isInteger(page) && page >= 1 && page <= sourceDoc.numPages) anchorPages.push(page);
  }
  if (!anchorPages.length) return false;
  anchorPages.sort((a, b) => a - b);
  const anchor = anchorPages[Math.floor(anchorPages.length / 2)];
  const sample = [...new Set([anchor - 1, anchor, anchor + 1]
    .map((page) => Math.min(sourceDoc.numPages, Math.max(1, page))))];
  if (sample.length < 2) return false;
  let imagePages = 0;
  for (const pageNum of sample) if (await equationPageContainsRasterImage(sourceDoc, pageNum)) imagePages += 1;
  // Requiring every adjacent sample page to contain raster content keeps this
  // path away from ordinary born-digital papers that merely contain a figure.
  return imagePages === sample.length;
}

function equationSupplementalOcrPagePlan(sourceDoc, index) {
  const pageCount = Math.max(0, Number(sourceDoc?.numPages) || 0);
  if (!pageCount) return [];
  if (pageCount <= 60) return Array.from({ length: pageCount }, (_, index) => index + 1);
  const anchors = [];
  for (const candidates of index.values()) {
    const candidate = chooseCanonicalEquationCandidate(candidates);
    const page = Number(candidate?.page);
    if (Number.isInteger(page) && page >= 1 && page <= pageCount) anchors.push(page);
  }
  const pages = new Set();
  for (const anchor of anchors) {
    for (let delta = -12; delta <= 12; delta += 1) {
      const page = anchor + delta;
      if (page >= 1 && page <= pageCount) pages.add(page);
    }
  }
  // Keep automatic image assistance bounded on long scanned books. Full
  // document OCR remains the explicit path when a much larger scan needs it.
  return [...pages].sort((a, b) => a - b).slice(0, 48);
}

function remapEquationMarginOcrLine(line, side, marginFraction) {
  const fraction = Math.min(0.48, Math.max(0.12, Number(marginFraction) || 0.38));
  const offset = side === 'right' ? 1 - fraction : 0;
  const mapX = (value) => Math.min(1, Math.max(0, offset + (Number(value) || 0) * fraction));
  return {
    ...line,
    ocrSource: true,
    supplementalEquationOcr: true,
    xStartRatio: mapX(line.xStartRatio),
    xEndRatio: mapX(line.xEndRatio),
    parts: (line.parts || []).map((part) => ({
      ...part,
      xStartRatio: mapX(part.xStartRatio),
      xEndRatio: mapX(part.xEndRatio),
    })),
  };
}

// The equation pipeline is progressive: native text completes first, then optional
// selected-page image OCR. These diagnostics describe work performed, NOT 100%
// content-detection accuracy or full-page OCR coverage.
function equationDetectionNowMs() {
  return typeof performance !== 'undefined' && typeof performance.now === 'function' ? performance.now() : Date.now();
}
function resetEquationDetectionProgress() {
  equationDetectionGeneration += 1;
  equationDetectionProgress = { phase: 'idle' };
  equationDetectionLastPaint = 0;
  updateEquationDetectionStatus(true);
}
function updateEquationDetectionProgress(update, generation = equationDetectionGeneration, force = false) {
  if (generation !== equationDetectionGeneration) return false;
  equationDetectionProgress = { ...equationDetectionProgress, ...update };
  updateEquationDetectionStatus(force);
  return true;
}
function formatEquationDetectionTime(ms) {
  return `${(Math.max(0, Number(ms) || 0) / 1000).toFixed(2)}s`;
}
function equationDetectionSummary(state) {
  const phase = state?.phase || 'idle';
  if (phase === 'idle') return ['', ''];
  // Keep the narrow sidebar a single line. Detailed counts, coverage, and
  // timings remain available on hover rather than widening the contents pane.
  if (phase === 'saved') return [t('Saved · not rescanned', '已保存 · 未重扫'), t('Saved index · not rescanned', '已保存索引 · 尚未重新扫描')];
  if (phase === 'unavailable') return [t('No text · full OCR needed', '无文本 · 需全文 OCR'), t('Text unavailable · full-document OCR required', '文本不可用 · 需要全文 OCR')];
  if (phase === 'failed') return [t('Index failed · see console', '索引失败 · 查看控制台'), t('Equation indexing failed · see console', '公式索引失败 · 请查看控制台')];
  const native = state.nativeTotal > 0
    ? t(`Text ${state.nativeDone || 0}/${state.nativeTotal}`, `文本 ${state.nativeDone || 0}/${state.nativeTotal}`)
    : t('Text scan', '文本扫描');
  const labels = Number.isInteger(state.labels) ? t(`${state.labels} labels`, `${state.labels} 编号`) : '';
  const scanned = Number(state.ocrTotal || 0);
  const ocr = scanned ? t(`equation-margin OCR ${state.ocrDone || 0}/${scanned} selected pages out of ${state.documentPages || '?'} PDF pages (not full-document OCR)`, `公式编号边缘 OCR 已完成 ${state.ocrDone || 0}/${scanned} 选定页；PDF 共 ${state.documentPages || '?'} 页（并非全文 OCR）`) : '';
  const retry = Number(state.retryTotal || 0)
    ? t(`gap retries ${state.retryDone || 0}/${state.retryTotal}`, `缺口重试 ${state.retryDone || 0}/${state.retryTotal}`) : '';
  const gain = scanned ? t(`+${state.recovered || 0} recovered`, `补回 ${state.recovered || 0} 个`) : '';
  const failed = Number(state.failedPages || 0);
  const selected = scanned > 0 && scanned < Number(state.documentPages || 0);
  const head = phase === 'native' ? t('Reading text', '读取文本')
    : phase === 'planning' ? t('Checking for image assistance', '检查图像辅助')
    : phase === 'ocr' ? t('Reading equation margins', '读取公式边缘')
    : phase === 'validating' ? t('Validating recovered labels', '验证补回编号')
    : phase === 'partial' ? t('Finished with OCR issues', '已结束，部分 OCR 失败')
    : scanned ? t('Equation image check finished', '公式图像检查完成') : t('Equation text check finished', '公式文本检查完成');
  const parts = [head, native, ocr, retry, labels, gain];
  if (failed) parts.push(t(`${failed} failed pages`, `${failed} 页失败`));
  if (selected) parts.push(t('selected coverage only', '仅覆盖选定页面'));

  // Prioritize the stage, incomplete/failed coverage, and recovered labels
  // before less urgent counts, so narrow panes truncate the least critical end.
  const shortHead = phase === 'native' ? native
    : phase === 'planning' ? t('OCR plan', 'OCR 计划')
    : phase === 'ocr' ? t(`Eq OCR ${state.ocrDone || 0}/${scanned}`, `公式 OCR ${state.ocrDone || 0}/${scanned}`)
    : phase === 'validating' ? t('Checking', '校验中')
    : phase === 'partial' ? t('OCR partial', 'OCR 部分失败')
    : scanned ? t('Eq OCR done', '公式 OCR 已完成') : t('Text done', '文本已读取');
  const shortParts = [shortHead];
  if (failed) shortParts.push(t(`${failed} failed`, `${failed} 页失败`));
  if (scanned && phase !== 'ocr') shortParts.push(t(`${state.ocrDone || 0}/${scanned} pages`, `${state.ocrDone || 0}/${scanned} 页`));
  if (!scanned && phase !== 'native' && state.nativeTotal > 0) shortParts.push(native);
  if (selected) shortParts.push(t('selected', '选页'));
  if (scanned && Number(state.recovered || 0)) shortParts.push(t(`+${state.recovered}`, `+${state.recovered}`));
  if (phase === 'ocr' && Number(state.retryTotal || 0)) shortParts.push(t(`retry ${state.retryDone || 0}/${state.retryTotal}`, `重试 ${state.retryDone || 0}/${state.retryTotal}`));
  // The adjacent equation-count badge already shows total labels; do not duplicate it here.

  const detailed = [
    t('Measured local timings (approximate):', '本地测量耗时（近似）：'),
    t(`text ${formatEquationDetectionTime(state.nativeMs)}`, `文本 ${formatEquationDetectionTime(state.nativeMs)}`),
    t(`PDF rendering ${formatEquationDetectionTime(state.renderMs)}`, `PDF 渲染 ${formatEquationDetectionTime(state.renderMs)}`),
    t(`OCR recognition ${formatEquationDetectionTime(state.recognizeMs)}`, `OCR 识别 ${formatEquationDetectionTime(state.recognizeMs)}`),
    t(`OCR worker setup ${formatEquationDetectionTime(state.ocrSetupMs)}`, `OCR 初始化 ${formatEquationDetectionTime(state.ocrSetupMs)}`),
    t(`gap retries ${formatEquationDetectionTime(state.retryMs)}`, `缺口重试 ${formatEquationDetectionTime(state.retryMs)}`),
    t(`UI updates ${formatEquationDetectionTime(state.uiMs)}`, `界面更新 ${formatEquationDetectionTime(state.uiMs)}`),
    t(`index validation ${formatEquationDetectionTime(state.validationMs)}`, `索引校验 ${formatEquationDetectionTime(state.validationMs)}`),
    t(`elapsed ${formatEquationDetectionTime(state.elapsedMs)}`, `总历时 ${formatEquationDetectionTime(state.elapsedMs)}`),
  ];
  return [shortParts.join(' · '), `${parts.filter(Boolean).join(' · ')}\n${detailed.join(' · ')}`];
}
function refreshEquationForceOcrButton() {
  // Isolated equation-status probes may omit both button references.
  const settingsAction = typeof detectionScanMarginsButton !== 'undefined' && detectionScanMarginsButton;
  const equationAction = typeof equationForceOcrButton !== 'undefined' && equationForceOcrButton;
  if (!settingsAction && !equationAction) return;
  const active = Boolean(pdfDoc && documentTextFeaturesAvailable());
  const busy = Boolean(equationIndexBuildPromise || equationImageAssistPromise || documentOcrActive || documentOcrBusy);
  // The same scan is exposed in both Equations and Settings. Keep both actions
  // disabled while a scan is running, instead of accepting no-op clicks.
  if (settingsAction) settingsAction.disabled = !active || busy;
  if (!equationAction) return;
  equationForceOcrButton.disabled = !active || busy;
  equationForceOcrButton.title = t('Manually recheck equation labels across all pages (may take a while)', '手动重新检查全部页面的公式编号（可能需要较长时间）');
  equationForceOcrButton.setAttribute('aria-label', t('Force equation-label image OCR', '强制进行公式编号图像 OCR'));
}
async function forceEquationImageOcr() {
  if (!pdfDoc || !documentTextFeaturesAvailable() || equationIndexBuildPromise || equationImageAssistPromise || documentOcrActive || documentOcrBusy) return;
  // Explicit image rechecks may add labels but never erase previous detections.
  const sourceDoc = pdfDoc;
  const sourceKey = currentFileKey;
  const previousEquations = new Map(equationAutomaticLabelIndex || equationLabelIndex || []);
  equationLabelIndex = null;
  equationAutomaticLabelIndex = null;
  equationIndexKnownCount = null;
  resetEquationDetectionProgress();
  const promise = buildEquationLabelIndex({ forceImageOcr: true });
  equationIndexBuildPromise = promise;
  refreshEquationForceOcrButton();
  try {
    await promise;
    if (pdfDoc === sourceDoc && currentFileKey === sourceKey && previousEquations.size) {
      if (!(equationAutomaticLabelIndex instanceof Map)) equationAutomaticLabelIndex = new Map();
      for (const [label, candidates] of previousEquations) {
        if (!equationAutomaticLabelIndex.has(label)) equationAutomaticLabelIndex.set(label, candidates);
      }
      equationLabelIndex = applyEquationEdits(equationAutomaticLabelIndex);
      renderEquationIndex();
      persistDocumentState();
    }
  }
  catch (error) {
    console.warn('MathReader forced equation OCR failed.', error);
    updateEquationDetectionProgress({ phase: 'failed', error: String(error?.message || error) }, equationDetectionGeneration, true);
  } finally {
    if (equationIndexBuildPromise === promise) equationIndexBuildPromise = null;
    refreshEquationForceOcrButton();
  }
}
function updateEquationDetectionStatus(force = false) {
  if (!equationDetectionStatus) return;
  refreshEquationForceOcrButton();
  const state = equationDetectionProgress;
  const now = equationDetectionNowMs();
  if (!force && now - equationDetectionLastPaint < 400) return;
  equationDetectionLastPaint = now;
  const [message, tooltip] = equationDetectionSummary(state);
  if (equationDetectionStatus.textContent !== message) equationDetectionStatus.textContent = message;
  equationDetectionStatus.title = tooltip;
  equationDetectionStatus.dataset.phase = ['native','planning','ocr','validating'].includes(state.phase)
    ? 'running' : ['failed','partial'].includes(state.phase) ? 'warning' : 'done';
}
function logEquationDetectionTiming(state, sourceKey) {
  // No telemetry or remote calls. One compact console record per finished run.
  console.info('MathReader equation indexing (local timing)', {
    document: String(sourceKey || '').slice(0, 100),
    nativePages: state.nativeDone || 0,
    plannedImagePages: state.ocrTotal || 0,
    processedImagePages: state.ocrDone || 0,
    retries: state.retryDone || 0,
    failedPages: state.failedPages || 0,
    recoveredLabels: state.recovered || 0,
    elapsedMs: Math.round(state.elapsedMs || 0),
    nativeMs: Math.round(state.nativeMs || 0),
    pdfRenderMs: Math.round(state.renderMs || 0),
    ocrRecognitionMs: Math.round(state.recognizeMs || 0),
    ocrSetupMs: Math.round(state.ocrSetupMs || 0),
    numericRetryMs: Math.round(state.retryMs || 0),
    uiUpdateMs: Math.round(state.uiMs || 0),
    validationMs: Math.round(state.validationMs || 0),
  });
}

async function equationMarginOcrLines(sourceDoc, pageNum, side, worker, { marginFraction = 0.28, onTiming = null, existingCanvas = null } = {}) {
  const started = equationDetectionNowMs();
  let fullCanvas = existingCanvas;
  if (!fullCanvas) {
    const page = await sourceDoc.getPage(pageNum);
    const base = page.getViewport({ scale: 1 });
    const scale = Math.max(2.4, Math.min(3.6, 3200 / Math.max(1, base.width, base.height)));
    const viewport = page.getViewport({ scale });
    fullCanvas = document.createElement('canvas');
    fullCanvas.width = Math.max(1, Math.ceil(viewport.width));
    fullCanvas.height = Math.max(1, Math.ceil(viewport.height));
    const fullContext = fullCanvas.getContext('2d', { alpha: false });
    fullContext.fillStyle = '#fff';
    fullContext.fillRect(0, 0, fullCanvas.width, fullCanvas.height);
    await page.render({ canvasContext: fullContext, viewport }).promise;
  }

  // Equation labels live at the outer edge. A narrow crop is both faster and
  // less likely to OCR inline prose references as candidate labels.
  const sourceHeight = Math.max(1, fullCanvas.height);
  const cropWidth = Math.max(1, Math.ceil(fullCanvas.width * marginFraction));
  const cropX = side === 'right' ? Math.max(0, fullCanvas.width - cropWidth) : 0;
  const cropCanvas = document.createElement('canvas');
  cropCanvas.width = cropWidth;
  cropCanvas.height = fullCanvas.height;
  const cropContext = cropCanvas.getContext('2d', { alpha: false });
  cropContext.fillStyle = '#fff';
  cropContext.fillRect(0, 0, cropCanvas.width, cropCanvas.height);
  cropContext.drawImage(fullCanvas, cropX, 0, cropWidth, fullCanvas.height, 0, 0, cropWidth, fullCanvas.height);

  const rendered = equationDetectionNowMs();
  let result;
  try {
    result = await worker.recognize(cropCanvas, {}, { hocr: true });
  } finally {
    if (typeof onTiming === 'function') {
      try { onTiming({ renderMs: rendered - started, recognizeMs: equationDetectionNowMs() - rendered }); } catch (_) {}
    }
    // Do not mutate a caller-owned canvas. Preserve the source dimensions
    // until OCR coordinates have been normalized to the whole PDF page.
    if (!existingCanvas) fullCanvas.width = 1;
    if (!existingCanvas) fullCanvas.height = 1;
    cropCanvas.width = 1;
    cropCanvas.height = 1;
  }
  const record = pageRecordFromHocr(result?.data?.hocr || '', result?.data?.text || '', cropWidth, sourceHeight, pageNum);
  // A plain-text OCR fallback has no hOCR boxes. Its synthetic y-ratios may be
  // useful for reading order, but are not valid *equation navigation* evidence.
  return (record.lines || []).filter((line) => line.geometryEstimated !== true)
    .map((line) => remapEquationMarginOcrLine(line, side, marginFraction));
}

// Some original printed mathematics has alphabetic appendix equation tags
// that disappear from the PDF text layer (Giusti p231, printed (A.1)). The
// numeric-only gap retry below cannot verify those tags. Accept a retry only
// when OCR actually reads the entire parenthesized appendix label on the
// original margin, beside *observed* display math. Neither gaps nor ambiguous
// confusables (e.g. OCR "Al") are evidence for an equation label.
function equationExpectedAppendixOcrRecord(line, page, expectedLabel) {
  const parsed = parsedEquationNumber(expectedLabel);
  if (!parsed?.appendix) return null;
  const text = String(line?.text || '');
  const candidates = equationLabelCandidatesInLine(text).filter((candidate) =>
    candidate.label === expectedLabel && !candidate.bare && !candidate.sequenceOnly
    && !candidate.attachedFunctionCall);
  if (!candidates.length) return null;
  const ratio = Number(line?.ratio);
  if (!Number.isFinite(ratio) || ratio < 0.07 || ratio > 0.93) return null;
  for (const candidate of candidates) {
    const before = text.slice(0, candidate.index).trim();
    const after = text.slice(candidate.end).trim();
    const remainder = equationNumberingSide === 'left' ? after : before;
    // A heading, citation or bare isolated margin token cannot pass: the
    // source OCR line must itself contain a mathematical operator or relation
    // outside the tag. This deliberately sacrifices uncertain recall.
    if (!remainder || !/[=<>≤≥≠≈≡∈∉∑∏∫√∂∇^_+−×÷]/u.test(remainder)
        || (remainder.match(/\b[A-Za-z]{3,}\b/g) || []).length > 2) continue;
    // OCR often reduces a printed ≤/≥ to ASCII </>. Only this
    // exact-tag appendix retry may count that observed relation as math;
    // generic equation detection remains unchanged.
    const record = equationSupplementalRecord(line, page, 0, [line], candidate,
      { countAsciiInequality: /[<>]/u.test(remainder) });
    if (!record || !record.explicitParenthesized) continue;
    const start = Number(record.candidateXStartRatio);
    const end = Number(record.candidateXEndRatio);
    if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end > 1 || end <= start) continue;
    const atOuterMargin = equationNumberingSide === 'left'
      ? record.candidateAtLineStart && end <= 0.22
      : record.candidateAtLineEnd && start >= 0.78;
    if (!atOuterMargin || equationReferenceProseContext(text)) continue;
    return { ...record, appendixGapCorroborated: true, ocrGeometryMeasured: true };
  }
  return null;
}

function equationExpectedNumericOcrRecord(line, page, expectedLabel) {
  const numeric = parsedEquationNumber(expectedLabel);
  if (numeric?.appendix) return null; // Numeric-only retry cannot verify an alphabetic prefix.
  if (!numeric || !Number.isInteger(numeric.last)) return null;
  const core = numeric.prefix
    ? `${numeric.prefix}${numeric.separator || '.'}${numeric.last}`
    : String(numeric.last);
  const normalizedText = String(line?.text || '')
    .normalize('NFKC')
    .replace(/[．·•]/g, '.')
    .replace(/\s+/g, '');
  if (!normalizedText.includes(core)) return null;
  // The retry OCR is deliberately numeric-only. Require the whole OCR line to
  // reduce to the expected digits, so a nearby page number or second label
  // cannot corroborate the query accidentally. Parentheses may be lost by OCR.
  const observedDigits = normalizedText.replace(/\D/g, '');
  const expectedDigits = core.replace(/\D/g, '');
  if (!expectedDigits || observedDigits !== expectedDigits) return null;
  if (normalizedText.includes('.') !== core.includes('.')) return null;
  const sideAligned = equationNumberingSide === 'left'
    ? Number(line?.xEndRatio || 0) <= 0.22
    : Number(line?.xStartRatio || 0) >= 0.78;
  if (!sideAligned) return null;
  return {
    label: expectedLabel,
    page,
    ratio: Number(line?.ratio || 0),
    text: String(line?.text || ''),
    xStartRatio: Number(line?.xStartRatio || 0),
    xEndRatio: Number(line?.xEndRatio || 0),
    candidateXStartRatio: Number(line?.xStartRatio || 0),
    candidateXEndRatio: Number(line?.xEndRatio || 0),
    numeric,
    bareSource: false,
    sequenceOnly: false,
    explicitParenthesized: /[()]/.test(normalizedText),
    candidateAtLineStart: true,
    candidateAtLineEnd: true,
    standaloneTag: true,
    nearbyDisplayMath: false,
    nearbyHeadingContext: false,
    axisNumericCluster: false,
    mathSignals: 0,
    ocrSource: true,
    supplementalEquationOcr: true,
    numericGapCorroborated: true,
    confidence: 24,
  };
}

function equationSupplementalNumericRetryQueries(records, pageCount) {
  const byPrefix = new Map();
  for (const record of records || []) {
    const parsed = record?.numeric || parsedEquationNumber(record?.label);
    if (!parsed?.prefix || parsed.appendix || !Number.isInteger(parsed.last)) continue;
    const list = byPrefix.get(parsed.prefix) || [];
    list.push({ record, parsed });
    byPrefix.set(parsed.prefix, list);
  }
  const expectedByPage = new Map();
  const addExpected = (pageNum, label) => {
    const page = Number(pageNum);
    if (!Number.isInteger(page) || page < 1 || page > pageCount) return;
    const labels = expectedByPage.get(page) || new Set();
    labels.add(label);
    expectedByPage.set(page, labels);
  };
  for (const entries0 of byPrefix.values()) {
    const byLabel = new Map();
    for (const item of entries0) {
      const existing = byLabel.get(item.record.label);
      if (!existing || equationDocumentPosition(item.record) < equationDocumentPosition(existing.record)) {
        byLabel.set(item.record.label, item);
      }
    }
    const entries = [...byLabel.values()].sort((a, b) => equationDocumentPosition(a.record) - equationDocumentPosition(b.record));
    if (entries.length < 3) continue;
    for (let i = 0; i + 1 < entries.length; i += 1) {
      const left = entries[i];
      const right = entries[i + 1];
      const gap = right.parsed.last - left.parsed.last;
      const leftPage = Number(left.record.page);
      const rightPage = Number(right.record.page);
      if (gap < 2 || gap > 4 || rightPage < leftPage || rightPage - leftPage > 2) continue;
      for (let missing = left.parsed.last + 1; missing < right.parsed.last; missing += 1) {
        const label = `(${left.parsed.prefix}${left.parsed.separator ?? '.'}${missing})`;
        for (let page = leftPage; page <= rightPage; page += 1) addExpected(page, label);
      }
    }
  }
  return expectedByPage;
}

function equationSupplementalRecord(line, page, lineIndex, lines, candidate, { countAsciiInequality = false } = {}) {
  const numeric = parsedEquationNumber(candidate.label);
  if (!numeric || !Number.isInteger(numeric.last)) return null;
  const tokenGeometry = equationCandidateTokenGeometry(line, candidate);
  const atStart = !String(line.text || '').slice(0, Math.max(0, Number(candidate.index) || 0)).trim();
  const atEnd = !String(line.text || '').slice(Math.max(0, Number(candidate.end) || 0)).trim();
  const standaloneTag = isStandaloneEquationTagLine(line, candidate.label);
  if (!standaloneTag && equationNumberingSide === 'left' && !atStart) return null;
  if (!standaloneTag && equationNumberingSide === 'right' && !atEnd) return null;
  const record = {
    label: candidate.label,
    page,
    ratio: line.ratio,
    text: line.text,
    xStartRatio: line.xStartRatio,
    xEndRatio: line.xEndRatio,
    candidateXStartRatio: tokenGeometry.xStartRatio,
    candidateXEndRatio: tokenGeometry.xEndRatio,
    numeric,
    bareSource: Boolean(candidate.bare),
    sequenceOnly: false,
    explicitParenthesized: !candidate.bare,
    candidateAtLineStart: atStart,
    candidateAtLineEnd: atEnd,
    standaloneTag,
    nearbyDisplayMath: hasNearbyDisplayMath(lines, lineIndex),
    nearbyHeadingContext: Boolean(candidate.bare) && bareEquationHasNearbyHeadingContext(lines, lineIndex),
    axisNumericCluster: false,
    mathSignals: equationLineMathSignalCount(line.text) + (countAsciiInequality && /[<>]/u.test(String(line.text || '')) ? 1 : 0),
    ocrSource: true,
    supplementalEquationOcr: true,
    attachedFunctionCall: Boolean(candidate.attachedFunctionCall),
    enumeratedConditionList: equationEnumeratedConditionListContext(lines, lineIndex, candidate),
  };
  if (record.attachedFunctionCall) return null;
  // A crop can start with an inline prose reference and make it look margin-
  // aligned. Keep it only when OCR saw the label as a standalone tag.
  if (!standaloneTag && equationReferenceProseContext(record.text)) return null;
  let confidence = equationCandidateConfidenceForSide(record);
  if (record.axisNumericCluster) confidence = -Infinity;
  if (!Number.isFinite(confidence) || confidence < 8) {
    if (!(standaloneTag && equationCandidateAlignedToNumberingSide(record))) return null;
    confidence = 12;
  }
  record.confidence = Math.max(12, confidence);
  return record;
}

function denseSupplementalEquationFamilies(records) {
  const byPrefix = new Map();
  const integerRecords = [];
  for (const record of records || []) {
    const parsed = record?.numeric || parsedEquationNumber(record?.label);
    if (!parsed) continue;
    if (!parsed.prefix) {
      if (record.standaloneTag && equationCandidateAlignedToNumberingSide(record)) integerRecords.push(record);
      continue;
    }
    const familyKey = equationSequenceFamilyKey(parsed);
    const list = byPrefix.get(familyKey) || [];
    list.push(record);
    byPrefix.set(familyKey, list);
  }
  const accepted = [];
  for (const recordsForPrefix of byPrefix.values()) {
    const byLabel = new Map();
    for (const record of recordsForPrefix) {
      const list = byLabel.get(record.label) || [];
      list.push(record);
      byLabel.set(record.label, list);
    }
    const canonical = [...byLabel.entries()].map(([label, candidates]) => ({
      label,
      parsed: parsedEquationNumber(label),
      candidate: chooseCanonicalEquationCandidate(candidates),
    })).filter((item) => item.parsed && item.candidate);
    canonical.sort((a, b) => equationDocumentPosition(a.candidate) - equationDocumentPosition(b.candidate));
    const monotone = [];
    let last = -1;
    for (const item of canonical) {
      if (item.parsed.last < last) continue;
      if (item.parsed.last === last && !item.parsed.suffix) continue;
      last = item.parsed.last;
      monotone.push(item);
    }
    if (monotone.length < 3) continue;
    const numbers = monotone.map((item) => item.parsed.last);
    const span = Math.max(...numbers) - Math.min(...numbers) + 1;
    // Full-margin OCR on old scans may itself miss a few faint tags. Require a
    // dense monotone family, but allow a proportional number of OCR holes so a
    // long genuine family (for example 2.1--2.60) is not discarded wholesale.
    const allowedHoles = Math.max(3, Math.ceil(monotone.length * 0.22));
    if (span > monotone.length + allowedHoles) continue;
    accepted.push(...monotone.map((item) => item.candidate));
  }

  // Some papers temporarily use local integer tags inside a numbered section.
  // Promote only consecutive standalone margin tags seen close together in
  // document order. This recovers genuine pairs such as Simon's (1), (2),
  // while sparse OCR noise from years, bibliography keys, or page furniture
  // cannot form an accepted run.
  const integerCanonical = [...new Map(integerRecords.map((record) => [record.label, record])).values()]
    .map((record) => ({ record, parsed: record.numeric || parsedEquationNumber(record.label) }))
    .filter((item) => item.parsed && Number.isInteger(item.parsed.last))
    .sort((a, b) => equationDocumentPosition(a.record) - equationDocumentPosition(b.record));
  let run = [];
  const flushIntegerRun = () => {
    if (run.length >= 2) {
      for (const item of run) item.record.confirmedLocalIntegerFamily = true;
      accepted.push(...run.map((item) => item.record));
    }
    run = [];
  };
  for (const item of integerCanonical) {
    const previous = run[run.length - 1];
    const pageGap = previous ? Number(item.record.page || 0) - Number(previous.record.page || 0) : 0;
    if (!previous || (item.parsed.last === previous.parsed.last + 1 && pageGap >= 0 && pageGap <= 2)) run.push(item);
    else { flushIntegerRun(); run.push(item); }
  }
  flushIntegerRun();
  return accepted;
}

async function supplementEquationIndexFromPageImages(sourceDoc, sourceKey, index, referenceEvidence = [], onProgress = null, forceImageOcr = false) {
  if (!sourceDoc?.numPages || documentTextMode !== 'native' || documentOcrActive || documentOcrBusy) return false;

  const pageCount = Math.max(0, Number(sourceDoc.numPages) || 0);
  const gapPlan = equationNativeImageGapPlan(index, pageCount, referenceEvidence);

  // Class-level old-scan rule: when the native PDF is actually image-backed,
  // its hidden text layer is only a hint. On journal-paper sized documents we
  // inventory the whole equation-number margin in the background. This is what
  // closes systematic Yau/Simon/Pisier-style omissions where every second or
  // several consecutive printed labels can be absent from the text layer.
  const imageBacked = await equationDocumentLooksImageBacked(sourceDoc, index);
  let comprehensivePages = [];
  if (forceImageOcr) comprehensivePages = Array.from({ length: pageCount }, (_, i) => i + 1);
  else if (imageBacked) {
    if (pageCount <= 120) comprehensivePages = Array.from({ length: pageCount }, (_, i) => i + 1);
    else comprehensivePages = equationSupplementalOcrPagePlan(sourceDoc, index).slice(0, 72);
  }

  const comprehensivePageSet = new Set(comprehensivePages);
  // Exact expected-gap pages are safe to render even for vector/text-backed PDFs:
  // the expected label is only a query and OCR must still read that exact margin
  // label before publication. This closes old reprint/text-layer omissions without
  // enabling broad OCR on ordinary born-digital documents.
  const priorityPages = [...new Set(gapPlan.pages)].sort((a, b) => a - b);
  const priorityPageSet = new Set(priorityPages);
  const pages = [...priorityPages, ...comprehensivePages.filter((page) => !priorityPageSet.has(page))];
  if (!pages.length) return false;
  if (typeof onProgress === 'function') onProgress({ phase: 'ocr', ocrTotal: pages.length, ocrDone: 0, documentPages: pageCount });
  let donePages = 0;
  let failedPages = 0;
  let worker = null;
  let createWorker = null;
  let workerInitFailed = false;
  const ensureWorker = async () => {
    if (worker) return worker;
    if (workerInitFailed) return null;
    const module = await loadDocumentOcrModule();
    if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return null;
    createWorker = createWorker || documentOcrCreateWorker(module);
    if (typeof createWorker !== 'function') { workerInitFailed = true; return null; }
    const setupStarted = equationDetectionNowMs();
    try {
      worker = await createWorker('eng', 1, { logger: () => {} });
    } catch (error) {
      workerInitFailed = true;
      throw error;
    }
    if (typeof onProgress === 'function') onProgress({ setupMs: equationDetectionNowMs() - setupStarted });
    if (typeof worker.setParameters === 'function') {
      try {
        await worker.setParameters({
          preserve_interword_spaces: '1',
          user_defined_dpi: '300',
          tessedit_pageseg_mode: '11',
        });
      } catch (_) {}
    }
    return worker;
  };

  const cachedLinesForPage = async (pageNum) => {
    // Freeze the numbering side before worker setup: a Settings change while
    // the worker is loading cannot miskey the stored margin observation.
    const side = equationNumberingSide === 'left' ? 'left' : 'right';
    const cacheKey = `${String(sourceKey || '')}|${side}|${pageNum}`;
    const cached = equationSupplementalOcrCache.get(cacheKey);
    if (Array.isArray(cached)) return cached;
    if (cached && typeof cached.then === 'function') return cached;
    const activeWorker = await ensureWorker();
    if (!activeWorker) throw new Error('Equation OCR worker unavailable');
    const pending = equationMarginOcrLines(sourceDoc, pageNum, side, activeWorker, { onTiming: (measurement) => {
      if (typeof onProgress === 'function') onProgress({ timing: measurement });
    } })
      .then(async (lines) => {
        if (pdfDoc === sourceDoc && currentFileKey === sourceKey) {
          equationSupplementalOcrCache.set(cacheKey, lines);
          // Commit each completed page before reporting it as scanned.
          await persistEquationMarginOcrPage(sourceDoc, sourceKey, pageNum, side, lines);
        }
        return lines;
      })
      .catch((error) => {
        equationSupplementalOcrCache.delete(cacheKey);
        throw error;
      });
    equationSupplementalOcrCache.set(cacheKey, pending);
    return pending;
  };

  const comprehensiveRecords = [];
  let added = false;
  try {
    for (const pageNum of pages) {
      if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return added;
      let lines;
      try {
        lines = await cachedLinesForPage(pageNum);
      } catch (error) {
        console.warn(`MathReader equation image-assistance skipped page ${pageNum}.`, error);
        failedPages += 1;
        donePages += 1;
        if (typeof onProgress === 'function') onProgress({ phase: 'ocr', ocrDone: donePages, failedPages });
        continue;
      }
      const expectedOnPage = gapPlan.expectedByPage.get(pageNum) || new Set();
      let pageAdded = false;
      for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
        const line = lines[lineIndex];
        for (const candidate of equationLabelCandidatesInLine(line.text)) {
          const record = equationSupplementalRecord(line, pageNum, lineIndex, lines, candidate);
          if (!record) continue;
          if (comprehensivePageSet.has(pageNum)) comprehensiveRecords.push(record);
          if (expectedOnPage.has(record.label) && !index.has(record.label)) {
            index.set(record.label, [{
              ...record,
              nativeGapCorroborated: true,
              confidence: Math.max(20, Number(record.confidence) || 0),
            }]);
            added = true;
            pageAdded = true;
          }
        }
      }
      donePages += 1;
      if (typeof onProgress === 'function') onProgress({ phase: 'ocr', ocrDone: donePages, failedPages, changed: pageAdded });
      await nextFrame();
    }

    // A faint printed tag can survive the normal margin inventory yet be lost
    // by general-purpose OCR (old scans often lose one parenthesis or one tiny
    // digit). Retry only unresolved, already-evidenced gaps with a narrower
    // numeric-only crop. The expected label is a query, never an assertion: its
    // exact digit/dot core must still be read as a standalone margin line.
    const numericRetryExpectedByPage = new Map();
    const addNumericRetryExpected = (pageNum, label) => {
      // Alphabetic families cannot be verified by the digits-only OCR pass.
      if (index.has(label) || parsedEquationNumber(label)?.appendix) return;
      const page = Number(pageNum);
      if (!Number.isInteger(page) || page < 1 || page > pageCount) return;
      const labels = numericRetryExpectedByPage.get(page) || new Set();
      labels.add(label);
      numericRetryExpectedByPage.set(page, labels);
    };
    for (const [pageNum, labels] of gapPlan.expectedByPage.entries()) {
      for (const label of labels) addNumericRetryExpected(pageNum, label);
    }
    for (const [pageNum, labels] of equationSupplementalNumericRetryQueries(comprehensiveRecords, pageCount).entries()) {
      for (const label of labels) addNumericRetryExpected(pageNum, label);
    }

    let numericRetryDone = 0;
    let numericRetryElapsed = 0;
    if (typeof onProgress === 'function') onProgress({ retryTotal: numericRetryExpectedByPage.size, retryDone: 0 });
    if (numericRetryExpectedByPage.size) {
      const activeWorker = await ensureWorker();
      if (activeWorker) {
        try {
          if (typeof activeWorker.setParameters === 'function') {
            await activeWorker.setParameters({
              preserve_interword_spaces: '1',
              user_defined_dpi: '300',
              tessedit_pageseg_mode: '6',
              tessedit_char_whitelist: '0123456789.()-',
            });
          }
          let retryDone = 0;
          const retryStarted = equationDetectionNowMs();
          for (const [pageNum, expectedLabels] of [...numericRetryExpectedByPage.entries()].sort((a, b) => a[0] - b[0])) {
            if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return added;
            let retryLines = [];
            try {
              retryLines = await equationMarginOcrLines(sourceDoc, pageNum, equationNumberingSide, activeWorker, {
                marginFraction: 0.18, onTiming: (measurement) => {
                  if (typeof onProgress === 'function') onProgress({ timing: measurement });
                },
              });
            } catch (error) {
              console.warn(`MathReader equation numeric-gap OCR skipped page ${pageNum}.`, error);
              failedPages += 1;
              retryDone += 1;
              numericRetryDone = retryDone;
              if (typeof onProgress === 'function') onProgress({ retryDone, failedPages });
              continue;
            }
            let pageAdded = false;
            for (const expectedLabel of expectedLabels) {
              if (index.has(expectedLabel)) continue;
              for (const line of retryLines) {
                const record = equationExpectedNumericOcrRecord(line, pageNum, expectedLabel);
                if (!record) continue;
                index.set(expectedLabel, [{ ...record, nativeGapCorroborated: true }]);
                comprehensiveRecords.push(record);
                added = true;
                pageAdded = true;
                break;
              }
            }
            retryDone += 1;
            numericRetryDone = retryDone;
            if (typeof onProgress === 'function') onProgress({ retryDone, failedPages, changed: pageAdded });
            await nextFrame();
          }
          numericRetryElapsed = equationDetectionNowMs() - retryStarted;
          if (typeof onProgress === 'function') onProgress({ retryMs: numericRetryElapsed });
        } finally {
          if (typeof activeWorker.setParameters === 'function') {
            try {
              await activeWorker.setParameters({
                preserve_interword_spaces: '1',
                user_defined_dpi: '300',
                tessedit_pageseg_mode: '11',
                tessedit_char_whitelist: '',
              });
            } catch (_) {}
          }
        }
      }
    }

    // Bounded second pass for printed appendix labels missed by the normal
    // wide-margin scan. Unlike the numeric-only pass, keep the alphabetic
    // glyph and the formula visible; OCR must observe the exact parenthesized
    // tag and mathematical context before any label is published.
    const appendixRetryExpectedByPage = new Map();
    for (const [pageNum, labels] of gapPlan.expectedByPage.entries()) {
      const missing = [...labels].filter((label) => !index.has(label) && parsedEquationNumber(label)?.appendix);
      if (missing.length) appendixRetryExpectedByPage.set(pageNum, missing);
    }
    // If the document contains many appendix schemes, prioritize a missing
    // *first* equation corroborated by a mature native sequence, then pages
    // with multiple missing labels. Never use document-specific page numbers.
    const appendixRetryPages = [...appendixRetryExpectedByPage.keys()].sort((a, b) => {
      const firstMissing = (page) => Number((appendixRetryExpectedByPage.get(page) || [])
        .some((label) => parsedEquationNumber(label)?.last === 1));
      return firstMissing(b) - firstMissing(a)
        || appendixRetryExpectedByPage.get(b).length - appendixRetryExpectedByPage.get(a).length
        || a - b;
    }).slice(0, 8);
    if (typeof onProgress === 'function') onProgress({
      retryTotal: numericRetryExpectedByPage.size + appendixRetryPages.length,
      retryDone: numericRetryDone,
    });
    if (appendixRetryPages.length) {
      const activeWorker = await ensureWorker();
      if (activeWorker) {
        try {
          if (typeof activeWorker.setParameters === 'function') {
            await activeWorker.setParameters({
              preserve_interword_spaces: '1',
              user_defined_dpi: '300',
              tessedit_pageseg_mode: '6',
              tessedit_char_whitelist: '',
            });
          }
          const appendixStarted = equationDetectionNowMs();
          let appendixDone = 0;
          for (const pageNum of appendixRetryPages) {
            if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return added;
            let retryLines = [];
            try {
              retryLines = await equationMarginOcrLines(sourceDoc, pageNum, equationNumberingSide, activeWorker, {
                marginFraction: 0.28, onTiming: (measurement) => {
                  if (typeof onProgress === 'function') onProgress({ timing: measurement });
                },
              });
            } catch (error) {
              console.warn(`MathReader appendix equation OCR skipped page ${pageNum}.`, error);
              failedPages += 1;
              appendixDone += 1;
              if (typeof onProgress === 'function') onProgress({
                retryDone: numericRetryDone + appendixDone, failedPages,
              });
              continue;
            }
            // The OCR worker may finish after the user has opened another PDF.
            if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return added;
            let pageAdded = false;
            for (const expectedLabel of appendixRetryExpectedByPage.get(pageNum) || []) {
              if (index.has(expectedLabel)) continue;
              for (const line of retryLines) {
                const record = equationExpectedAppendixOcrRecord(line, pageNum, expectedLabel);
                if (!record) continue;
                index.set(expectedLabel, [{ ...record, nativeGapCorroborated: true }]);
                comprehensiveRecords.push(record);
                added = true;
                pageAdded = true;
                break;
              }
            }
            appendixDone += 1;
            if (typeof onProgress === 'function') onProgress({
              retryDone: numericRetryDone + appendixDone, failedPages, changed: pageAdded,
            });
            await nextFrame();
          }
          if (typeof onProgress === 'function') onProgress({
            retryMs: numericRetryElapsed + equationDetectionNowMs() - appendixStarted,
          });
        } finally {
          if (typeof activeWorker.setParameters === 'function') {
            try {
              await activeWorker.setParameters({
                preserve_interword_spaces: '1',
                user_defined_dpi: '300',
                tessedit_pageseg_mode: '11',
                tessedit_char_whitelist: '',
              });
            } catch (_) {}
          }
        }
      }
    }

    // The comprehensive pass is still evidence-driven: only dense, monotone
    // OCR families are promoted, and every promoted label was actually read on
    // the page margin. Sequence arithmetic never invents a label.
    if (comprehensiveRecords.length) {
      for (const record of denseSupplementalEquationFamilies(comprehensiveRecords)) {
        if (index.has(record.label)) continue;
        index.set(record.label, [{ ...record, confidence: Math.max(18, Number(record.confidence) || 0) }]);
        added = true;
      }
      if (added && typeof onProgress === 'function') onProgress({ changed: true });
    }
    return added;
  } finally {
    // Save observed OCR lines independently of the published equation labels.
    // Reopening a cached PDF must not discard evidence needed by a later export.
    if (pdfDoc === sourceDoc && currentFileKey === sourceKey) {
      await persistEquationMarginOcrEvidence(sourceDoc, sourceKey);
    }
    try { await worker?.terminate?.(); } catch (_) {}
  }
}

// A narrow margin crop may include the first words of ordinary prose. On
// Giusti p.28, for example, the genuine (1.12) lies at x=.084 while a later
// "It follows from (1.12)" is near x=.24. Both lie inside a 28% left crop.
// Only promote an hOCR tag with measured outer-edge geometry. A broader edge
// position needs independent same-row display-math evidence from full-page OCR.
function meticulousMarginTargetGeometry(record, side, fullPageLines = []) {
  const start = Number(record?.candidateXStartRatio);
  const end = Number(record?.candidateXEndRatio);
  const ratio = Number(record?.ratio);
  if (!Number.isFinite(start) || !Number.isFinite(end) || !Number.isFinite(ratio)
      || ratio < 0 || ratio >= 0.999 || start < 0 || end > 1 || end <= start) return false;
  const strongOuter = side === 'left' ? end <= 0.205 : start >= 0.795;
  const weakOuter = side === 'left' ? end <= 0.285 : start >= 0.715;
  if (!weakOuter) return false;
  const near = (fullPageLines || []).filter((line) =>
    Number.isFinite(Number(line?.ratio)) && Math.abs(Number(line.ratio) - ratio) <= 0.014);
  // Even a "standalone" tag returned by a clipped margin crop is not reliable
  // if the uncropped page shows this exact occurrence in reference prose.
  if (near.some((line) => {
    const lineStart = Number(line?.xStartRatio);
    const lineEnd = Number(line?.xEndRatio);
    // An unrelated citation in the other column at the same y is not a
    // reason to discard the genuine numbered equation on this side.
    const overlapsToken = Number.isFinite(lineStart) && Number.isFinite(lineEnd)
      && lineStart <= end + 0.012 && lineEnd >= start - 0.012;
    return overlapsToken && equationReferenceProseContext(line.text)
      && equationLabelCandidatesInLine(line.text).some((item) => item.label === record.label);
  })) return false;
  if (strongOuter) return true;
  return near.some((line) => !equationReferenceProseContext(line.text)
    && equationLineMathSignalCount(line.text) >= 2);
}

// Meticulous page OCR is an explicit user action. Read equation-number margins
// separately from general text OCR, but never synthesize labels from gaps.
// Only parenthesized labels actually observed at the numbering edge are saved.
async function meticulousEquationMarginEvidence(sourceDoc, pageNum, worker, renderedCanvas, fullPageLines = []) {
  const sourceKey = currentFileKey;
  const side = equationNumberingSide === 'left' ? 'left' : 'right';
  const lines = await equationMarginOcrLines(sourceDoc, pageNum, side, worker, {
    existingCanvas: renderedCanvas,
  });
  if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return [];
  // Explicit page OCR also produces valuable measured margin observations.
  // v401 persisted only the automatic equation assistance pass, so this user-
  // initiated route lost its raw evidence on reopen even if labels survived.
  equationSupplementalOcrCache.set(`${sourceKey}|${side}|${pageNum}`, lines);
  await persistEquationMarginOcrPage(sourceDoc, sourceKey, pageNum, side, lines);
  if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return [];
  const byLabel = new Map();
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    for (const candidate of equationLabelCandidatesInLine(line.text)) {
      if (candidate.bare || candidate.sequenceOnly) continue;
      const record = equationSupplementalRecord(line, pageNum, i, lines, candidate);
      if (!record || !record.explicitParenthesized || !record.numeric?.prefix) continue;
      if (!record.candidateAtLineStart && side === 'left') continue;
      if (!record.candidateAtLineEnd && side === 'right') continue;
      if (!equationCandidateAlignedToNumberingSide(record)) continue;
      if (equationReferenceProseContext(record.text)) continue;
      if (!meticulousMarginTargetGeometry(record, side, fullPageLines)) continue;
      const verified = { ...record, ocrGeometryMeasured: true, marginLocationVerifiedV385: true, marginLocationVerifiedV386: true };
      const existing = byLabel.get(record.label);
      // Prefer the measured outer label over a more OCR-confident duplicate
      // farther into the body. A page can cite its own equation repeatedly.
      const edge = (item) => side === 'left'
        ? Number(item.candidateXEndRatio) : 1 - Number(item.candidateXStartRatio);
      if (!existing || edge(verified) < edge(existing) - 0.012
          || (Math.abs(edge(verified) - edge(existing)) <= 0.012
              && verified.confidence > existing.confidence)) byLabel.set(record.label, verified);
    }
  }
  return [...byLabel.values()];
}

async function buildEquationLabelIndex({ forceImageOcr = false, initialImageOcr = false } = {}) {
  if (!pdfDoc || !documentTextFeaturesAvailable()) return new Map();
  if (equationLabelIndex) return equationLabelIndex;
  const sourceDoc = pdfDoc;
  const sourceKey = currentFileKey;
  const generation = equationDetectionGeneration;
  const started = equationDetectionNowMs();
  updateEquationDetectionProgress({
    phase: 'native', nativeDone: 0, nativeTotal: sourceDoc.numPages,
    documentPages: sourceDoc.numPages, ocrTotal: 0, ocrDone: 0,
    retryTotal: 0, retryDone: 0, labels: 0, recovered: 0,
    failedPages: 0, renderMs: 0, recognizeMs: 0, validationMs: 0, ocrSetupMs: 0, retryMs: 0, uiMs: 0,
    nativeMs: 0, elapsedMs: 0,
  }, generation, true);
  const index = new Map();
  const candidatePool = new Map();
  const rawCandidates = [];
  const referenceOcrEvidence = [];
  const rawPageLines = new Map();
  const dottedSectionHeadingEvidence = [];
  const equationPages = Array.from({ length: sourceDoc.numPages }, (_, index) => index + 1);
  for await (const { item: page, value: lines } of orderedPrefetch(
    equationPages,
    (pageNum) => pageTextLines(pageNum, sourceDoc),
    3
  )) {
    rawPageLines.set(page, lines);
    updateEquationDetectionProgress({ nativeDone: page }, generation);
    const pageOcrConfidence = equationOcrPageConfidence(page);
    for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
      const line = lines[lineIndex];
      const rawLineText = String(line.text || '').normalize('NFKC');
      const sectionHeadingMatch = rawLineText.trim().match(/^(\d+(?:\.\d+){1,4})\s+(.{2,120})$/);
      if (sectionHeadingMatch) {
        const sectionTitle = String(sectionHeadingMatch[2] || '').trim();
        const sectionWords = sectionTitle.match(/\b[A-Za-z]{3,}\b/g) || [];
        const sectionHan = sectionTitle.match(/\p{Script=Han}/gu) || [];
        if (equationLineMathSignalCount(sectionTitle) <= 1 && (sectionWords.length >= 2 || sectionHan.length >= 3)) {
          dottedSectionHeadingEvidence.push({ page, label: normalizedEquationLabel(sectionHeadingMatch[1]) });
        }
      }
      const explicit = equationLabelCandidatesInLine(line.text);
      const weakBare = [];
      const rawText = String(line.text || '').normalize('NFKC');
      // OCR can drop parentheses around hierarchical equation tags. Keep both
      // dotted and hyphenated bare forms sequence-only so they can fill a local
      // numbering gap, but never enter the index directly.
      const bareRe = line.ocrSource
        ? /\b\d+(?:(?:\.\d+)+|(?:-\d+)+)\b/g
        : /\b\d+(?:\.\d+)+\b/g;
      let bareMatch;
      while ((bareMatch = bareRe.exec(rawText))) {
        const label = normalizedEquationLabel(bareMatch[0]);
        if (isLikelyCalendarYearEquationLabel(label) || explicit.some((item) => item.label === label)) continue;
        weakBare.push({ label, index: bareMatch.index, end: bareMatch.index + bareMatch[0].length, bare: true, sequenceOnly: true });
      }
      for (const candidate of [...explicit, ...weakBare]) {
        const tokenGeometry = equationCandidateTokenGeometry(line, candidate);
        const numeric = parsedEquationNumber(candidate.label);
        // OCR of old books can turn a running section header such as
        // "6.2  <title>  · 239 ·" into a bare dotted equation candidate.  A
        // genuine display tag may occur near the top of a page, but it should
        // not also look like a short running header with a trailing page number.
        // Keep this rejection OCR-only and top-band-only so born-digital and
        // ordinary display equations retain the mature detector behavior.
        const ocrTopRunningHeader = Boolean(
          line.ocrSource
          && candidate.bare
          && (Number(candidate.index) || 0) <= 4
          && Number(line.ratio) <= 0.075
          && /^\s*\d{1,3}\s*(?:[.．]\s*\d{1,3}){1,3}\s+\S/u.test(rawLineText)
          && /[A-Za-z\u00C0-\u024F]{2,}/u.test(rawLineText)
          && /\b\d{1,4}\b\s*[-+·•.]?\s*$/u.test(rawLineText)
          && rawLineText.length <= 90
        );
        rawCandidates.push({
          label: candidate.label,
          page,
          ratio: line.ratio,
          text: line.text,
          xStartRatio: line.xStartRatio,
          xEndRatio: line.xEndRatio,
          candidateXStartRatio: tokenGeometry.xStartRatio,
          candidateXEndRatio: tokenGeometry.xEndRatio,
          numeric,
          bareSource: Boolean(candidate.bare),
          sequenceOnly: Boolean(candidate.sequenceOnly),
          explicitParenthesized: !candidate.bare && !candidate.sequenceOnly,
          candidateAtLineStart: !String(line.text || '').slice(0, Math.max(0, Number(candidate.index) || 0)).trim(),
          candidateAtLineEnd: !String(line.text || '').slice(Math.max(0, Number(candidate.end) || 0)).trim(),
          standaloneTag: isStandaloneEquationTagLine(line, candidate.label),
          nearbyDisplayMath: hasNearbyDisplayMath(lines, lineIndex),
          nearbyHeadingContext: Boolean(candidate.bare) && bareEquationHasNearbyHeadingContext(lines, lineIndex),
          sameRowHeadingContext: Boolean(candidate.bare) && bareEquationHasSameRowHeadingContext(lines, lineIndex),
          axisNumericCluster: Boolean(candidate.bare) && (bareEquationInHorizontalNumericCluster(lines, lineIndex)
            || bareEquationInVerticalNumericTicks(lines, lineIndex)),
          tabularNumericCell: Boolean(candidate.bare) && bareEquationInTabularRow(lines, lineIndex),
          measurementValue: Boolean(candidate.bare) && bareEquationHasMeasurementSuffix(line, candidate),
          mathSignals: equationLineMathSignalCount(line.text),
          ocrSource: Boolean(line.ocrSource),
          ocrLineConfidence: Number.isFinite(line.confidence) ? Number(line.confidence) : null,
          ocrPageConfidence: Number.isFinite(pageOcrConfidence) ? Number(pageOcrConfidence) : null,
          ocrTopRunningHeader,
          attachedFunctionCall: Boolean(candidate.attachedFunctionCall),
          colonEncoded: Boolean(candidate.colonEncoded),
          enumeratedConditionList: equationEnumeratedConditionListContext(lines, lineIndex, candidate),
        });
      }
    }
    if (page % 20 === 0) await new Promise((resolve) => setTimeout(resolve, 0));
  }

  const dottedSectionHeadingPages = new Set(dottedSectionHeadingEvidence.map((item) => item.page));
  const dottedSectionHeadingLabels = new Set(dottedSectionHeadingEvidence.map((item) => item.label));
  const dottedSectionNumberingProfile = dottedSectionHeadingEvidence.length >= 6 && dottedSectionHeadingPages.size >= 3;

  equationNumberingSide = inferEquationNumberingSide(rawCandidates);
  const colonMarginFamily = equationNumberingSide === 'left'
    ? equationColonMarginFamily(rawCandidates) : null;

  for (const record0 of rawCandidates) {
    const record = { ...record0 };
    let confidence = equationCandidateConfidenceForSide(record);
    const weakOcrPageCandidate = Boolean(
      record.ocrSource
      && Number.isFinite(record.ocrPageConfidence)
      && record.ocrPageConfidence < 50
    );
    const extremeTopBareMarker = Boolean(
      record.bareSource
      && record.standaloneTag
      && !record.nearbyDisplayMath
      && (
        Number(record.ratio) <= 0.040
        || (Number(record.ratio) <= 0.070 && record.nearbyHeadingContext)
      )
    );
    const referenceContextRejectedCandidate = Boolean(record.explicitParenthesized && equationReferenceProseContext(record.text));
    // Only schedule posterior image recovery when this exact prose candidate
    // would have survived the mature v326 classifier without the new lexical
    // reference guard. This keeps harmless citations from expanding the OCR
    // plan while preserving recovery for the class-level false targets fixed
    // here.
    const preReferenceGuardConfidence = referenceContextRejectedCandidate
      ? equationCandidateConfidenceForSide(record, true)
      : -Infinity;
    if (referenceContextRejectedCandidate && record.numeric?.prefix && preReferenceGuardConfidence >= 8) referenceOcrEvidence.push({ ...record, referenceRecoveryStrong: true });
    const bareSectionHeadingCandidate = Boolean(
      record.bareSource
      && (Number(record.mathSignals) || 0) === 0
      && (record.sameRowHeadingContext || (record.nearbyHeadingContext && !record.nearbyDisplayMath))
    );
    let hardRejectedCandidate = Boolean(record.axisNumericCluster || record.tabularNumericCell || record.measurementValue || record.ocrTopRunningHeader || extremeTopBareMarker || weakOcrPageCandidate || referenceContextRejectedCandidate || bareSectionHeadingCandidate);
    if (hardRejectedCandidate) confidence = -Infinity;
    // Normal PDF math-signal heuristics see no operator when an old embedded
    // font extracts '=' as 'D'. A corroborated left-margin colon family supplies
    // separate, stronger positional evidence for these damaged labels.
    const confirmedColonMargin = !hardRejectedCandidate
      && equationColonMarginCandidateReliable(record, colonMarginFamily);
    if (confirmedColonMargin) confidence = Math.max(confidence, 18);
    if (dottedSectionNumberingProfile && record.bareSource && record.numeric?.prefix) {
      const strongOuterMargin = equationNumberingSide === 'left'
        ? Number(record.candidateXEndRatio) <= (record.ocrSource ? 0.24 : 0.13)
        : Number(record.candidateXStartRatio) >= (record.ocrSource ? 0.76 : 0.87);
      const bareRemainder = String(record.text || '').replace(/^\s*\d+(?:\s*\.\s*\d+)+\s*/, '').trim();
      const sameLineWords = bareRemainder.match(/\b[A-Za-z]{3,}\b/g) || [];
      const sameLineHan = bareRemainder.match(/\p{Script=Han}/gu) || [];
      const sameLineMathSignals = Number(record.mathSignals) || 0;
      const sameLineSectionContext = Boolean(bareRemainder) && (
        (sameLineMathSignals === 0 && (sameLineWords.length >= 2 || sameLineHan.length >= 2)) ||
        (sameLineMathSignals === 1 && sameLineHan.length >= 1 && (/^[-–—]?[A-Za-z]{2,}/.test(bareRemainder) || sameLineHan.length >= 2))
      );
      const sectionLikeBare = sameLineSectionContext
        || Boolean(record.nearbyHeadingContext)
        || (!strongOuterMargin && !record.nearbyDisplayMath && (Number(record.mathSignals) || 0) === 0);
      if (sectionLikeBare) {
        confidence = -Infinity;
        hardRejectedCandidate = true;
      }
    }
    if (confirmedColonMargin && !hardRejectedCandidate) confidence = Math.max(confidence, 18);
    record.confirmedColonMargin = confirmedColonMargin;
    let reliable = confidence >= 8;
    if (!hardRejectedCandidate && !reliable && record.standaloneTag && record.nearbyDisplayMath && equationCandidateAlignedToNumberingSide(record)) {
      confidence = Math.max(confidence, 12);
      reliable = true;
    }
    // Integer numbering is valid on either margin, but only when the token is
    // aligned with the inferred numbering side and has display-math context.
    const integerTag = Boolean(record.numeric && !record.numeric.prefix);
    if (integerTag && !(equationCandidateAlignedToNumberingSide(record) && (record.explicitParenthesized || record.nearbyDisplayMath || record.mathSignals >= 2))) {
      reliable = false;
    }
    if (integerTag && record.bareSource && !(record.nearbyDisplayMath || record.mathSignals >= 2)) reliable = false;
    if (record.colonEncoded && !confirmedColonMargin) {
      confidence = -Infinity;
      reliable = false;
    }
    record.confidence = confidence;
    // Sequence recovery must never resurrect a candidate that the direct
    // classifier already rejected as implausible (for example "1.7 Lemma"
    // or "3.10 Corollary").  Keep a deliberately narrower recovery pool:
    // direct candidates need to clear the normal confidence floor, while weak
    // bare/sequence-only candidates additionally need local display-math
    // evidence.  This keeps recovery as a gap-filler, not a second detector.
    const alignedForPool = equationCandidateAlignedToNumberingSide(record);
    const strongLineStartTag = Boolean(
      record.explicitParenthesized &&
      record.candidateAtLineStart &&
      (alignedForPool || record.nearbyDisplayMath || record.mathSignals >= 1)
    );
    const poolEligible = Number.isFinite(confidence) && (
      (confidence >= 8 && (
        record.standaloneTag ||
        alignedForPool ||
        record.nearbyDisplayMath ||
        record.mathSignals >= 2
      )) ||
      strongLineStartTag
    ) && (!record.sequenceOnly || record.nearbyDisplayMath || record.mathSignals >= 2);
    // Some PDFs expose a true displayed equation as a short alphabetic or
    // badly decoded formula line plus its explicit margin tag. The normal direct
    // classifier deliberately rejects prose-like integer tags. Keep such a tag
    // only as sequence evidence: it can fill one bounded numeric gap, but it
    // cannot enter the index on its own. This preserves the anti-reference
    // guard while allowing complete equation families.
    const marginGapCandidate = Boolean(
      !referenceContextRejectedCandidate
      && !record.attachedFunctionCall
      && !record.ocrTopRunningHeader
      && record.explicitParenthesized
      && alignedForPool
      && (Number(record.mathSignals) || 0) === 0
      && (equationNumberingSide === 'left' ? record.candidateAtLineStart : record.candidateAtLineEnd)
      && (equationNumberingSide === 'left' || Number(record.xStartRatio) >= 0.22)
      && !/\b(?:equation|eq\.?|see|from|by|using|satisfies|implies|according\s+to|as\s+in|in\s+view\s+of|contradicts?|rewrit(?:e|ten)|follows?\s+from|inequality\s+(?:like|in)|as\s+required|cf\.?|recall|apply(?:ing)?|combin(?:e|ing)|substitut(?:e|ing)|insert|notice)\b/i.test(String(record.text || ''))
    );
    if (poolEligible || marginGapCandidate) {
      const pool = candidatePool.get(record.label) || [];
      pool.push(marginGapCandidate && !poolEligible
        ? { ...record, confidence: 0, sequenceOnly: true, recoveredMarginGapCandidate: true }
        : record);
      candidatePool.set(record.label, pool);
    }
    if (!reliable || record.sequenceOnly) continue;
    const list = index.get(record.label) || [];
    list.push(record);
    index.set(record.label, list);
  }

  const nativeExtractionEnd = equationDetectionNowMs();
  updateEquationDetectionProgress({ phase: 'validating', nativeDone: sourceDoc.numPages, nativeMs: nativeExtractionEnd - started }, generation, true);
  const columnProfiles = supplementTwoColumnEquations(index, rawPageLines);
  reconcileEquationNumberingFamilies(index);
  recoverSequentialEquationGaps(index, candidatePool);
  reconcileEquationNumberingFamilies(index);
  reconcileOcrEquationSequenceOrder(index);
  suppressSparseAmbiguousOcrEquationFamilies(index);
  suppressSparseAmbiguousNativeBareEquationFamilies(index);
  suppressIsolatedBareAppendixTokens(index);
  // Preserve individually image-verified margin labels from the user's
  // deliberate Meticulous OCR action, even when the full-page text OCR missed
  // the tiny parenthesized number. No scan is started here or on reopen.
  for (const [pageNum, saved] of manualIndexOcrPages.entries()) {
    for (const evidence of saved?.equationMarginEvidence || []) {
      if (Number(evidence?.page) !== Number(pageNum) || !evidence.explicitParenthesized ||
          !evidence.numeric?.prefix || !Number.isFinite(evidence.ratio) ||
          !equationCandidateAlignedToNumberingSide(evidence) ||
          !isPlausibleEquationTagInner(normalizedEquationLabel(evidence.label).slice(1, -1))) continue;
      const candidates = index.get(evidence.label) || [];
      // A correctly read number is not enough: the image-margin position must
      // also correct stale/native candidate positions for this *same* label.
      if (!candidates.some((other) => Number(other.page) === Number(evidence.page)
        && Math.abs(Number(other.ratio) - Number(evidence.ratio)) < 0.008
        && other.meticulousPageVerified === true)) {
        index.set(evidence.label, [...candidates, {
          ...evidence, meticulousPageVerified: true,
          marginLocationVerifiedV385: evidence.marginLocationVerifiedV385 === true,
          marginLocationVerifiedV386: evidence.marginLocationVerifiedV386 === true
        }]);
      }
    }
  }
  // Gap recovery can promote a local-column candidate *after* the initial
  // supplement pass. Reapply only display-column metadata, never detections.
  annotateEquationColumnsForOrder(index, columnProfiles);
  if (generation !== equationDetectionGeneration || pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return new Map();
  const nativeEnd = equationDetectionNowMs();
  updateEquationDetectionProgress({ nativeMs: nativeExtractionEnd - started, validationMs: nativeEnd - nativeExtractionEnd, phase: 'planning' }, generation, true);
  let nativeCount = 0;

  const publishAutomaticIndex = () => {
    if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return false;
    equationAutomaticLabelIndex = canonicalizeEquationIndex(index);
    equationLabelIndex = applyEquationEdits(equationAutomaticLabelIndex);
    updateEquationDetectionProgress({ labels: equationAutomaticLabelIndex.size, recovered: Math.max(0, equationAutomaticLabelIndex.size - nativeCount) }, generation);
    const previousKnownEquationCount = equationIndexKnownCount;
    const uiStarted = equationDetectionNowMs();
    renderEquationIndex();
    updateEquationDetectionProgress({ uiMs: (equationDetectionProgress.uiMs || 0) + equationDetectionNowMs() - uiStarted }, generation);
    if (equationIndexKnownCount !== previousKnownEquationCount) persistDocumentState();
    return true;
  };

  // Publish native text immediately; first open schedules one bounded image-backed
  // recovery. Subsequent full-document rescans require the manual OCR action.
  publishAutomaticIndex();
  nativeCount = equationAutomaticLabelIndex?.size || 0;
  updateEquationDetectionProgress({ labels: nativeCount, recovered: 0 }, generation, true);

  if ((forceImageOcr || initialImageOcr) && !equationImageAssistPromise) {
    const assistIndex = index;
    const assistPool = candidatePool;
    const onAssistProgress = (event = {}) => {
      if (generation !== equationDetectionGeneration || pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return;
      const { timing, changed, setupMs, ...values } = event;
      if (setupMs != null) values.ocrSetupMs = (equationDetectionProgress.ocrSetupMs || 0) + setupMs;
      if (timing) {
        values.renderMs = (equationDetectionProgress.renderMs || 0) + (timing.renderMs || 0);
        values.recognizeMs = (equationDetectionProgress.recognizeMs || 0) + (timing.recognizeMs || 0);
      }
      updateEquationDetectionProgress(values, generation, Boolean(changed));
      if (changed) publishAutomaticIndex();
    };
    equationImageAssistPromise = (async () => {
      const added = await supplementEquationIndexFromPageImages(sourceDoc, sourceKey, assistIndex, referenceOcrEvidence, onAssistProgress, forceImageOcr);
      if (generation !== equationDetectionGeneration || pdfDoc !== sourceDoc || currentFileKey !== sourceKey) return;
      if (added) {
        updateEquationDetectionProgress({ phase: 'validating' }, generation, true);
        const validatedAt = equationDetectionNowMs();
        reconcileEquationNumberingFamilies(assistIndex);
        recoverSequentialEquationGaps(assistIndex, assistPool);
        reconcileEquationNumberingFamilies(assistIndex);
        reconcileOcrEquationSequenceOrder(assistIndex);
        suppressSparseAmbiguousOcrEquationFamilies(assistIndex);
        suppressSparseAmbiguousNativeBareEquationFamilies(assistIndex);
        suppressIsolatedBareAppendixTokens(assistIndex);
        annotateEquationColumnsForOrder(assistIndex, columnProfiles);
        updateEquationDetectionProgress({ validationMs: (equationDetectionProgress.validationMs || 0) + equationDetectionNowMs() - validatedAt }, generation);
        publishAutomaticIndex();
      }
      const current = equationDetectionProgress;
      // Record the first automatic recovery only after the image pass is complete.
      // A partial/error run must not silently suppress a later retry.
      if (initialImageOcr && !current.failedPages) {
        equationInitialRecoveryDone = true;
        persistDocumentState();
      }
      const finish = { phase: (current.failedPages || 0) ? 'partial' : 'complete', elapsedMs: equationDetectionNowMs() - started };
      updateEquationDetectionProgress(finish, generation, true);
      logEquationDetectionTiming(equationDetectionProgress, sourceKey);
    })().catch((error) => {
      console.warn('MathReader posterior equation OCR was unavailable.', error);
      if (generation === equationDetectionGeneration && pdfDoc === sourceDoc && currentFileKey === sourceKey) {
        updateEquationDetectionProgress({ phase: 'partial', elapsedMs: equationDetectionNowMs() - started, error: String(error?.message || error) }, generation, true);
        logEquationDetectionTiming(equationDetectionProgress, sourceKey);
      }
    }).finally(() => {
      if (generation === equationDetectionGeneration && pdfDoc === sourceDoc && currentFileKey === sourceKey) { equationImageAssistPromise = null; refreshEquationForceOcrButton(); }
    });
  }
  if (!forceImageOcr && !initialImageOcr) {
    updateEquationDetectionProgress({ phase: 'complete', elapsedMs: equationDetectionNowMs() - started }, generation, true);
    logEquationDetectionTiming(equationDetectionProgress, sourceKey);
  }
  return equationLabelIndex;
}

function equationConfidenceTier(score) {
  if (score >= 20) return t('high confidence','高置信度');
  if (score >= 12) return t('medium confidence','中等置信度');
  return t('review','需核对');
}

function equationRowOrderKey(entry) {
  if (entry?.manualEditId) return `edit:${String(entry.manualEditId)}`;
  const source = equationSourceLabelForDisplayed(entry?.label || '');
  const base = `label:${normalizedEquationLabel(source || entry?.label || '')}`;
  // Distinct occurrences need distinct drag/persistence identities. Keep the
  // original key for ordinary single-occurrence PDFs and their saved edits.
  if (entry?.repeatedPrintedEquation) {
    return `${base}:page:${Number(entry.page) || 1}:y:${Math.round((Number(entry.ratio) || 0) * 10000)}`;
  }
  return base;
}

// Page order is primary, but within the same numbered family OCR coordinates
// may be approximate. Respect the printed equation sequence, not OCR arrival time.
function compareEquationIndexRows(a, b) {
  const pageDelta = (Number(a.page) || 0) - (Number(b.page) || 0);
  if (pageDelta) return pageDelta;
  if (a.equationTwoColumn && b.equationTwoColumn
      && Number.isInteger(a.equationColumnIndex) && Number.isInteger(b.equationColumnIndex)
      && a.equationColumnIndex !== b.equationColumnIndex) return a.equationColumnIndex - b.equationColumnIndex;
  // Yau (1978), PDF p.8 actually PRINTS (1.21) after (1.33). A global
  // numeric sort moved it to the wrong location despite independently measured
  // x/y label geometry. Prefer print-page order when BOTH labels have measured
  // candidate bounding boxes and are separated by more than a line-height.
  // For approximate OCR-only ratios (no measured candidate bounds), preserve
  // the previous numerical ordering so additive OCR does not jumble entries.
  const aMeasured = Number.isFinite(a.ratio) && Number.isFinite(a.candidateXStartRatio)
    && Number.isFinite(a.candidateXEndRatio)
    && a.candidateXStartRatio >= 0 && a.candidateXEndRatio <= 1
    && a.candidateXStartRatio < a.candidateXEndRatio;
  const bMeasured = Number.isFinite(b.ratio) && Number.isFinite(b.candidateXStartRatio)
    && Number.isFinite(b.candidateXEndRatio)
    && b.candidateXStartRatio >= 0 && b.candidateXEndRatio <= 1
    && b.candidateXStartRatio < b.candidateXEndRatio;
  if (aMeasured && bMeasured && Math.abs(a.ratio - b.ratio) >= 0.024) return a.ratio - b.ratio;
  const aNumber = parsedEquationNumber(a.label);
  const bNumber = parsedEquationNumber(b.label);
  if (aNumber && bNumber && aNumber.prefix === bNumber.prefix) {
    if (aNumber.last !== bNumber.last) return aNumber.last - bNumber.last;
    if (aNumber.suffix !== bNumber.suffix) return String(aNumber.suffix).localeCompare(String(bNumber.suffix));
  }
  return (Number(a.ratio) || 0) - (Number(b.ratio) || 0) || String(a.label).localeCompare(String(b.label), undefined, { numeric: true });
}

function reconcileEquationManualOrder(rows) {
  if (!Array.isArray(rows) || !rows.length) { equationManualOrder = []; return rows || []; }
  const currentKeys = rows.map(equationRowOrderKey);
  // The automatic index is always re-sorted after an OCR merge. Never let the
  // historically persisted auto-generated key list append new equations at the end.
  if (!equationOrderCustomized) {
    equationManualOrder = currentKeys;
    return rows;
  }
  const valid = new Set(currentKeys);
  const seen = new Set();
  const order = [];
  for (const rawKey of equationManualOrder || []) {
    const key = String(rawKey || '');
    if (!key || !valid.has(key) || seen.has(key)) continue;
    seen.add(key);
    order.push(key);
  }
  if (!order.length) order.push(...currentKeys);
  for (let i = 0; i < currentKeys.length; i += 1) {
    const key = currentKeys[i];
    if (order.includes(key)) continue;
    let inserted = false;
    for (let j = i - 1; j >= 0; j -= 1) {
      const prev = currentKeys[j];
      const at = order.indexOf(prev);
      if (at >= 0) { order.splice(at + 1, 0, key); inserted = true; break; }
    }
    if (!inserted) {
      for (let j = i + 1; j < currentKeys.length; j += 1) {
        const next = currentKeys[j];
        const at = order.indexOf(next);
        if (at >= 0) { order.splice(at, 0, key); inserted = true; break; }
      }
    }
    if (!inserted) order.push(key);
  }
  const changed = order.length !== equationManualOrder.length || order.some((key, index) => key !== equationManualOrder[index]);
  equationManualOrder = order;
  if (changed) persistDocumentState();
  const byKey = new Map(rows.map((row) => [equationRowOrderKey(row), row]));
  return equationManualOrder.map((key) => byKey.get(key)).filter(Boolean);
}

function saveEquationDragOrder(rows, visibleRows, draggedKey, targetKey, before) {
  const fullKeys = rows.map(equationRowOrderKey);
  const visibleKeys = visibleRows.map(equationRowOrderKey);
  const from = visibleKeys.indexOf(draggedKey);
  const target = visibleKeys.indexOf(targetKey);
  if (from < 0 || target < 0 || draggedKey === targetKey) return false;
  visibleKeys.splice(from, 1);
  let insertAt = visibleKeys.indexOf(targetKey);
  if (insertAt < 0) insertAt = visibleKeys.length;
  if (!before) insertAt += 1;
  visibleKeys.splice(Math.min(insertAt, visibleKeys.length), 0, draggedKey);
  const visibleSet = new Set(visibleKeys);
  let cursor = 0;
  equationManualOrder = fullKeys.map((key) => visibleSet.has(key) ? visibleKeys[cursor++] : key);
  equationOrderCustomized = true;
  persistDocumentState();
  return true;
}

// Trust the exact measured page-margin observation when an old imported or
// cached Equations row still points at a different location. This is a read-
// only navigation repair: it does not delete an entry or modify manual edits.
function verifiedEquationNavigationTarget(entry) {
  const original = { page: Number(entry?.page) || 1, ratio: Math.min(1, Math.max(0, Number(entry?.ratio) || 0)) };
  if (!entry?.label || entry.manualEditId || entry.manualAdd || entry.manualReselect
      || !(manualIndexOcrPages instanceof Map)) return original;
  const label = normalizedEquationLabel(equationSourceLabelForDisplayed(entry.label));
  const verified = [];
  for (const [pageNum, record] of manualIndexOcrPages) {
    for (const item of record?.equationMarginEvidence || []) {
      if (normalizedEquationLabel(item?.label) !== label
          || item.marginLocationVerifiedV385 !== true
          || item.ocrGeometryMeasured !== true
          || !Number.isFinite(Number(item.ratio))
          || Number(item.ratio) < 0 || Number(item.ratio) >= 0.999
          || !Number.isInteger(Number(pageNum)) || Number(pageNum) < 1) continue;
      verified.push({ page: Number(pageNum), ratio: Number(item.ratio), candidate: item });
    }
  }
  if (!verified.length) return original;
  // Page identity outranks OCR geometry version: an upgraded measurement
  // for another printed occurrence must never displace a valid same-page tag.
  // Only then prefer the newer, page-bbox-normalized v386 coordinates.
  const samePageEvidence = verified.filter((item) => item.page === original.page);
  const eligible = samePageEvidence.length ? samePageEvidence : verified;
  const newMeasurements = eligible.filter((item) => item.candidate.marginLocationVerifiedV386 === true);
  const usable = newMeasurements.length ? newMeasurements : eligible;
  const samePage = usable.filter((item) => item.page === original.page);
  // Other-page recovery is safe only when there is exactly one independently
  // vetted page for the label; otherwise retain the original target.
  const group = samePage.length ? samePage
    : entry.repeatedPrintedEquation ? []
    : new Set(usable.map((item) => item.page)).size === 1 ? usable : [];
  if (!group.length) return original;
  const side = equationNumberingSide === 'left' ? 'left' : 'right';
  group.sort((a, b) => {
    const edge = (item) => side === 'left'
      ? Number(item.candidate?.candidateXEndRatio)
      : 1 - Number(item.candidate?.candidateXStartRatio);
    const ax = edge(a);
    const bx = edge(b);
    if (Number.isFinite(ax) && Number.isFinite(bx) && Math.abs(ax-bx) > 0.012) return ax-bx;
    return Math.abs(a.ratio-original.ratio) - Math.abs(b.ratio-original.ratio);
  });
  return { page: group[0].page, ratio: group[0].ratio };
}

function renderEquationIndex() {
  if (!equationIndex || !equationIndexEmpty || !equationIndexCount) return;
  if (equationDetectionProgress.phase === 'idle' && equationLabelIndex) updateEquationDetectionProgress({ phase: 'saved' }, equationDetectionGeneration, true);
  const previousRenderedEquationRows = equationIndex.querySelectorAll('.equation-edit-row').length;
  equationIndex.replaceChildren();
  if (!equationLabelIndex) {
    equationIndexCount.textContent = Number.isInteger(equationIndexKnownCount) ? String(equationIndexKnownCount) : '…';
    equationIndexEmpty.classList.remove('is-hidden');
    equationIndexEmpty.textContent = !pdfDoc
      ? t('Open a PDF to index equations.', '打开 PDF 后可建立公式索引。')
      : t('Preparing equation-label index…', '正在准备公式编号索引……');
    return;
  }
  let rows = [];
  for (const [label, candidates] of equationLabelIndex.entries()) {
    let best = null;
    const instances = [];
    for (const candidate of candidates || []) {
      const score = Number.isFinite(candidate.confidence) ? candidate.confidence : equationCandidateConfidence(candidate, label);
      if (score < 8) continue;
      const entry = { label, ...candidate, score };
      instances.push(entry);
      if (!best || score > best.score) best = entry;
    }
    if (instances.length > 1) {
      // Show both Chapter 1 (1.1) and Chapter 2 (1.1), with the correct page.
      // Never expose label-wide Remove/Reselect for an ambiguous occurrence.
      rows.push(...instances.map((item) => ({...item, repeatedPrintedEquation: true})));
    } else if (best) rows.push(best);
  }
  rows.sort(compareEquationIndexRows);
  for (const edit of equationEdits.filter((item) => item.action === 'add')) {
    const addedIndex = rows.findIndex((row) => row.manualEditId && String(row.manualEditId) === String(edit.id));
    if (addedIndex < 0) continue;
    const [added] = rows.splice(addedIndex, 1);
    let anchorIndex = -1;
    const anchorRef = String(edit.beforeRef || edit.afterRef || edit.sourceLabel || '');
    if (anchorRef.startsWith('edit:')) anchorIndex = rows.findIndex((row) => String(row.manualEditId || '') === anchorRef.slice(5));
    else anchorIndex = rows.findIndex((row) => normalizedEquationLabel(row.label) === normalizedEquationLabel(anchorRef));
    const insertAt = anchorIndex >= 0
      ? (edit.beforeRef || edit.placement === 'above' ? anchorIndex : anchorIndex + 1)
      : rows.length;
    rows.splice(insertAt, 0, added);
  }
  rows = reconcileEquationManualOrder(rows);
  equationIndexKnownCount = rows.length;
  equationIndexCount.textContent = String(rows.length);
  const filterBar = document.createElement('div'); filterBar.className = 'equation-confidence-filter';
  const filterLabel = document.createElement('label'); filterLabel.textContent = t('Confidence', '置信度');
  const filterSelect = document.createElement('select'); filterSelect.setAttribute('aria-label', t('Filter equations by confidence', '按置信度筛选公式'));
  const filterOptions = [
    ['all', t('All', '全部')],
    ['high', t('High', '高')],
    ['medium', t('Medium', '中')],
    ['review', t('Review', '需核对')],
  ];
  for (const [value, text] of filterOptions) { const option = document.createElement('option'); option.value = value; option.textContent = text; filterSelect.append(option); }
  filterSelect.value = equationConfidenceFilter;
  if (detectionEquationConfidenceSelect) detectionEquationConfidenceSelect.value = equationConfidenceFilter;
  filterSelect.addEventListener('change', () => { equationConfidenceFilter = filterSelect.value || 'all'; persistDetectionViewPreferences(); renderEquationIndex(); });
  filterLabel.append(filterSelect); filterBar.append(filterLabel); equationIndex.append(filterBar);
  const visibleRows = equationConfidenceFilter === 'all' ? rows : rows.filter((row) => (row.score >= 20 ? 'high' : row.score >= 12 ? 'medium' : 'review') === equationConfidenceFilter);
  equationIndexEmpty.classList.toggle('is-hidden', visibleRows.length > 0);
  if (!rows.length) equationIndexEmpty.textContent = t('No reliable equation labels detected.', '未检测到可靠的公式编号。');
  else if (!visibleRows.length) equationIndexEmpty.textContent = t('No equations match this confidence filter.', '没有符合当前置信度筛选的公式。');
  const equationTextFilter = String(el('map-filter-equations')?.value || '').trim().toLocaleLowerCase();
  const displayRows = equationTextFilter
    ? visibleRows.filter((row) => [row.label, row.text, `Page ${row.page}`].some((part) => String(part || '').toLocaleLowerCase().includes(equationTextFilter)))
    : visibleRows;
  const initialBatchSize = equationTextFilter ? displayRows.length : Math.max(500, previousRenderedEquationRows);
  let renderedRows = 0;
  let moreButton = null;
  const appendEquationRows = () => {
    if (renderedRows >= displayRows.length) return;
    if (moreButton) { moreButton.remove(); moreButton = null; }
    const until = Math.min(displayRows.length, renderedRows + (renderedRows === 0 ? initialBatchSize : 500));
    for (const entry of displayRows.slice(renderedRows, until)) {
    const row = document.createElement('div'); row.className = 'outline-edit-row equation-edit-row';
    const button = document.createElement('button'); button.type = 'button'; button.className = 'equation-index-item'; button.dataset.page=String(entry.page); button.dataset.confidence=entry.score >= 20 ? 'high' : entry.score >= 12 ? 'medium' : 'review';
    const copy=document.createElement('span'); copy.className='equation-index-copy';
    const label = document.createElement('strong'); label.textContent = entry.label;
    const meta = document.createElement('span'); meta.textContent = `${t(`Page ${entry.page}`, `第 ${entry.page} 页`)} · ${equationConfidenceTier(entry.score)}`;
    copy.append(label,meta); button.append(copy);
    button.title = entry.text || entry.label;
    button.addEventListener('click', async () => { equationIndex.querySelectorAll('.equation-edit-row.has-edit-menu').forEach((node) => node.classList.remove('has-edit-menu')); const target = verifiedEquationNavigationTarget(entry); await goToMatchedLocation(target.page, target.ratio, entry.label, { positionOnly: true }); updateBacklinksForTarget(entry.label, target); });
    const menu = document.createElement('button'); menu.type='button'; menu.className='outline-overflow-button'; menu.textContent='⋯'; menu.title=t('Edit equation','编辑公式'); menu.setAttribute('aria-label',menu.title); menu.setAttribute('aria-expanded','false');
    menu.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); const willOpen = !row.classList.contains('has-edit-menu'); equationIndex.querySelectorAll('.equation-edit-row.has-edit-menu').forEach((node) => { node.classList.remove('has-edit-menu'); node.querySelector('.outline-overflow-button')?.setAttribute('aria-expanded','false'); }); row.classList.toggle('has-edit-menu', willOpen); menu.setAttribute('aria-expanded', willOpen ? 'true' : 'false'); if (willOpen) requestAnimationFrame(() => positionOutlineEditActions(menu, actions)); });
    const actions = document.createElement('div'); actions.className = 'outline-edit-actions';
    const reselect = document.createElement('button'); reselect.type='button'; reselect.className='outline-edit-button'; reselect.textContent=t('Reselect','重新选择');
    reselect.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); row.classList.remove('has-edit-menu'); pendingEquationReselectKey = entry.manualEditId ? `edit:${entry.manualEditId}` : `label:${equationSourceLabelForDisplayed(entry.label)}`; pendingEquationAddKey = null; pendingOutlineReselectKey = null; refreshSelectionUI(); });
    const remove = document.createElement('button'); remove.type='button'; remove.className='outline-edit-button'; remove.textContent=t('Remove','移除');
    remove.addEventListener('click', (event) => {
      event.preventDefault(); event.stopPropagation(); row.classList.remove('has-edit-menu');
      if (entry.manualEditId) {
        const removedEdit = equationEdits.find((item) => item.action === 'add' && String(item.id) === String(entry.manualEditId));
        if (removedEdit) pushUndo('equation', entry.label || t('Equation','公式'), { mode:'added', edit: removedEdit });
        equationEdits = equationEdits.filter((item) => !(item.action === 'add' && String(item.id) === String(entry.manualEditId)));
      } else {
        const sourceLabel = equationSourceLabelForDisplayed(entry.label);
        const previousEdit = equationEdits.find((item) => item.action !== 'add' && normalizedEquationLabel(item.sourceLabel) === normalizedEquationLabel(sourceLabel)) || null;
        pushUndo('equation', entry.label || t('Equation','公式'), {
          mode:'source', sourceLabel, previousEdit,
          label:String(entry.label || sourceLabel), page:Number(entry.page)||1,
          ratio:Number(entry.ratio)||0, text:String(entry.text || entry.label || sourceLabel)
        });
        equationEdits = equationEdits.filter((item) => !(item.action !== 'add' && normalizedEquationLabel(item.sourceLabel) === normalizedEquationLabel(sourceLabel)));
        equationEdits.push({ action:'remove', sourceLabel });
      }
      pendingEquationReselectKey = null; pendingEquationAddKey = null;
      persistDocumentState();
      refreshEquationIndexAfterManualEdit().catch(() => {});
      refreshSelectionUI();
    });
    const add = document.createElement('button'); add.type='button'; add.className='outline-edit-button'; add.textContent=t('Add','添加');
    add.addEventListener('click', (event) => {
      event.preventDefault(); event.stopPropagation(); row.classList.remove('has-edit-menu');
      const sourceOrderKey = equationRowOrderKey(entry);
      if (!equationManualOrder.includes(sourceOrderKey)) {
        equationManualOrder = rows.map(equationRowOrderKey);
        persistDocumentState();
      }
      pendingEquationAddKey = entry.manualEditId ? `edit:${entry.manualEditId}` : entry.label;
      pendingEquationReselectKey = null; pendingOutlineReselectKey = null; refreshSelectionUI();
    });
    actions.append(reselect, remove, add);

    const orderKey = equationRowOrderKey(entry);
    row.draggable = true;
    row.dataset.equationOrderKey = orderKey;
    row.title = row.title || t('Drag to reorder equation', '拖动调整公式顺序');
    row.addEventListener('dragstart', (event) => {
      if (event.target?.closest?.('.outline-overflow-button,.outline-edit-actions')) { event.preventDefault(); return; }
      event.stopPropagation();
      draggedEquationKey = orderKey;
      row.classList.add('is-dragging-equation');
      try {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('application/x-mathreader-equation-row', orderKey);
        event.dataTransfer.setData('text/plain', orderKey);
      } catch (_) {}
    });
    row.addEventListener('dragend', (event) => {
      event.stopPropagation();
      draggedEquationKey = null;
      dragDepth = 0;
      dropOverlay?.classList.add('is-hidden');
      row.classList.remove('is-dragging-equation');
      equationIndex.querySelectorAll('.equation-edit-row.drag-target-before,.equation-edit-row.drag-target-after').forEach((node) => node.classList.remove('drag-target-before','drag-target-after'));
    });
    row.addEventListener('dragover', (event) => {
      if (!draggedEquationKey || draggedEquationKey === orderKey) return;
      event.preventDefault(); event.stopPropagation();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
      const rect = row.getBoundingClientRect();
      const before = event.clientY < rect.top + rect.height / 2;
      row.classList.toggle('drag-target-before', before);
      row.classList.toggle('drag-target-after', !before);
    });
    row.addEventListener('dragleave', (event) => { event.stopPropagation(); row.classList.remove('drag-target-before','drag-target-after'); });
    row.addEventListener('drop', (event) => {
      if (!draggedEquationKey || draggedEquationKey === orderKey) return;
      event.preventDefault(); event.stopPropagation();
      const rect = row.getBoundingClientRect();
      const before = event.clientY < rect.top + rect.height / 2;
      row.classList.remove('drag-target-before','drag-target-after');
      if (saveEquationDragOrder(rows, visibleRows, draggedEquationKey, orderKey, before)) renderEquationIndex();
    });

    if (entry.repeatedPrintedEquation) {
      // Remove/Reselect currently address a global printed label. Suppress
      // destructive, ambiguous actions for repeated chapter-local labels;
      // location navigation and ordering remain available independently.
      row.append(button);
      button.title = `${entry.text || entry.label} · ${t('Repeated number in different sections; edit by location is unavailable.', '不同章节重复编号；暂不支持按位置修改。')}`;
    } else row.append(button, menu, actions);
    equationIndex.append(row);
    }
    renderedRows = until;
    if (renderedRows < displayRows.length) {
      moreButton = document.createElement('button');
      moreButton.type = 'button'; moreButton.className = 'text-button';
      moreButton.textContent = t(`Show more equations (${displayRows.length - renderedRows})`, `显示更多公式（${displayRows.length - renderedRows}）`);
      moreButton.addEventListener('click', appendEquationRows);
      equationIndex.append(moreButton);
    }
    applyDocumentMapFilter(el('map-filter-equations'));
    updateDocumentMapCurrentLocation();
  };
  equationIndex.onscroll = () => {
    if (renderedRows < displayRows.length && equationIndex.scrollTop + equationIndex.clientHeight >= equationIndex.scrollHeight - 110) appendEquationRows();
  };
  appendEquationRows();
}

async function ensureEquationIndexRendered() {
  if (!pdfDoc) { renderEquationIndex(); return; }
  if (!documentTextFeaturesAvailable()) {
    // Imported reading-data may already contain a portable equation map. Do not
    // destroy it merely because the scanned PDF is open without OCR text.
    if (portableContentDetectionActive && equationLabelIndex) {
      renderEquationIndex();
      return equationLabelIndex;
    }
    equationLabelIndex = null;
    equationImageAssistPromise = null;
    equationAutomaticLabelIndex = null;
    equationSupplementalOcrCache = new Map();
    resetEquationDetectionProgress();
    updateEquationDetectionProgress({ phase: 'unavailable' }, equationDetectionGeneration, true);
    equationIndex?.replaceChildren();
    if (equationIndexCount) equationIndexCount.textContent = '0';
    if (equationIndexEmpty) { equationIndexEmpty.classList.remove('is-hidden'); equationIndexEmpty.textContent = t('Document text unavailable. Run full-document OCR to enable Equations.', '文档文本不可用。运行全文 OCR 后才能启用公式索引。'); }
    return new Map();
  }
  if (equationLabelIndex) { renderEquationIndex(); return equationLabelIndex; }
  if (equationIndexEmpty) { equationIndexEmpty.classList.remove('is-hidden'); equationIndexEmpty.textContent = t('Building equation-label index…', '正在生成公式编号索引……'); }
  try {
    if (!equationIndexBuildPromise) {
      // One bounded image-recovery pass on first reading, not on every reopen.
      // Existing manually saved equation edits are preserved through rebuilding.
      if (equationLabelIndex && !equationInitialRecoveryDone) {
        equationLabelIndex = null;
        equationAutomaticLabelIndex = null;
      }
      const initialImageOcr = !equationInitialRecoveryDone && !equationInitialRecoveryAttempted;
      if (initialImageOcr) equationInitialRecoveryAttempted = true;
      equationIndexBuildPromise = buildEquationLabelIndex({ initialImageOcr })
        .finally(() => { equationIndexBuildPromise = null; refreshEquationForceOcrButton(); });
      refreshEquationForceOcrButton();
    }
    await equationIndexBuildPromise;
    return equationLabelIndex;
  } catch (error) {
    console.warn('Equation-label index build failed', error);
    updateEquationDetectionProgress({ phase: 'failed' }, equationDetectionGeneration, true);
    if (equationIndexEmpty) equationIndexEmpty.textContent = t('The equation-label index could not be built.', '无法生成公式编号索引。');
  }
}

async function findEquationLabelLocation(query, originPage = null, originRatio = null) {
  const label = normalizedEquationLabel(query);
  const index = (await ensureEquationIndexRendered()) || new Map();
  const candidates = index.get(label) || [];
  let best = null;
  for (const candidate of candidates) {
    // Never resolve an inline equation reference back to the exact glyphs
    // that were clicked. This is the key distinction between a reference
    // occurrence in prose and the actual equation tag.
    if (candidate.page === originPage && Number.isFinite(originRatio) && Number.isFinite(candidate.ratio)
        && Math.abs(candidate.ratio - originRatio) < 0.018) continue;
    const confidence = Number.isFinite(candidate.confidence) ? candidate.confidence : equationCandidateConfidence(candidate, label);
    if (confidence < 8) continue;
    const score = equationTargetScore(candidate.text, label, originPage, candidate.page, originRatio, candidate.ratio) + confidence * 0.2;
    if (!best || score > best.score) best = { ...candidate, score };
  }
  return best ? { page: best.page, ratio: best.ratio } : null;
}

async function pageTextLines(pageNum, sourceDoc = pdfDoc, cache = lineCache, flatCache = textCache, { ignoreManual = false } = {}) {
  // A manual-OCR overlay and a native-text query have different semantics.
  // Do not reuse a shared cached overlay when native-only evidence is requested,
  // or an old native cache when a freshly restored manual overlay is present.
  // Native-only requests use a disposable cache to prevent contamination.
  if (ignoreManual && sourceDoc === pdfDoc
      && (manualIndexOcrPages.has(Number(pageNum)) || sourceDocumentUsesOcr(pageNum)) && cache === lineCache) {
    return pageTextLines(pageNum, sourceDoc, new Map(), null, { ignoreManual: true });
  }
  if (!ignoreManual && sourceDoc === pdfDoc && manualIndexOcrPages.has(Number(pageNum))) {
    const record = manualIndexOcrPages.get(Number(pageNum));
    const lines = (record.lines || []).map((line) => ({...line, ocrSource: true, parts: Array.isArray(line.parts) ? line.parts.map((part) => ({...part})) : []}));
    cache.set(pageNum, lines);
    if (flatCache) flatCache.set(pageNum, String(record.text || lines.map((line) => line.text).join(' ')).replace(/\s+/g, ' ').trim());
    return lines;
  }
  if (!ignoreManual && sourceDoc === pdfDoc && sourceDocumentUsesOcr(pageNum)) {
    const record = documentOcrPages.get(Number(pageNum));
    const lines = (record?.lines || []).map((line) => ({
      ...line,
      ocrSource: true,
      parts: Array.isArray(line.parts) ? line.parts.map((part) => ({ ...part })) : [],
    }));
    cache.set(pageNum, lines);
    if (flatCache) flatCache.set(pageNum, String(record?.text || lines.map((line) => line.text).join(' ')).replace(/\s+/g, ' ').trim());
    return lines;
  }
  if (cache.has(pageNum)) return cache.get(pageNum);
  const { page, content } = await nativePageTextData(sourceDoc, pageNum);
  const view = Array.isArray(page.view) ? page.view : [0, 0, 1, 1];
  const yMin = Number(view[1]) || 0;
  const yMax = Number(view[3]) || 1;
  const pageHeight = Math.max(1, yMax - yMin);
  const rows = [];
  const rowBuckets = new Map();
  for (const item of content.items || []) {
    const text = String(item.str || '').replace(/\s+/g, ' ').trim();
    if (!text) continue;
    const x = Number(item.transform?.[4]) || 0;
    const width = Math.max(0, Number(item.width) || 0);
    const y = Number(item.transform?.[5]) || 0;
    // Same first-match semantics as rows.find(), but only inspect y-nearby
    // rows. Dense PDF text pages otherwise make line construction quadratic.
    let row = findFirstRowInYBuckets(rowBuckets, y, 2.2, 2.2);
    if (!row) {
      row = { y, items: [], _rowOrder: rows.length };
      rows.push(row);
      addRowToYBuckets(rowBuckets, row, 2.2);
    }
    row.items.push({ x, width, text, height: Math.max(0, Number(item.height) || 0) });
  }
  rows.sort((a, b) => b.y - a.y);
  const pageWidth = Math.max(1, (Number(view[2]) || 1) - (Number(view[0]) || 0));
  const lines = rows.map((row) => {
    const items = row.items.sort((a, b) => a.x - b.x);
    let xMin = Infinity;
    let xMax = -Infinity;
    let maxHeight = 0;
    for (const item of items) {
      if (item.x < xMin) xMin = item.x;
      if (item.x + item.width > xMax) xMax = item.x + item.width;
      if (item.height > maxHeight) maxHeight = item.height;
    }
    const parts = [];
    let text = '';
    for (const item of items) {
      if (text) text += ' ';
      const start = text.length;
      text += item.text;
      parts.push({
        start,
        end: text.length,
        xStartRatio: Math.min(1, Math.max(0, (item.x - (Number(view[0]) || 0)) / pageWidth)),
        xEndRatio: Math.min(1, Math.max(0, (item.x + (item.width || 0) - (Number(view[0]) || 0)) / pageWidth))
      });
    }
    return {
      text: text.replace(/\s+/g, ' ').trim(),
      parts,
      ratio: Math.min(1, Math.max(0, (yMax - row.y) / pageHeight)),
      heightRatio: Math.min(0.08, Math.max(0.001, maxHeight / pageHeight)),
      xStartRatio: Math.min(1, Math.max(0, (xMin - (Number(view[0]) || 0)) / pageWidth)),
      xEndRatio: Math.min(1, Math.max(0, (xMax - (Number(view[0]) || 0)) / pageWidth))
    };
  }).filter((line) => line.text);
  cache.set(pageNum, lines);
  if (flatCache && !flatCache.has(pageNum)) flatCache.set(pageNum, lines.map((line) => line.text).join(' ').replace(/\s+/g, ' ').trim());
  return lines;
}


function bibliographyHeadingText(value) {
  return /^(?:references(?:\s+and\s+notes)?|notes\s+and\s+references|bibliography|literature\s+cited|参考文献|參考文獻|参考资料|參考資料|参考书目|參考書目)\s*[.:：]?$/iu.test(String(value || '').replace(/\s+/g, ' ').trim());
}

// Some older reference lists put authors on their own *preceding* line:
//   ADAMS, R.A.
//   [AR] Sobolev Spaces ...
// Never attach that author heading to the previous reference. Require an
// immediately following author-keyed row (not a prose citation), a left-margin
// author line and uppercase surname/initials evidence.
function bibliographyStandaloneAuthorHeading(line, nextLine) {
  const text = String(line?.text || '').replace(/\s+/g, ' ').trim();
  const nextText = String(nextLine?.text || '').replace(/\s+/g, ' ').trim();
  if (!text || !nextText || text.length > 105 || text.length < 6
      || Number(line?.xStartRatio) > 0.16 || Number(line?.xEndRatio) > 0.77
      || !/^\[\s*[A-Za-z][A-Za-z0-9\s]{0,11}\s*[\]}]/u.test(nextText)
      || Number(nextLine?.xStartRatio) > 0.25
      || Number(nextLine?.ratio) - Number(line?.ratio) > 0.037
      || Number(nextLine?.ratio) <= Number(line?.ratio)) return false;
  const initialSurname = /^(?:[A-ZÀ-ÖØ-Þ][A-ZÀ-ÖØ-Þ'’\- ]{1,50}),\s*(?:[A-Z]\.?){1,4}/u.test(text);
  if (!initialSurname) return false;
  const letters = [...text].filter((ch) => /\p{L}/u.test(ch));
  const uppercase = letters.filter((ch) => /\p{Lu}/u.test(ch)).length;
  return letters.length >= 4 && uppercase / letters.length >= 0.67
    && !/[=<>∫∑]/u.test(text);
}

function bibliographyRepairAuthorKeyBrace(text, line, hasAuthorHeading) {
  if (!hasAuthorHeading || Number(line?.xStartRatio) > 0.25) return text;
  return String(text || '').replace(/^\[\s*([A-Za-z][A-Za-z0-9\s]{1,10})\s*\}\s+(?=[A-ZÀ-ÖØ-Þ])/u,
    (_, key) => `[${key.trim()}] `);
}

function bibliographyEntryLooksCompleteForPostscript(entry) {
  const text = String(entry?.title || '').replace(/\s+/g, ' ').trim();
  if (!text) return false;
  return /\b(?:17|18|19|20)\d{2}\b/.test(text)
    && (/(?:\d{1,4}\s*[-–—]\s*\d{1,4}|\b(?:MR|Zbl)\s*\d+|\b(?:doi|arXiv)\b)/i.test(text) || /[.)]\s*$/.test(text));
}

function bibliographyPostscriptContactLine(line, text, activeEntry, entryCount, followingLines = []) {
  if (!activeEntry || entryCount < 3 || !bibliographyEntryLooksCompleteForPostscript(activeEntry)) return false;
  // A bibliography entry can itself contain an affiliation or a university
  // (e.g. a thesis institution). Do not mistake it for postscript contact
  // information while the NEXT numbered author citation is plainly visible.
  // This is sequence- and author-evidence based, not a title/page exception.
  const nextNumber = Number(activeEntry.number) + 1;
  if (Number.isInteger(nextNumber) && (followingLines || []).some((row) => {
    const match = String(row?.text || '').trim().match(/^\[\s*(\d{1,3})\s*\]\s+(.{12,})$/u);
    return match && Number(match[1]) === nextNumber
      && bibliographyReferenceBodyLooksStrong(match[2]);
  })) return false;
  const cleaned = String(text || '').replace(/\s+/g, ' ').trim();
  if (!cleaned || cleaned.length > 120) return false;
  if (/^E-?mail\s+address\b/i.test(cleaned)) return true;
  if (/^(?:School|Department|Faculty)\s+of\b/i.test(cleaned)) return true;
  if (/^(?:Institute|Instituto|Institut|Équipe|Equipe|EQU\s*IPE)\b/i.test(cleaned)) return true;
  if (/^(?:University\s+of\b|[A-Z][A-Za-zÀ-ÖØ-öø-ÿ.'’&\- ]{2,60}\s+University\b)/u.test(cleaned)) return true;
  const ratio = Number(line?.ratio || 0);
  const xStart = Number(line?.xStartRatio || 0);
  const authorSignature = /^(?:[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ.'’\-]+\s+){1,3}[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ.'’\-]+$/u.test(cleaned);
  return authorSignature && ratio >= 0.55 && xStart >= 0.45;
}

function repeatedBibliographyAuthorPrefix(entries) {
  const rows = Array.isArray(entries) ? entries : [];
  for (let index = rows.length - 1; index >= Math.max(0, rows.length - 6); index -= 1) {
    const title = String(rows[index]?.title || '').replace(/\s+/g, ' ').trim();
    const match = title.match(/^([^,]{2,80}),\s+/);
    if (!match) continue;
    const author = match[1].trim();
    const initialStyle = author.includes('.')
      && /^[A-Za-zÀ-ÖØ-öø-ÿ.'’&\- ]+$/u.test(author)
      && !/\b(?:of|the|in|on|for|with|sets|points)\b/i.test(author);
    const fullNameStyle = /^[A-ZÀ-ÖØ-Þ][a-zà-öø-ÿ'’.-]{2,}\s+[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’.-]{2,}$/u.test(author);
    if (initialStyle || fullNameStyle) return author;
  }
  return '';
}

function bibliographyLineFragment(line, parts, columnIndex = null) {
  if (!Array.isArray(parts) || !parts.length) return null;
  const source = String(line?.text || '');
  // The glyph offsets belong to the ORIGINAL PDF.js line. Collapsing spaces
  // before rebasing parts shifts every later token (including numbered keys),
  // and can silently change a bibliography hit into a neighboring reference.
  // Reject malformed bounds rather than turning out-of-range slices into
  // apparently valid reference text.
  const ordered = [...parts].sort((a, b) => Number(a.start) - Number(b.start));
  let start = source.length;
  let end = 0;
  let xStart = Infinity;
  let xEnd = -Infinity;
  for (const part of ordered) {
    const partStart = Number(part.start);
    const partEnd = Number(part.end);
    if (!Number.isInteger(partStart) || !Number.isInteger(partEnd)
        || partStart < 0 || partEnd <= partStart || partEnd > source.length) return null;
    start = Math.min(start, partStart);
    end = Math.max(end, partEnd);
    const xs = Number(part.xStartRatio);
    const xe = Number(part.xEndRatio);
    if (Number.isFinite(xs)) xStart = Math.min(xStart, xs);
    if (Number.isFinite(xe)) xEnd = Math.max(xEnd, xe);
  }
  const segment = source.slice(start, end);
  const leading = segment.search(/\S/);
  if (leading < 0) return null;
  const trailing = segment.match(/\s*$/u)?.[0]?.length || 0;
  const adjustedStart = start + leading;
  const adjustedEnd = end - trailing;
  if (adjustedEnd <= adjustedStart) return null;
  const fragmentParts = ordered.map((part) => ({
    ...part,
    start: Number(part.start) - adjustedStart,
    end: Number(part.end) - adjustedStart,
  }));
  return {
    ...line,
    text: source.slice(adjustedStart, adjustedEnd),
    parts: fragmentParts,
    xStartRatio: xStart === Infinity ? Number(line?.xStartRatio || 0) : xStart,
    xEndRatio: xEnd === -Infinity ? Number(line?.xEndRatio || 0) : xEnd,
    columnIndex,
  };
}

function bibliographyColumnAwareLines(rawLines, bibliographyAlreadyActive = false, includeBodyColumns = false) {
  const lines = Array.isArray(rawLines) ? rawLines : [];
  if (!lines.length) return lines;

  const splitRows = [];
  const strongColumnSplitRatios = [];
  for (const line of lines) {
    const parts = Array.isArray(line.parts) ? [...line.parts].sort((a, b) => Number(a.xStartRatio || 0) - Number(b.xStartRatio || 0)) : [];
    let bestGap = null;
    for (let index = 0; index + 1 < parts.length; index += 1) {
      const left = parts[index];
      const right = parts[index + 1];
      const gap = Number(right.xStartRatio || 0) - Number(left.xEndRatio || 0);
      if (Number(left.xEndRatio || 0) > 0.56 || Number(right.xStartRatio || 0) < 0.44
          || gap < (includeBodyColumns && !bibliographyAlreadyActive ? 0.032 : 0.04)) continue;
      if (!bestGap || gap > bestGap.gap) bestGap = { index, gap };
    }
    if (bestGap) {
      const left = bibliographyLineFragment(line, parts.slice(0, bestGap.index + 1), 0);
      const right = bibliographyLineFragment(line, parts.slice(bestGap.index + 1), 1);
      if (left && right) {
        splitRows.push(left, right);
        const ratio = Number(line.ratio || 0);
        // A real two-column row normally has substantial content anchored in
        // both outer halves. Old single-column text layers can contain large
        // internal gaps around formulas, page numbers, or journal metadata;
        // do not let those isolated gaps establish a column layout.
        if (Number(left.xStartRatio || 0) <= 0.18
            && Number(left.xEndRatio || 0) >= 0.28
            && Number(right.xStartRatio || 0) >= 0.46
            && Number(right.xEndRatio || 0) >= 0.70) strongColumnSplitRatios.push(ratio);
        continue;
      }
    }
    const columnIndex = Number(line.xEndRatio || 0) <= 0.56 ? 0 : (Number(line.xStartRatio || 0) >= 0.44 ? 1 : null);
    splitRows.push({ ...line, columnIndex });
  }

  const headingLines = splitRows.filter((line) => bibliographyHeadingText(line.text));
  const headingPresent = headingLines.length > 0;
  const headingRatio = headingPresent ? Math.min(...headingLines.map((line) => Number(line.ratio || 0))) : 0;
  // On a final two-column page the reference list can finish its left column
  // then continue at the TOP of the right column, above the left References
  // heading. Those right-column entries must not be discarded as pre-heading
  // text merely because their page-y coordinate is smaller.
  const rightReferencesAboveHeading = headingPresent
    && headingLines.some((line) => line.columnIndex === 0)
    && splitRows.some((line) => line.columnIndex === 1
      && Number(line.ratio) < headingRatio - 0.015
      && /^\[\s*\d{1,3}\s*\]\s+[\p{Lu}]/u.test(String(line.text || '').trim()));
  const relevant = (line) => bibliographyAlreadyActive || !headingPresent
    || rightReferencesAboveHeading || Number(line.ratio || 0) >= headingRatio - 0.02;
  const leftLines = splitRows.filter((line) => line.columnIndex === 0 && relevant(line));
  const rightLines = splitRows.filter((line) => line.columnIndex === 1 && relevant(line));
  const strongSplitCount = strongColumnSplitRatios.filter((ratio) => bibliographyAlreadyActive || ratio >= headingRatio - 0.02).length;
  const substantialColumnLine = (line) => {
    const span = Math.max(0, Number(line.xEndRatio || 0) - Number(line.xStartRatio || 0));
    return span >= 0.18 && String(line.text || '').trim().length >= 20;
  };
  const substantialLeftCount = leftLines.filter(substantialColumnLine).length;
  const substantialRightCount = rightLines.filter(substantialColumnLine).length;
  // Do not split ordinary Result/prose lines on a single unusual whitespace
  // gap. A genuine journal spread supplies repeated substantial fragments on
  // both sides and multiple independently split baselines.
  const confirmedBodyColumns = includeBodyColumns && !headingPresent
    && splitRows.length - lines.length >= 8
    && substantialLeftCount >= 7 && substantialRightCount >= 7;
  if (!bibliographyAlreadyActive && !headingPresent && !confirmedBodyColumns) return lines;
  const headingOnLeft = headingLines.some((line) => line.columnIndex === 0);
  const headingOnRight = headingLines.some((line) => line.columnIndex === 1);
  // A single-column bibliography with hanging keys can superficially resemble
  // two columns: short "[16]" rows sit at the left margin while their bodies
  // begin farther right. Do not reorder such pages unless there is comparable
  // key evidence in the right half. Reordering separates a key from its body.
  const leftHangingKeys = splitRows.filter((line) => Number(line.xStartRatio || 0) < 0.36 && /^\[\s*(?:\d{1,3}|[A-Za-z][A-Za-z0-9 ]{0,8})\s*\][.)]?$/.test(String(line.text || '').trim())).length;
  const rightHangingKeys = splitRows.filter((line) => Number(line.xStartRatio || 0) > 0.52 && /^\[\s*(?:\d{1,3}|[A-Za-z][A-Za-z0-9 ]{0,8})\s*\][.)]?$/.test(String(line.text || '').trim())).length;
  const hangingBodies = lines.filter((line) => Number(line.xStartRatio || 0) >= 0.18 && Number(line.xStartRatio || 0) <= 0.36 && Number(line.xEndRatio || 0) >= 0.62 && String(line.text || '').trim().length >= 24).length;
  const sameLineKeyLead = (line) => /^\[\s*(?:\d{1,3}|[A-Za-z][A-Za-z0-9 ]{0,8})\s*\][.)]?\s+\S/.test(String(line.text || '').trim());
  const leftSameLineKeyLeads = lines.filter((line) => Number(line.xStartRatio || 0) < 0.36 && Number(line.xEndRatio || 0) <= 0.48 && sameLineKeyLead(line)).length;
  const wideSameLineKeyLeads = lines.filter((line) => Number(line.xStartRatio || 0) < 0.36 && Number(line.xEndRatio || 0) >= 0.62 && sameLineKeyLead(line)).length;
  const rightSameLineKeyLeads = lines.filter((line) => Number(line.xStartRatio || 0) > 0.52 && sameLineKeyLead(line)).length;
  const singleColumnHangingBibliography = (leftHangingKeys >= 3 && rightHangingKeys === 0 && hangingBodies >= 3)
    || (leftSameLineKeyLeads >= 3 && rightSameLineKeyLeads === 0)
    // Full-width numbered references are also single-column evidence.  Italic
    // title/journal spans can create large internal PDF-text gaps that resemble
    // a column gutter even though each entry visibly crosses the page centre.
    || (wideSameLineKeyLeads >= 3 && rightSameLineKeyLeads === 0);
  const twoColumn = !singleColumnHangingBibliography && (
    confirmedBodyColumns || strongSplitCount >= 2
    || (substantialLeftCount >= 3 && substantialRightCount >= 3)
    || (headingOnRight && substantialRightCount >= 3 && (strongSplitCount >= 1 || substantialLeftCount >= 1))
    || (headingOnLeft && substantialLeftCount >= 3 && (strongSplitCount >= 1 || substantialRightCount >= 1))
  );
  if (!twoColumn) {
    // Do not retain speculative row splits when the page as a whole did not
    // establish a bibliography column layout. A single-column reference line
    // can contain a large internal gap (especially in old OCR/text layers),
    // but splitting it changes reading order and can manufacture entries.
    const starts = lines.map((line) => Number(line.xStartRatio || 0)).filter(Number.isFinite).sort((a, b) => a - b);
    const base = starts.length ? starts[Math.min(starts.length - 1, Math.floor(starts.length * 0.12))] : 0;
    const annotated = lines.map((line) => ({ ...line, columnStartRatio: base }));
    if (singleColumnHangingBibliography) {
      // PDF text layers sometimes emit a hanging key after its same-baseline
      // body fragment. Preserve visual reading order so `[17]` is seen before
      // the continuation that belongs to reference 17 rather than appended to
      // reference 16.
      annotated.sort((a, b) => {
        const ar = Number(a.ratio || 0); const br = Number(b.ratio || 0);
        if (Math.abs(ar - br) <= 0.0040) return Number(a.xStartRatio || 0) - Number(b.xStartRatio || 0);
        return ar - br;
      });
    }
    return annotated;
  }

  const columnStart = (columnLines) => {
    const starts = columnLines.map((line) => Number(line.xStartRatio || 0)).filter(Number.isFinite).sort((a, b) => a - b);
    return starts.length ? starts[Math.min(starts.length - 1, Math.floor(starts.length * 0.12))] : 0;
  };
  const leftStart = columnStart(leftLines);
  const rightStart = columnStart(rightLines);
  const annotate = (line) => ({
    ...line,
    columnStartRatio: line.columnIndex === 0 ? leftStart : (line.columnIndex === 1 ? rightStart : Number(line.xStartRatio || 0)),
  });
  // When an explicit References/Bibliography heading occurs part-way down a
  // page, it is a hard reading-order boundary.  A single-column reference list
  // can otherwise look two-column because keys and bodies occupy opposite
  // halves, causing pre-heading prose to be moved after live bibliography
  // entries and appended to them.  Preserve all pre-heading lines verbatim and
  // apply column ordering only at/after the heading.
  const headingBoundary = headingPresent && !rightReferencesAboveHeading ? headingRatio - 0.02 : -Infinity;
  const preHeading = headingPresent
    ? lines.filter((line) => Number(line.ratio || 0) < headingBoundary).map((line) => ({ ...line, columnStartRatio: Number(line.xStartRatio || 0) }))
    : [];
  const orderedSplitRows = headingPresent
    ? splitRows.filter((line) => Number(line.ratio || 0) >= headingBoundary)
    : splitRows;
  const fullWidth = orderedSplitRows.filter((line) => line.columnIndex === null).map(annotate);
  const headingFullWidth = headingPresent
    ? fullWidth.filter((line) => bibliographyHeadingText(line.text) || Number(line.ratio || 0) <= headingRatio + 0.015)
    : [];
  const topFullWidth = headingPresent
    ? []
    : fullWidth.filter((line) => Number(line.ratio || 0) < 0.18).sort((a, b) => Number(a.ratio || 0) - Number(b.ratio || 0));
  const headingFullWidthSet = new Set(headingFullWidth);
  const otherFullWidth = fullWidth
    .filter((line) => !headingFullWidthSet.has(line) && (headingPresent || Number(line.ratio || 0) >= 0.18))
    .sort((a, b) => Number(a.ratio || 0) - Number(b.ratio || 0));
  const visualColumnSort = (a, b) => {
    const ar = Number(a.ratio || 0); const br = Number(b.ratio || 0);
    if (Math.abs(ar - br) <= 0.0040) return Number(a.xStartRatio || 0) - Number(b.xStartRatio || 0);
    return ar - br;
  };
  return [
    ...preHeading,
    ...headingFullWidth.sort((a, b) => Number(a.ratio || 0) - Number(b.ratio || 0)),
    ...topFullWidth,
    ...leftLines.map(annotate).sort(visualColumnSort),
    ...rightLines.map(annotate).sort(visualColumnSort),
    ...otherFullWidth,
  ];
}

function bibliographyPersonNameChunk(value) {
  const cleaned = String(value || '').replace(/^[,;:\s]+|[,;:.\s]+$/g, '').replace(/^(?:and|&)\s+/i, '').trim();
  if (!cleaned || /\b(?:Journal|Proceedings?|Conference|Transactions?|University|Univ\.?|Press|Springer|arXiv|Vol(?:ume)?|pages?|Math\.?|Appl\.?|Analysis|Annals?|Comm\.?|Communications?|Proc\.?|Trans\.?|Arch\.?|Invent\.?|Acta|Bull\.?)\b/i.test(cleaned)) return false;
  const tokens = cleaned.split(/\s+/).filter((token) => !/^(?:de|del|di|du|la|le|van|von|da|dos|bin)$/i.test(token));
  if (tokens.length < 2 || tokens.length > 6) return false;
  let nameTokens = 0;
  for (const token of tokens) {
    const bare = token.replace(/[()]/g, '');
    if (/^(?:[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я]\.?|[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я][\p{L}'’.-]+)$/u.test(bare)) nameTokens += 1;
    else return false;
  }
  return nameTokens >= 2;
}

function fullNameBibliographyLead(text) {
  const value = String(text || '').replace(/\s+/g, ' ').trim();
  if (!value || /^(?:The|This|These|Those|We|Our|In|For|From|Figure|Table|Section|Appendix|Proof|Lemma|Theorem|Proposition|Corollary)\b/.test(value)) return false;
  // Wrapped publication metadata can superficially look like two capitalized
  // person-name tokens (for example “Math. J., ... 1976”). Such lines are
  // continuations, never starts of an unnumbered author-year reference.
  const journalAbbreviationContinuation = /^J\.\s+(?:Math|Amer|Appl|Stat|Comput|Phys|Differential|Funct|Algebra|Geom|Approx|Complex|Number|Fluid|Mech|ACM|IEEE)\b/i.test(value);
  if (journalAbbreviationContinuation
      || /^(?:Math\.?|Ann\.?|Comm\.?|Commun\.?|Proc\.?|Proceedings?|Trans\.?|Arch\.?|Invent\.?|Acta|Bull\.?|Vol\.?|Volume|No\.?|pp?\.?|t\.)\b/i.test(value)) return false;
  const yearMatch = value.match(/\b(?:17|18|19|20)\d{2}\b/);
  let authorRegion = yearMatch ? value.slice(0, yearMatch.index) : value.slice(0, 220);
  authorRegion = authorRegion.replace(/[.\s]+$/g, '').replace(/\s+(?:et\s+al\.)$/i, '').trim();
  const chunks = authorRegion.split(/\s*,\s*|\s+(?:and|&)\s+/).map((chunk) => chunk.trim()).filter(Boolean);
  let count = 0;
  for (const chunk of chunks.slice(0, 8)) {
    if (!bibliographyPersonNameChunk(chunk)) break;
    count += 1;
  }
  if (count >= 2 || (count >= 1 && Boolean(yearMatch))) return true;

  // Older AI/CS proceedings and many technical bibliographies use an
  // unnumbered single-author form such as
  //   "J. Stephen Judd. Learning in networks is hard. ... 1987."
  // or "Nimrod Megiddo. On The Complexity ... 1986.".  The period after
  // the author is a sentence boundary, not part of a comma/and-separated
  // author list, so the generic multi-author parser above otherwise consumes
  // the title and rejects the lead.  Accept only a *leading* person-name
  // prefix ending at a sentence break; final promotion still requires the
  // existing strong publication/year evidence in
  // unnumberedBibliographyTextLooksStrong().  Trying successive sentence
  // breaks also handles initials like "J. Stephen Judd." without treating
  // the first initial as the whole author.
  for (const match of authorRegion.matchAll(/\.\s+(?=[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я])/gu)) {
    let prefix = authorRegion.slice(0, match.index).trim();
    if (prefix.length > 140) break;
    prefix = prefix.replace(/,\s*(?:editors?|eds?\.?|compilers?)$/i, '').trim();
    if (bibliographyPersonNameChunk(prefix)) return true;
    const prefixChunks = prefix.split(/\s*,\s*|\s+(?:and|&)\s+/).map((chunk) => chunk.trim()).filter(Boolean);
    if (prefixChunks.length >= 2 && prefixChunks.length <= 8 && prefixChunks.every(bibliographyPersonNameChunk)) return true;
  }
  return false;
}

function unnumberedBibliographyTextLooksStrong(text) {
  const value = String(text || '').replace(/\s+/g, ' ').trim();
  if (value.length < 35 || !fullNameBibliographyLead(value) || !/\b(?:17|18|19|20)\d{2}\b/.test(value)) return false;
  let score = 0;
  if (/\b(?:Journal|Proceedings?|Conference|Transactions?|Communications?|Annals?|Springer|Press|University|arXiv|CoRR|IEEE|ACM|SIAM|NeurIPS|ICML|ICLR|ACL|EMNLP|CVPR)\b/i.test(value)) score += 2;
  if (/\b(?:vol(?:ume)?\.?|pages?|pp?\.|\d+\s*\(\d+\)\s*:\s*\d+)\b/i.test(value)) score += 1;
  if ((value.match(/[.]/g) || []).length >= 2) score += 1;
  if (value.length >= 80) score += 1;
  return score >= 2;
}

function bibliographyHeadingHasNearbyEntryEvidence(lines, headingIndex) {
  const list = Array.isArray(lines) ? lines : [];
  const heading = list[headingIndex] || null;
  const headingRatio = Number(heading?.ratio || 0);
  for (let index = headingIndex + 1; index < Math.min(list.length, headingIndex + 8); index += 1) {
    const line = list[index];
    const ratio = Number(line?.ratio || 0);
    if (Number.isFinite(headingRatio) && Number.isFinite(ratio) && ratio - headingRatio > 0.18) break;
    const value = String(line?.text || '').replace(/\s+/g, ' ').trim();
    if (!value || /^\d{1,4}$/.test(value)) continue;
    // A real references heading normally has an actual key or a strong
    // unnumbered author/year entry immediately below it.  Contents pages, by
    // contrast, are followed by page numbers or the next outline item.
    if (/^[\[{(]\s*(?:\d{1,3}|[A-Za-z][A-Za-z0-9.\-]{0,12})\s*[\]})]/.test(value)) return true;
    if (unnumberedBibliographyTextLooksStrong(value)) return true;
  }
  return false;
}

function bibliographyLineStartsAtColumn(line) {
  const x = Number(line?.xStartRatio || 0);
  const base = Number(line?.columnStartRatio);
  if (!Number.isFinite(base)) return true;
  return x <= base + 0.018;
}

function bibliographyLineLooksLikeHeaderOrFooter(line, cleaned) {
  const value = String(cleaned || '').replace(/\s+/g, ' ').trim();
  const ratio = Number(line?.ratio || 0);
  const xStart = Number(line?.xStartRatio || 0);
  const topHeaderLike = ratio < 0.10 && (
    /^\d{1,4}\s+[A-Z][A-Z0-9 .,:;'’"()\-]{4,}$/u.test(value)
    || /^[A-Z][A-Z0-9 .,:;'’"()\-]{4,}\s+\d{1,4}$/u.test(value)
  );
  // Journals/books often split running headers into separate page-number and
  // centered author/title lines.  Do not append that header to the previous
  // bibliography entry. Keep the geometry narrow so left-aligned real author
  // lines at the top of a references page remain valid content.
  const topCenteredRunningHeader = ratio < 0.125
    && xStart > 0.28
    && value.length >= 4 && value.length <= 80
    && (/^[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я][A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я0-9 .,&'’\-:]+$/u.test(value)
      || /^(?:[A-Z]\.?\s*){1,4}[A-ZÀ-ÖØ-Þ][\p{L}'’.-]{2,40}(?:\s*(?:&|and)\s*(?:[A-Z]\.?\s*){0,4}[A-ZÀ-ÖØ-Þ][\p{L}'’.-]{2,40})?$/u.test(value));
  return topHeaderLike
    || topCenteredRunningHeader
    || (ratio > 0.91 && value.length < 100)
    || /^\d{1,4}\s+[A-Z][A-Z .,'’'-]{2,}$/u.test(value)
    || /^(?:(?:I\s+)?manuscrit\s+reçu|received|revised|department\s+of|annales\s+de|license\s+or\s+copyright\s+restrictions)\b/i.test(value);
}

function normalizedBibliographyKey(value) {
  return String(value || '').replace(/^\s*\[|\]\s*$/g, '').replace(/\s+/g, '').trim().toLocaleLowerCase();
}

// Math uses square brackets for matrix indices and set notation as well as
// citations. Do not manufacture reference backlinks from a directly adjacent
// mathematical variable (A[1,2], D_t [1,1]) or from set-index brackets.
function bibliographyBracketIsMathematicalIndex(text, start, raw) {
  const inner = String(raw || '').slice(1, -1);
  if (/[{}=∪∩⊆⊂∈∉\\]/u.test(inner)) return true;
  const before = String(text || '').slice(0, Math.max(0, start)).trimEnd();
  return /(?:^|[^\p{L}])(?:[A-Z\p{Lu}])(?:\s+[\p{Ll}\p{N}])?\s*$/u.test(before);
}

function bibliographyCitationKeys(raw, knownKeys = null) {
  const inner = String(raw || '').replace(/^\s*\[|\]\s*$/g, '').trim();
  if (!inner || /[{}=∪∩⊆⊂∈∉\\]/u.test(inner)) return [];
  const keys = [];
  const accept = (value) => {
    const key = normalizedBibliographyKey(value);
    if (!key || (knownKeys && !knownKeys.has(key)) || keys.includes(key)) return;
    keys.push(key);
  };
  for (const part of inner.split(/[;,]/)) {
    const token = part.trim();
    const numericRange = token.match(/^(\d{1,3})\s*[-–—]\s*(\d{1,3})$/);
    if (numericRange) {
      const start = Number(numericRange[1]);
      const end = Number(numericRange[2]);
      if (Math.abs(end - start) <= 80) {
        const step = start <= end ? 1 : -1;
        for (let value = start; value !== end + step; value += step) accept(String(value));
      }
      continue;
    }
    // Do not guess the syntax of author-style bibliography keys. When the
    // bibliography is known, exact normalized key membership is authoritative.
    accept(token);
  }
  return keys;
}

function bibliographyMetadata(text) {
  const value = String(text || '');
  // DOI suffixes may legitimately contain balanced parentheses (including
  // nested ones). Only strip a closing parenthesis when it is unmatched;
  // punctuation belonging to the surrounding sentence is not part of a DOI.
  let doi = value.match(/\b10\.\d{4,9}\/[\-._;()/:A-Z0-9]+/i)?.[0] || '';
  while (doi && /[.,;)]$/.test(doi)) {
    if (doi.endsWith(')')) {
      const opens = (doi.match(/\(/g) || []).length;
      const closes = (doi.match(/\)/g) || []).length;
      if (closes <= opens) break;
    }
    doi = doi.slice(0, -1);
  }
  const arxiv = value.match(/\barXiv\s*:\s*([a-z.-]+\/\d{7}|\d{4}\.\d{4,5})(?:v\d+)?/i)?.[1] || '';
  return { doi, arxiv };
}


function bibliographyReferenceBodyLooksStrong(text) {
  const value = String(text || '').replace(/\s+/g, ' ').trim();
  if (value.length < 12 || !/^[\p{L}]/u.test(value)) return false;
  let score = 0;
  if (/^[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я]/u.test(value)) score += 1;
  if (/^(?:(?:[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я][.\-–—·]{1,5}\s+){1,4})[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я][\p{L}'’.-]{1,40}\s*,/u.test(value)
      || /^[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я][\p{L}'’.-]{1,40},\s+(?:(?:[A-ZÀ-ÖØ-ÞΑ-ΩЁА-Я][.\-–—·]{0,5}\s*){1,4})/u.test(value)) score += 2;
  if (/\b(?:17|18|19|20)\d{2}\b/.test(value)) score += 2;
  if (/\b(?:Ann\.?|Math\.?|Journal|J\.?\s|Proc\.?|Proceedings?|Trans\.?|Communications?|Comm\.?|Springer|Press|Verlag|University|Acad(?:emy)?|Acta|Inventiones|Topology|Bull\.?)\b/i.test(value)) score += 2;
  if ((value.match(/,/g) || []).length >= 2) score += 1;
  if (value.length >= 42) score += 1;
  return score >= 3;
}

function damagedOcrBibliographyKeyDigits(raw) {
  // Only confusable glyphs that resemble digits in short *numbered* keys.
  // Never apply to author-keyed references or ordinary prose.
  const digits = String(raw || '').replace(/[lI|]/g, '1').replace(/[Oo]/g, '0').replace(/[Ss]/g, '5');
  return /^\d{1,3}$/.test(digits) ? digits : '';
}

function repairOcrExpectedBibliographyKey(text, line, expected) {
  // Scanned journal references can lose the closing bracket entirely, replace
  // it with comma punctuation, or render [11] as {ll}, [l1, etc. Anchor the
  // repair to the *next already-established* numeric key, the OCR-only left
  // margin, and a strong bibliographic body so body citations do not qualify.
  if (!line?.ocrSource || expected < 2 || expected > 999 || Number(line.xStartRatio || 0) >= 0.20) return text;
  // A damaged *opening* bracket is a separate old-scan class: "2] A. Borel".
  // Require the surviving closing delimiter plus the same sequence/body gates.
  const match = String(text || '').match(/^[\[{(]\s*([0-9lI|OoSs]{1,3})\s*(?:[\]})])?\s*[,;:.]?\s+(.{12,})$/u)
    || String(text || '').match(/^([0-9lI|OoSs]{1,3})\s*[\]})]\s+(.{12,})$/u);
  if (!match) return text;
  if (damagedOcrBibliographyKeyDigits(match[1]) !== String(expected) || !bibliographyReferenceBodyLooksStrong(match[2])) return text;
  return `[${expected}] ${match[2]}`;
}

function repairOcrExpectedBibliographyKeyOnly(text, line, expected, establishedCount) {
  // PSM-11 and some PDF OCR layers place the damaged numeric marker on its
  // own line and the bibliography body on the next line. Preserve a pending
  // numeric key only if a real numbered series is already established; the
  // existing pending-key handler then attaches the following text rather than
  // appending it to the preceding reference.
  if (!line?.ocrSource || establishedCount < 3 || expected < 2 || expected > 999
      || Number(line.xStartRatio || 0) >= 0.20) return text;
  const match = String(text || '').match(/^[\[{(]\s*([0-9lI|OoSs]{1,3})\s*(?:[\]})])?\s*[,;:.]?$/u);
  if (!match || damagedOcrBibliographyKeyDigits(match[1]) !== String(expected)) return text;
  return `[${expected}]`;
}

function malformedNumericBibliographyCandidate(text, line, page) {
  if (Number(line?.xStartRatio || 0) >= 0.22) return null;
  // A scan may fuse the opening bracket and the first two narrow digits into
  // a short shape such as "tl) , Title ..." for the printed "[11] , Title ...".
  // Never accept this as a key directly: retain it only as *possible* evidence
  // for one missing number bounded by two exact adjacent bibliography keys.
  // The comma after the closing mark is characteristic of old ditto-author
  // bibliography lines, and the body must independently look bibliographic.
  const closedDitto = line?.ocrSource && Number(line.xStartRatio || 0) < 0.18
    ? String(text || '').match(/^([1lI|t]{2,3})\)\s*[,;:]\s+(.{20,})$/u)
    : null;
  if (closedDitto) {
    const digitText = closedDitto[1].replace(/[lI|t]/g, '1');
    const body = closedDitto[2].trim();
    if (/^\d{2,3}$/.test(digitText) && bibliographyReferenceBodyLooksStrong(body)) {
      return {
        token: closedDitto[1] + ')', digitText, bracketedSingleGlyph: false,
        body, page, ratio: Number(line.ratio || 0),
        xStartRatio: Number(line.xStartRatio || 0),
        ocrSource: Boolean(line.ocrSource),
        used: false, continuations: [], closedOcrDitto: true
      };
    }
  }
  // On degraded scans, a numbered key may retain its opening delimiter
  // but lose the closing delimiter and read a narrow "1" as "j":
  // "{lj , Global properties ...". Keep this as *candidate evidence* only.
  // The final pass requires one unique missing key between two exact numeric
  // neighbors; an isolated OCR token never creates a bibliography entry.
  const openDitto = line?.ocrSource && Number(line.xStartRatio || 0) < 0.18
    ? String(text || '').match(/^[\[{(]\s*([1lI|tj]{2,3})\s*[,;:]\s+(.{20,})$/u)
    : null;
  if (openDitto) {
    const digitText = openDitto[1].replace(/[lI|tj]/g, '1');
    const body = openDitto[2].trim();
    if (/^\d{2,3}$/.test(digitText) && bibliographyReferenceBodyLooksStrong(body)) {
      return {
        token: openDitto[1], digitText, bracketedSingleGlyph: false,
        body, page, ratio: Number(line.ratio || 0),
        xStartRatio: Number(line.xStartRatio || 0),
        ocrSource: true, used: false, continuations: [], openOcrDitto: true
      };
    }
  }
  const match = String(text || '').match(/^(\S{2,8})\s+(.{8,})$/u);
  if (!match) return null;
  const token = match[1];
  const body = match[2].trim();
  if (!/^[\[{(]/u.test(token)) return null;
  if (/^\[\s*\d{1,3}\s*\][.)]?$/u.test(token)) return null;
  if (/^\[\s*[A-Za-z][A-Za-z0-9\s]{0,12}\s*\][.)]?$/u.test(token)) return null;
  if (!bibliographyReferenceBodyLooksStrong(body)) return null;

  const compact = Array.from(token).length <= 6;
  if (!compact) return null;
  const digitText = (token.match(/\d/g) || []).join('');
  const bracketedSingleGlyph = /^[\[{(]\s*[^\s\]})]{1}\s*[\]})][.)]?$/u.test(token);
  const digitBearing = digitText.length >= 1 && digitText.length <= 3;
  if (!digitBearing && !bracketedSingleGlyph) return null;

  return {
    token,
    digitText,
    bracketedSingleGlyph,
    body,
    page,
    ratio: Number(line?.ratio || 0),
    xStartRatio: Number(line?.xStartRatio || 0),
    ocrSource: Boolean(line?.ocrSource),
    used: false,
    continuations: []
  };
}

function bibliographyDocumentPosition(item) {
  return (Number(item?.page || 0) * 2) + Math.min(1, Math.max(0, Number(item?.ratio || 0)));
}

function recoverSingleGapBibliographyCandidates(entries, candidates) {
  const numericEntries = entries
    .map((entry) => ({ entry, value: Number(normalizedBibliographyKey(entry.number)) }))
    .filter((item) => Number.isInteger(item.value) && item.value >= 1 && item.value <= 999)
    .sort((a, b) => bibliographyDocumentPosition(a.entry) - bibliographyDocumentPosition(b.entry));
  if (numericEntries.length < 2 || !Array.isArray(candidates) || !candidates.length) return 0;

  let recoveredCount = 0;
  const existingKeys = new Set(entries.map((entry) => normalizedBibliographyKey(entry.number)));

  // Old scans can render the first numbered bibliography marker [1] as
  // {i}, (l), [I], etc.  This is not safe to guess at the start of a section:
  // require a mature exact [2], [3], [4] sequence, a *single* OCR-only
  // bracketed-digit-confusable candidate immediately before [2], the same
  // bibliography page/left margin, and independently bibliographic text.
  // Author-key [B] and unpaired snippets must remain untouched.
  if (numericEntries.length >= 3
      && numericEntries[0].value === 2
      && numericEntries[1].value === 3
      && numericEntries[2].value === 4
      && !existingKeys.has('1')) {
    const first = numericEntries[0].entry;
    const compatible = candidates.filter((candidate) => {
      if (candidate.used || !candidate.ocrSource || !candidate.bracketedSingleGlyph
          || candidate.digitText || Number(candidate.xStartRatio) >= 0.18
          || Number(candidate.page) !== Number(first.page)) return false;
      if (!/^[\[{(]\s*[iIl|]\s*[\]})][.)]?$/u.test(String(candidate.token || ''))) return false;
      const distance = Number(first.ratio) - Number(candidate.ratio);
      if (!(distance > 0 && distance <= 0.22)) return false;
      const fullBody = [candidate.body, ...(candidate.continuations || [])].join(' ').replace(/\s+/g, ' ').trim();
      return bibliographyReferenceBodyLooksStrong(fullBody);
    });
    if (compatible.length === 1) {
      const candidate = compatible[0];
      const fullBody = [candidate.body, ...(candidate.continuations || [])].join(' ').replace(/\s+/g, ' ').trim();
      const recovered = {
        number: 1, label: '[1]', page: candidate.page, ratio: candidate.ratio,
        title: fullBody.slice(0, 640), citations: [], ...bibliographyMetadata(fullBody)
      };
      const insertAt = entries.indexOf(first);
      entries.splice(insertAt >= 0 ? insertAt : 0, 0, recovered);
      existingKeys.add('1');
      candidate.used = true;
      recoveredCount += 1;
    }
  }

  for (let index = 0; index + 1 < numericEntries.length; index += 1) {
    const left = numericEntries[index];
    const right = numericEntries[index + 1];
    if (right.value !== left.value + 2) continue;
    const missing = left.value + 1;
    if (existingKeys.has(String(missing))) continue;
    const leftPos = bibliographyDocumentPosition(left.entry);
    const rightPos = bibliographyDocumentPosition(right.entry);
    const compatible = candidates.filter((candidate) => {
      // Single-gap repair is OCR evidence, never a substitute for native text.
      // A math token in the middle of the page or an author-key [B] must not
      // silently manufacture a numbered bibliography reference.
      if (candidate.used || !candidate.ocrSource
          || !Number.isFinite(Number(candidate.xStartRatio))
          || Number(candidate.xStartRatio) >= 0.22) return false;
      const position = bibliographyDocumentPosition(candidate);
      if (!(position > leftPos && position < rightPos)) return false;
      if (candidate.digitText) return Number(candidate.digitText) === missing;
      return candidate.bracketedSingleGlyph
        && /^[\[{(]\s*[iIl|OoSs]\s*[\]})][.)]?$/u.test(String(candidate.token || ''));
    });
    if (compatible.length !== 1) continue;

    const candidate = compatible[0];
    const fullBody = [candidate.body, ...(candidate.continuations || [])].join(' ').replace(/\s+/g, ' ').trim();
    if (!bibliographyReferenceBodyLooksStrong(fullBody)) continue;
    const meta = bibliographyMetadata(fullBody);
    const recovered = {
      number: missing,
      label: `[${missing}]`,
      page: candidate.page,
      ratio: candidate.ratio,
      title: fullBody.slice(0, 640),
      citations: [],
      ...meta
    };
    const insertAt = entries.indexOf(right.entry);
    entries.splice(insertAt >= 0 ? insertAt : entries.length, 0, recovered);
    existingKeys.add(String(missing));
    candidate.used = true;
    recoveredCount += 1;
  }
  return recoveredCount;
}

function pruneIsolatedNumericEntriesFromAuthorKeyBibliography(entries) {
  const list = Array.isArray(entries) ? entries : [];
  const numeric = list.filter((entry) => /^\d{1,3}$/.test(normalizedBibliographyKey(entry?.number)));
  const authorKeyed = list.filter((entry) => {
    const key = normalizedBibliographyKey(entry?.number);
    return key && !/^\d{1,3}$/.test(key);
  });
  // A mature author-key bibliography does not acquire one stray numeric key
  // from a continuation line. Preserve mixed schemes when a numeric family is
  // actually present, and preserve any isolated numeric key that is cited in
  // the body. SPS-style phantom [11] entries have neither form of support.
  if (authorKeyed.length < 5 || numeric.length === 0 || numeric.length >= 3) return list;
  const rejected = new Set(
    numeric
      .filter((entry) => !Array.isArray(entry?.citations) || entry.citations.length === 0)
      .map((entry) => entry)
  );
  return rejected.size ? list.filter((entry) => !rejected.has(entry)) : list;
}

// Resolve repeated chapter-local labels in printed order. A forward-only
// declaration is not evidence of a proof dependency or derived corollary.
// Keep unknown coordinates conservative instead of interpreting null as zero.
function resolveStructureReferenceOccurrence(candidates, owner) {
  if (!Array.isArray(candidates) || !owner) return null;
  const ownerPage = Number(owner.proofPage ?? owner.page);
  const ownerRatio = owner.proofRatio ?? owner.ratio;
  if (!Number.isInteger(ownerPage) || ownerPage < 1) return null;
  const ratioValid = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1;
  const matches = candidates.filter((entry) => {
    const page = Number(entry?.page);
    if (entry === owner || !Number.isInteger(page) || page < 1 || page > ownerPage) return false;
    // Same-page occurrences need measured positions when the owner has one.
    if (page === ownerPage && ratioValid(ownerRatio)) {
      if (!ratioValid(entry?.ratio) || entry.ratio > ownerRatio) return false;
    }
    return true;
  });
  matches.sort((a, b) => {
    const pageDiff = Number(b.page) - Number(a.page);
    if (pageDiff) return pageDiff;
    const ar = ratioValid(a.ratio) ? a.ratio : -1;
    const br = ratioValid(b.ratio) ? b.ratio : -1;
    return br - ar;
  });
  return matches[0] || null;
}

function credibleStructureProofReferences(owner, structureByLabel) {
  const output = [];
  const seen = new Set();
  const ownKey = normalizedStructureResultReference(owner?.label);
  for (const raw of owner?.proofReferences || []) {
    const reference = String(raw || '').trim();
    if (!reference) continue;
    const key = normalizedStructureResultReference(reference);
    const target = structureByLabel?.get(key);
    // A lone alphabetic identifier is indistinguishable from prose such as
    // "the example u" unless another detection supplies its exact Result.
    if (!target && /^(?:Theorem|Lemma|Proposition|Corollary|Definition|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+[A-Z]{1,2}$/i.test(reference)) continue;
    const label = target?.label || reference;
    const canonical = normalizedStructureResultReference(label);
    if (!canonical || canonical === ownKey || seen.has(canonical)) continue;
    seen.add(canonical);
    output.push(label);
  }
  return output;
}

async function buildStructureIndex({ force = false } = {}) {
  if (!pdfDoc || !documentTextFeaturesAvailable() || !structureIndex || structureIndexBuilding) return;
  if (force && pendingOutlineReselectKey) { pendingOutlineReselectKey = null; refreshSelectionUI(); }
  if (!force && structureIndexVersion === STRUCTURE_INDEX_VERSION) {
    renderStructureIndex(); renderBibliographyIndex();
    return;
  }

  const sourceDoc = pdfDoc;
  const sourceKey = currentFileKey;
  const sourceTextCache = textCache;
  const sourceLineCache = lineCache;
  const token = ++structureIndexBuildToken;
  structureIndexBuilding = true;
  buildStructureIndexButton.disabled = true;
  if (typeof detectionRebuildIndexButton !== 'undefined' && detectionRebuildIndexButton) detectionRebuildIndexButton.disabled = true;
  structureEmpty.classList.remove('is-hidden');
  structureEmpty.textContent = t('Building mathematical structure in the background…', '正在后台生成数学结构索引……');
  if (bibliographyEmpty) { bibliographyEmpty.classList.remove('is-hidden'); bibliographyEmpty.textContent = t('Detecting bibliography entries…', '正在检测参考文献条目……'); }

  const nextEntries = [];
  const nextBibliography = [];
  const bibliographyCitationGroups = [];
  const bibliographyRecoveryCandidates = [];
  let bibliographyMode = false;
  let pendingBibliographyKey = null;
  let syntheticBibliographyMode = null;
  let activeBibliographyEntry = null;
  let currentBibliographyAuthorHeading = '';
  const bibliographyLastPosition = new WeakMap();
  let activeBibliographyRecoveryCandidate = null;
  let pendingUnnumberedBibliographyEntry = null;
  let activeProofEntry = null;
  const ambiguousAppendixResultObservations = [];
  let resultsIndexMode = false;
  try {
    // Structure stays bounded for performance, but old books and long technical
    // texts often place References far beyond page 800. Always include a tail
    // window so Bibliography can still be complete without scanning thousands
    // of middle pages.
    const primaryPageCount = Math.min(sourceDoc.numPages, 800);
    const pageSequence = Array.from({ length: primaryPageCount }, (_, index) => index + 1);
    if (sourceDoc.numPages > primaryPageCount) {
      const tailStart = Math.max(primaryPageCount + 1, sourceDoc.numPages - 119);
      for (let page = tailStart; page <= sourceDoc.numPages; page += 1) pageSequence.push(page);
    }
    for await (const { item: page, value: rawLines } of orderedPrefetch(
      pageSequence,
      (pageNum) => pageTextLines(pageNum, sourceDoc, sourceLineCache, sourceTextCache),
      3
    )) {
      if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey || token !== structureIndexBuildToken) return;
      const tailOnlyPage = page > primaryPageCount;
      const lines = bibliographyColumnAwareLines(rawLines, bibliographyMode, true);
      const tocResultRows = tailOnlyPage ? new Set() : tocResultLineIndices(lines, page, sourceDoc.numPages);
      // A back-of-book Subject Index continues after its title page. Its
      // continuation pages must not contribute phantom results such as
      // "Theorem 125" (a subject-index folio).
      const currentResultsIndexHeading = !tailOnlyPage && structureResultsIndexNavigationPage(lines);
      if (currentResultsIndexHeading && page >= Math.floor(sourceDoc.numPages * 0.8)) resultsIndexMode = true;
      // Rare books place appendices after the index. Restart Results only if
      // a real top-of-page Appendix/Chapter marker explicitly begins again.
      if (resultsIndexMode && !currentResultsIndexHeading && lines.some((row) =>
        Number(row?.ratio ?? 1) <= 0.19
        && /^(?:Appendix\s+[A-Z](?:\.\s+[^0-9].*)?|Chapter\s+\d+(?:\.\s+[^0-9].*)?)$/i.test(String(row?.text || '').trim()))) {
        resultsIndexMode = false;
      }
      const indexNavigationPage = currentResultsIndexHeading || resultsIndexMode;
      for (let lineIndex = 0; lineIndex < lines.length; lineIndex += 1) {
        const line = lines[lineIndex];
        const cleaned = String(line.text || '').replace(/\s+/g, ' ').trim();
        if (!cleaned) continue;
        if (bibliographyHeadingText(cleaned)) {
          // Contents pages in books often contain a standalone "Bibliography"
          // item near the front. Treat a heading as the real bibliography only
          // in the latter part of longer documents; repeated running headers on
          // subsequent bibliography pages keep the established numbering mode.
          const bibliographyHeadingEligible = page >= Math.max(2, Math.floor(sourceDoc.numPages * 0.35))
            || bibliographyHeadingHasNearbyEntryEvidence(lines, lineIndex)
            || (page === 1 && Number(line.ratio || 0) >= 0.78);
          if (bibliographyHeadingEligible) {
            if (!bibliographyMode) syntheticBibliographyMode = null;
            bibliographyMode = true; pendingBibliographyKey = null; pendingUnnumberedBibliographyEntry = null; activeBibliographyEntry = null; activeBibliographyRecoveryCandidate = null; activeProofEntry = null;
          }
          continue;
        }
        if (bibliographyMode && /^(?:glossary(?:\s+of\s+notation)?|index)\s*[.:]?$/i.test(cleaned)) {
          bibliographyMode = false; pendingBibliographyKey = null; pendingUnnumberedBibliographyEntry = null; activeBibliographyEntry = null; activeBibliographyRecoveryCandidate = null; continue;
        }

        if (!bibliographyMode && !tailOnlyPage) {
          const bracketRe = /\[[^\]]{1,60}\]/g;
          let bracketMatch;
          while ((bracketMatch = bracketRe.exec(cleaned))) {
            const raw = bracketMatch[0];
            if (bibliographyBracketIsMathematicalIndex(cleaned, bracketMatch.index, raw)) continue;
            bibliographyCitationGroups.push({
              page,
              ratio: line.ratio,
              raw,
              snippet: backlinkSnippet(cleaned, raw, bracketMatch.index),
              matchIndex: bracketMatch.index
            });
          }
        }

        if (!tailOnlyPage) {
          // Result headings must begin the extracted visual line. Classical
          // papers also use spaced numbering ("Lemma 2 . 3"), number-first
          // forms ("1.1. LEMMA"), and a standalone type line next to its
          // number. Normalize only these declaration shapes; prose references
          // such as "Proposition 2.1 shows ..." stay out of Results.
          const detectedResult = indexNavigationPage || tocResultRows.has(lineIndex)
            ? null : detectedStructureResult(lines, lineIndex, page);
          if (detectedResult?.ambiguousAppendixOCR) {
            ambiguousAppendixResultObservations.push(detectedResult);
          } else if (detectedResult) {
            const key = `${page}:${normalizedReferenceLabel(detectedResult.label)}`;
            if (!nextEntries.some((entry) => entry.key === key)) {
              const entry = { key, ...detectedResult,
                declarationXStartRatio: Number.isFinite(Number(line.xStartRatio)) ? Number(line.xStartRatio) : null,
                proofReferences: [], usedByProofs: [] };
              nextEntries.push(entry); activeProofEntry = entry;
            }
          }
  
          const proofMatch = resultProofHeading(cleaned);
          if (proofMatch) {
            const target = proofMatch.explicitTarget && !proofMatch.printedReference ? null
              : resultProofTarget(nextEntries, proofMatch.printedReference, page, line);
            // Clear the previous proof's reference collector even if the
            // explicitly printed target is missing or already has a proof.
            // Otherwise references on this unrelated proof leak backwards.
            activeProofEntry = null;
            if (target && !target.proofPage) {
              target.proofPage = page; target.proofRatio = line.ratio;
              target.proofXStartRatio = line?.xStartRatio == null || !Number.isFinite(Number(line.xStartRatio))
                ? null : Number(line.xStartRatio);
              target.proofTitle = proofMatch.printedReference ? `Proof of ${proofMatch.printedReference}` : 'Proof';
              activeProofEntry = target;
            }
          }
          if (activeProofEntry && activeProofEntry.proofPage) {
            // Side-by-side text columns are not a single proof. Do not let
            // an unrelated column contaminate its dependency graph.
            const sameProofColumn = proofLineSameColumn(activeProofEntry.proofXStartRatio, line?.xStartRatio);
            const references = sameProofColumn ? (cleaned.match(STRUCTURE_REFERENCE_RE) || []) : [];
            for (const reference of references) {
              const normalizedRef = normalizedReferenceLabel(reference);
              if (!normalizedRef || normalizedRef === normalizedReferenceLabel(activeProofEntry.label)) continue;
              if (!activeProofEntry.proofReferences.includes(reference)) activeProofEntry.proofReferences.push(reference);
            }
          }
  
          if (activeProofEntry
            && proofLineSameColumn(activeProofEntry.proofXStartRatio, line?.xStartRatio)
            && /(?:\bQ\.?\s*E\.?\s*D\.?\b|[□∎])/.test(cleaned)) {
            activeProofEntry.proofEndPage = page; activeProofEntry.proofEndRatio = line.ratio; activeProofEntry = null;
          }
        }

        if (bibliographyMode) {
          // The author heading immediately above a keyed reference is neither
          // a continuation of the preceding citation nor a separate entry.
          if (bibliographyStandaloneAuthorHeading(line, lines[lineIndex + 1])) {
            currentBibliographyAuthorHeading = cleaned;
            activeBibliographyEntry = null;
            activeBibliographyRecoveryCandidate = null;
            continue;
          }
          const addBibliographyEntry = (rawKey, body, bracketKey = true, entryPage = page, entryRatio = line.ratio) => {
            const number = bracketKey ? rawKey : Number(rawKey);
            const label = bracketKey ? `[${rawKey}]` : `[${number}]`;
            const normalizedKey = normalizedBibliographyKey(rawKey);
            if (!normalizedKey) return null;
            const existing = nextBibliography.find((entry) => normalizedBibliographyKey(entry.number) === normalizedKey);
            if (existing) return existing;
            const entryBody = bracketKey && currentBibliographyAuthorHeading
              ? `${currentBibliographyAuthorHeading} ${body}` : body;
            const meta = bibliographyMetadata(entryBody);
            const entry = { number, label, page: entryPage, ratio: entryRatio, title: entryBody.slice(0, 640), citations: [], ...meta };
            nextBibliography.push(entry);
            bibliographyLastPosition.set(entry, { page: entryPage, ratio: entryRatio });
            return entry;
          };

          const appendBibliographyContinuation = (entry, fragment) => {
            if (!entry) return;
            const addition = String(fragment || '').replace(/\s+/g, ' ').trim();
            if (!addition || /^\d{1,4}$/.test(addition)) return;
            const combined = `${entry.title || ''} ${addition}`.replace(/\s+/g, ' ').trim().slice(0, 640);
            entry.title = combined;
            bibliographyLastPosition.set(entry, { page, ratio: Number(line.ratio || 0) });
            const meta = bibliographyMetadata(combined);
            if (!entry.doi && meta.doi) entry.doi = meta.doi;
            if (!entry.arxiv && meta.arxiv) entry.arxiv = meta.arxiv;
          };

          // Old scanned bibliographies commonly lose or swap one bracket glyph.
          // Repair only a line-leading 1–3 digit key, only inside Bibliography,
          // and only for OCR-derived lines. Native PDF text remains authoritative.
          let bibliographyLine = line.ocrSource
            ? cleaned.replace(/^[\[{(]\s*(\d{1,3})\s*[\]})][.)]?\s*/, '[$1] ')
            : cleaned;
          if (bibliographyPostscriptContactLine(line, bibliographyLine, activeBibliographyEntry, nextBibliography.length, lines.slice(lineIndex + 1, lineIndex + 15))) {
            bibliographyMode = false;
            pendingBibliographyKey = null;
            pendingUnnumberedBibliographyEntry = null;
            activeBibliographyEntry = null;
            activeBibliographyRecoveryCandidate = null;
            continue;
          }
          bibliographyLine = bibliographyRepairAuthorKeyBrace(
            bibliographyLine, line, Boolean(currentBibliographyAuthorHeading));
          // Native text extraction in older scans can also confuse 1/l and the
          // closing bracket. Repair only the *next expected* numeric key, so a
          // malformed [l], [ll], [ 101 or [ 131 cannot invent a new sequence.
          const numericBibliographyNumbers = nextBibliography
            .map((entry) => Number(normalizedBibliographyKey(entry.number)))
            .filter((value) => Number.isInteger(value) && value >= 1 && value <= 999);
          const expectedBibliographyNumber = numericBibliographyNumbers.length ? Math.max(...numericBibliographyNumbers) + 1 : 1;
          if (expectedBibliographyNumber === 1) {
            bibliographyLine = line.ocrSource
              ? bibliographyLine.replace(/^[\[{(]\s*[lI]\s*[\]})][.)]?\s+/u, '[1] ')
              : bibliographyLine.replace(/^\[\s*[lI]\s*\]\s+/u, '[1] ');
          }
          if (expectedBibliographyNumber === 11) {
            bibliographyLine = line.ocrSource
              ? bibliographyLine.replace(/^[\[{(]\s*[1lI]{2}\s*[\]})][.)]?\s+/u, '[11] ')
              : bibliographyLine.replace(/^\[\s*[1lI]{2}\s*\]\s+/u, '[11] ');
          }
          // In some old mathematical text layers the printed digit 8 is
          // decoded as Greek delta. Accept that single glyph only when the
          // established numeric bibliography sequence is specifically waiting
          // for 8; never globally reinterpret delta as a digit.
          if (expectedBibliographyNumber === 8 && Number(line.xStartRatio || 0) < 0.22) {
            bibliographyLine = bibliographyLine.replace(/^\[\s*δ\s*\][.)]?$/u, '[8]');
          }
          bibliographyLine = bibliographyLine.replace(/^\[\s*(\d{1,3})1\s+(.+)$/u, (full, digits, body) => Number(digits) === expectedBibliographyNumber ? `[${digits}] ${body}` : full);
          bibliographyLine = repairOcrExpectedBibliographyKey(bibliographyLine, line, expectedBibliographyNumber);
          bibliographyLine = repairOcrExpectedBibliographyKeyOnly(bibliographyLine, line, expectedBibliographyNumber, numericBibliographyNumbers.length);
          // Preserve the established whitespace-delimited grammar verbatim:
          // historical scientific bibliographies may begin with punctuation,
          // digits or OCR-encoded symbols. Only *add* the strictly observed
          // no-space author-heading alternative, never replace old matching.
          let bib = bibliographyLine.match(/^\[\s*(\d{1,3})\s*\][.)]?\s+(.{3,})$/);
          if (!bib) bib = bibliographyLine.match(/^\[\s*(\d{1,3})\s*\][.)]?(?=[A-Za-zÀ-ÖØ-Þ])(.{3,})$/u);
          let bracketKey = false;
          if (!bib) {
            bib = bibliographyLine.match(/^\[\s*([A-Za-z][A-Za-z0-9\s]{0,12})\s*\][.)]?\s+(.{3,})$/);
            if (!bib) bib = bibliographyLine.match(/^\[\s*([A-Za-z][A-Za-z0-9\s]{0,12})\s*\][.)]?(?=[A-Za-zÀ-ÖØ-Þ])(.{3,})$/u);
            if (bib) bib[1] = bib[1].trim();
            bracketKey = Boolean(bib);
          }
          // Broken old text layers can omit the closing bracket while keeping
          // a short author key and the author name on the same visual line,
          // e.g. "[Gr GROSS L.". This shape is accepted only at the
          // bibliography's left edge and only with an uppercase author lead.
          if (!bib && Number(line.xStartRatio || 0) < 0.22) {
            const fragmentedAuthorWithBody = bibliographyLine.match(/^\[\s*([A-Za-z][A-Za-z0-9]{0,5})\s+([A-ZÀ-ÖØ-Þ][A-ZÀ-ÖØ-Þ .,'’\-]{2,})$/u);
            if (fragmentedAuthorWithBody) {
              bib = [fragmentedAuthorWithBody[0], fragmentedAuthorWithBody[1], fragmentedAuthorWithBody[2].trim()];
              bracketKey = true;
            }
          }
          if (!bib) bib = bibliographyLine.match(/^(\d{1,3})[.)]\s+([A-Z][^=]{8,})$/);
          // Once a numeric bibliography sequence is established, recover
          // old text layers whose author token is damaged or whose leading 5
          // was misread as 6 (for example visual 50 -> extracted 60). Recovery
          // is sequence-locked and left-margin-only, so numbered body prose
          // cannot start a reference merely because Bibliography mode is on.
          if (!bib && numericBibliographyNumbers.length >= 3 && Number(line.xStartRatio || 0) < 0.18) {
            const sequentialBare = bibliographyLine.match(/^(\d{1,3})-?\s+(.{8,})$/u);
            if (sequentialBare) {
              const rawNumber = Number(sequentialBare[1]);
              const tenDigitFiveToSixConfusion = expectedBibliographyNumber >= 50
                && expectedBibliographyNumber <= 59
                && rawNumber === expectedBibliographyNumber + 10;
              if (rawNumber === expectedBibliographyNumber
                  || (tenDigitFiveToSixConfusion && /^[A-ZÀ-ÖØ-Þ]/u.test(sequentialBare[2]))) {
                bib = [sequentialBare[0], String(expectedBibliographyNumber), sequentialBare[2]];
              }
            }
            if (!bib && expectedBibliographyNumber >= 10 && expectedBibliographyNumber <= 99) {
              const fuzzyLead = bibliographyLine.match(/^(\S{2,4})\s+([A-ZÀ-ÖØ-Þ].{7,})$/u);
              const expectedText = String(expectedBibliographyNumber);
              if (fuzzyLead) {
                const token = fuzzyLead[1];
                const tokenDigits = token.replace(/\D/g, '');
                const oneDigitCorruption = /\D/.test(token)
                  && token[0] === expectedText[0]
                  && tokenDigits === expectedText[0];
                if (oneDigitCorruption) bib = [fuzzyLead[0], expectedText, fuzzyLead[2]];
              }
            }
          }
          // Many older books print bare bibliography numbers in a left column
          // with no brackets or punctuation. Accept that shape only when the
          // body visibly begins like an author entry; this keeps ordinary page
          // numbers and numbered prose out of Bibliography.
          if (!bib) bib = bibliographyLine.match(/^(\d{1,3})-?\s+([A-ZÀ-ÖØ-Þ][\p{L}'’.-]{1,40},\s+.{6,})$/u);
          const malformedNumericCandidate = !bib ? malformedNumericBibliographyCandidate(bibliographyLine, line, page) : null;
          if (bib) {
            pendingBibliographyKey = null;
            pendingUnnumberedBibliographyEntry = null;
            activeBibliographyRecoveryCandidate = null;
            if (syntheticBibliographyMode === null) syntheticBibliographyMode = false;
            activeBibliographyEntry = addBibliographyEntry(bib[1], bib[2].trim(), bracketKey);
          } else {
            if (malformedNumericCandidate) {
              bibliographyRecoveryCandidates.push(malformedNumericCandidate);
              activeBibliographyRecoveryCandidate = malformedNumericCandidate;
              pendingBibliographyKey = null;
              activeBibliographyEntry = null;
              continue;
            }
            let keyOnly = bibliographyLine.match(/^\[\s*(\d{1,3}|[A-Za-z][A-Za-z0-9\s]{0,12})\s*\][.)]?$/);
            if (keyOnly) keyOnly[1] = keyOnly[1].trim();
            // A closing bracket may be extracted as its own tiny line. Treat a
            // short incomplete left-margin author key as pending; the isolated
            // "]" line is ignored and the following title attaches normally.
            if (!keyOnly && Number(line.xStartRatio || 0) < 0.22) {
              const fragmentedAuthorKey = bibliographyLine.match(/^\[\s*([A-Za-z][A-Za-z0-9\s]{0,8})\s*$/u);
              if (fragmentedAuthorKey) {
                const compactKey = fragmentedAuthorKey[1].replace(/\s+/g, '');
                if (compactKey && compactKey.length <= 8) keyOnly = [fragmentedAuthorKey[0], compactKey];
              }
            }
            // Old bibliographies often use a horizontal rule to mean
            // "same author as above". The rule may be a vector rather than
            // text, leaving PDF.js with a short fragment such as "[11] ,"
            // while the title starts on the next extracted line. Treat only
            // the next expected numeric key, at the bibliography's left edge,
            // as a pending key; do not broaden ordinary bracket matching.
            const dittoNumericKey = bibliographyLine.match(/^\[\s*(\d{1,3})\s*\]\s*(?:[-–—_]{1,16}\s*)?[,;:.]?\s*$/u);
            if (!keyOnly && dittoNumericKey
                && Number(dittoNumericKey[1]) === expectedBibliographyNumber
                && Number(line.xStartRatio || 0) < 0.22) keyOnly = dittoNumericKey;
            const bareNumericKey = bibliographyLine.match(/^(\d{1,3})-?$/);
            if (!keyOnly && bareNumericKey && Number(line.xStartRatio || 0) < 0.18) {
              const rawBareNumber = Number(bareNumericKey[1]);
              const keyOnlyFiveToSixConfusion = expectedBibliographyNumber >= 50
                && expectedBibliographyNumber <= 59
                && rawBareNumber === expectedBibliographyNumber + 10;
              if (rawBareNumber === expectedBibliographyNumber || keyOnlyFiveToSixConfusion) {
                keyOnly = [bareNumericKey[0], String(expectedBibliographyNumber)];
              }
            }
            if (!keyOnly && expectedBibliographyNumber >= 10 && expectedBibliographyNumber <= 99 && Number(line.xStartRatio || 0) < 0.18) {
              const fuzzyKeyOnly = bibliographyLine.match(/^(\S{2,4})$/u);
              if (fuzzyKeyOnly) {
                const expectedText = String(expectedBibliographyNumber);
                const token = fuzzyKeyOnly[1];
                const tokenDigits = token.replace(/\D/g, '');
                const oneDigitCorruption = /\D/.test(token)
                  && token[0] === expectedText[0]
                  && tokenDigits === expectedText[0];
                if (oneDigitCorruption) keyOnly = [fuzzyKeyOnly[0], expectedText];
              }
            }
            const surnameInitialAuthor = /^[A-ZÀ-ÖØ-Þ'’][\p{L}0-9"'’.\-\\{}:;]{1,48}(?:\s+(?:de|del|di|du|la|le|van|von))?,\s+(?:[A-Z0]\.?(?:\s*|$)){1,4}(?:,|\s|:).{6,}$/u.test(bibliographyLine);
            const surnameGivenAuthor = /^[A-ZÀ-ÖØ-Þ][\p{L}'’.-]{1,40},\s+[A-Z][\p{Ll}'’.-]{2,}(?:\s+(?:de|del|di|du|la|le|van|von))?(?:,|:).{6,}$/u.test(bibliographyLine);
            const initialFirstAuthor = /^(?:(?:[A-Z]\.\s*){1,4})[A-ZÀ-ÖØ-Þ][\p{L}'’.-]{1,40}(?:\s+(?:and|&)\s+(?:(?:[A-Z]\.\s*){1,4})?[A-ZÀ-ÖØ-Þ][\p{L}'’.-]{1,40})?\s*,\s+.{6,}$/u.test(bibliographyLine);
            const unnumberedBibCue = /(?:\b(?:17|18|19|20)\d{2}\b|\b(?:Journal|Communications?|Proceedings?|Springer|Press|Verlag|Inventiones|University\s+Press)\b|(?:\b(?:J|Math|Ann|Comm|Proc|Trans|Vol|No)\.))/i.test(bibliographyLine);
            const fullNameAuthorLead = fullNameBibliographyLead(bibliographyLine);
            const unnumberedAuthorLead = surnameInitialAuthor || initialFirstAuthor || (surnameGivenAuthor && unnumberedBibCue) || (fullNameAuthorLead && unnumberedBibliographyTextLooksStrong(bibliographyLine));
            const authorLineSpan = Math.max(0, Number(line.xEndRatio || 0) - Number(line.xStartRatio || 0));
            const strongUnnumberedAuthorLead = unnumberedAuthorLead && bibliographyLineStartsAtColumn(line) && (bibliographyLine.length >= 60 || authorLineSpan >= 0.45 || fullNameAuthorLead);
            const pendingFullNameLead = fullNameAuthorLead && bibliographyLineStartsAtColumn(line) && (syntheticBibliographyMode === true || syntheticBibliographyMode === null);
            const finalizePendingUnnumbered = () => {
              if (!pendingUnnumberedBibliographyEntry) return false;
              const full = pendingUnnumberedBibliographyEntry.fragments.join(' ').replace(/\s+/g, ' ').trim();
              if (!unnumberedBibliographyTextLooksStrong(full)) return false;
              if (syntheticBibliographyMode === null) syntheticBibliographyMode = true;
              activeBibliographyEntry = addBibliographyEntry(String(nextBibliography.length + 1), full, false, pendingUnnumberedBibliographyEntry.page, pendingUnnumberedBibliographyEntry.ratio);
              pendingUnnumberedBibliographyEntry = null;
              activeBibliographyRecoveryCandidate = null;
              pendingBibliographyKey = null;
              return Boolean(activeBibliographyEntry);
            };
            // A key-only line owns the next substantial line.  Old text layers
            // often emit `[B1]` and `BAKRY D.` as separate fragments on the
            // same visual baseline; do not let the author-name heuristics turn
            // that author into an unnumbered entry and discard the pending key.
            if (!keyOnly && pendingBibliographyKey && cleaned.length >= 3) {
              const pending = pendingBibliographyKey;
              pendingBibliographyKey = null;
              activeBibliographyRecoveryCandidate = null;
              let pendingBody = cleaned;
              if (/^\s*[,;:]/.test(pendingBody)) {
                const repeatedAuthor = repeatedBibliographyAuthorPrefix(nextBibliography);
                if (repeatedAuthor) pendingBody = `${repeatedAuthor}${pendingBody}`;
              }
              activeBibliographyEntry = addBibliographyEntry(pending.rawKey, pendingBody, pending.bracketKey, pending.page || page, pending.ratio ?? line.ratio);
              continue;
            }
            if (!keyOnly && pendingUnnumberedBibliographyEntry) {
              if (pendingFullNameLead && bibliographyLineStartsAtColumn(line)) {
                if (!finalizePendingUnnumbered()) pendingUnnumberedBibliographyEntry = null;
                pendingUnnumberedBibliographyEntry = { page, ratio: line.ratio, fragments: [bibliographyLine] };
                activeBibliographyEntry = null;
                if (unnumberedBibliographyTextLooksStrong(bibliographyLine)) finalizePendingUnnumbered();
                continue;
              }
              if (!bibliographyLineLooksLikeHeaderOrFooter(line, cleaned)) pendingUnnumberedBibliographyEntry.fragments.push(cleaned);
              if (finalizePendingUnnumbered()) continue;
              if (pendingUnnumberedBibliographyEntry.fragments.length >= 7) pendingUnnumberedBibliographyEntry = null;
              continue;
            }
            if (!keyOnly && pendingFullNameLead && !strongUnnumberedAuthorLead) {
              pendingUnnumberedBibliographyEntry = { page, ratio: line.ratio, fragments: [bibliographyLine] };
              activeBibliographyEntry = null;
              activeBibliographyRecoveryCandidate = null;
              pendingBibliographyKey = null;
              if (unnumberedBibliographyTextLooksStrong(bibliographyLine)) finalizePendingUnnumbered();
              continue;
            }
            if (keyOnly) {
              pendingUnnumberedBibliographyEntry = null;
              if (syntheticBibliographyMode === null) syntheticBibliographyMode = false;
              activeBibliographyRecoveryCandidate = null;
              pendingBibliographyKey = { rawKey: keyOnly[1], bracketKey: !/^\d+$/.test(keyOnly[1]), page, ratio: line.ratio };
              activeBibliographyEntry = null;
            } else if (activeBibliographyRecoveryCandidate && cleaned.length >= 3) {
              const footerLike = bibliographyLineLooksLikeHeaderOrFooter(line, cleaned);
              if (!footerLike) activeBibliographyRecoveryCandidate.continuations.push(cleaned);
            } else if ((syntheticBibliographyMode === true || syntheticBibliographyMode === null) && strongUnnumberedAuthorLead && (syntheticBibliographyMode === true || unnumberedBibCue)) {
              if (syntheticBibliographyMode === null) syntheticBibliographyMode = true;
              activeBibliographyRecoveryCandidate = null;
              pendingBibliographyKey = null;
              pendingUnnumberedBibliographyEntry = null;
              activeBibliographyEntry = addBibliographyEntry(String(nextBibliography.length + 1), bibliographyLine, false);
            } else if (activeBibliographyEntry && cleaned.length >= 3 && !/^(?:references?|bibliography|literature\s+cited)\b/i.test(cleaned)) {
              // Preserve wrapped old-style references. Continuation lines often
              // contain the journal, volume, year or page range that makes the
              // entry useful, but v295 discarded everything after line one.
              const footerLike = bibliographyLineLooksLikeHeaderOrFooter(line, cleaned);
              const lastPosition = bibliographyLastPosition.get(activeBibliographyEntry);
              const detachedSamePageBlock = Boolean(lastPosition
                && Number(lastPosition.page) === page
                && Number(line.ratio || 0) - Number(lastPosition.ratio || 0) > 0.18);
              if (!footerLike && !detachedSamePageBlock) appendBibliographyContinuation(activeBibliographyEntry, cleaned);
              else if (detachedSamePageBlock) activeBibliographyEntry = null;
            }
          }
        }
      }
      if (page % 10 === 0) await new Promise((resolve) => setTimeout(resolve, 0));
    }
    if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey || token !== structureIndexBuildToken) return;

    if (pendingUnnumberedBibliographyEntry) {
      const pendingText = pendingUnnumberedBibliographyEntry.fragments.join(' ').replace(/\s+/g, ' ').trim();
      if (unnumberedBibliographyTextLooksStrong(pendingText)) {
        if (syntheticBibliographyMode === null) syntheticBibliographyMode = true;
        const meta = bibliographyMetadata(pendingText);
        nextBibliography.push({ number: nextBibliography.length + 1, label: `[${nextBibliography.length + 1}]`, page: pendingUnnumberedBibliographyEntry.page, ratio: pendingUnnumberedBibliographyEntry.ratio, title: pendingText.slice(0, 640), citations: [], ...meta });
      }
      pendingUnnumberedBibliographyEntry = null;
    }

    // High-confidence exact parsing stays authoritative. A second pass may
    // promote a provisional malformed key only when two exact numeric neighbors
    // bound one unique missing number in document order. This recovers damaged
    // text-layer glyphs without broad OCR substitutions or duplicate entries.
    recoverSingleGapBibliographyCandidates(nextBibliography, bibliographyRecoveryCandidates);

    // Resolve body citation groups only after the bibliography keys are known.
    // The brackets group citations; they do not define the key syntax. This
    // supports author lists such as [Wg, W1] and unusual real bibliography keys
    // without broad bracket heuristics or false positives.
    const bibliographyByKey = new Map(nextBibliography.map((entry) => [normalizedBibliographyKey(entry.number), entry]));
    const knownBibliographyKeys = new Set(bibliographyByKey.keys());
    for (const citation of bibliographyCitationGroups) {
      for (const key of bibliographyCitationKeys(citation.raw, knownBibliographyKeys)) {
        const entry = bibliographyByKey.get(key);
        if (!entry) continue;
        entry.citations.push(citation);
        if (entry.citations.length > 500) entry.citations.length = 500;
      }
    }

    const cleanedBibliography = pruneIsolatedNumericEntriesFromAuthorKeyBibliography(nextBibliography);

    // Resolve only ambiguous OCR glyphs that have an actual observed result
    // declaration and uniquely supported immediately neighboring labels.
    // Never synthesize a missing declaration from numbering alone.
    recoverBoundedAppendixResultConfusables(nextEntries, ambiguousAppendixResultObservations);

    // Apply document-order sequence consistency after local detection. Exact
    // result labels are unique, and numeric result numbering must not move
    // backwards through the paper. This removes repeated prose-derived labels
    // without inventing missing mathematical results.
    const sequenceCleanEntries = normalizeSequentialStructureEntries(nextEntries);

    // Resolve proof dependencies into a directed graph and derive the reverse
    // relation from the same sequence-cleaned structure index.
    // The general reference grammar intentionally recognizes named results such
    // as "Theorem A". In ordinary proof prose that same grammar also matches
    // mathematical variables: "the example u", "the hypothesis X" and "by
    // assumption f". A bare letter has no reliable citation semantics unless
    // that exact labeled Result was actually detected in this document.
    // Keep unresolved NUMBERED references: they may point to a missed theorem
    // and are useful for conservative diagnosis rather than invented links.
    const structureOccurrences = new Map();
    for (const entry of sequenceCleanEntries) {
      const labelKey = normalizedStructureResultReference(entry.label);
      if (!structureOccurrences.has(labelKey)) structureOccurrences.set(labelKey, []);
      structureOccurrences.get(labelKey).push(entry);
    }
    // The Map below maintains the established proof-reference lexical filter;
    // physical link resolution is local to the proof owner when a name occurs
    // in several chapters. Ambiguous forward references remain unresolved.
    const structureByLabel = new Map([...structureOccurrences].map(([key, rows]) => [key, rows[0]]));
    const nearbyResult = (label, owner) => resolveStructureReferenceOccurrence(
      structureOccurrences.get(normalizedStructureResultReference(label)) || [], owner
    );
    for (const owner of sequenceCleanEntries) {
      owner.proofReferences = credibleStructureProofReferences(owner, structureByLabel);
      const resolved = [];
      for (const reference of owner.proofReferences || []) {
        const target = nearbyResult(reference, owner);
        if (!target || target === owner) continue;
        if (!resolved.some((item) => item.label === target.label && item.page === target.page && item.ratio === target.ratio)) resolved.push({ label: target.label, page: target.page, ratio: target.ratio });
        target.usedByProofs = target.usedByProofs || [];
        if (!target.usedByProofs.some((item) => item.label === owner.label && item.page === (owner.proofPage || owner.page) && item.ratio === (owner.proofRatio ?? owner.ratio))) target.usedByProofs.push({ label: owner.label, page: owner.proofPage || owner.page, ratio: owner.proofRatio ?? owner.ratio });
      }
      owner.proofUses = resolved.slice(0, 12);
    }

    // Corollary edges are intentionally conservative: only create them when
    // the corollary statement itself explicitly names an earlier structure.
    for (const entry of sequenceCleanEntries) {
      if (!/^corollary\b/i.test(entry.label || '')) continue;
      const refs = String(entry.title || '').match(STRUCTURE_REFERENCE_RE) || [];
      for (const ref of refs) {
        const parent = nearbyResult(ref, entry);
        if (!parent || parent === entry) continue;
        parent.corollaries = parent.corollaries || [];
        if (!parent.corollaries.some((item) => item.label === entry.label && item.page === entry.page && item.ratio === entry.ratio)) parent.corollaries.push({ label: entry.label, page: entry.page, ratio: entry.ratio });
        entry.derivedFrom = entry.derivedFrom || [];
        if (!entry.derivedFrom.some((item) => item.label === parent.label && item.page === parent.page && item.ratio === parent.ratio)) entry.derivedFrom.push({ label: parent.label, page: parent.page, ratio: parent.ratio });
      }
    }

    // Internal classifier strength is an implementation detail, not a
    // user-authored annotation or a new persisted reading-data contract.
    for (const entry of sequenceCleanEntries) {
      delete entry.declarationEvidence;
      delete entry.proofXStartRatio;
    }
    structureEntries = sequenceCleanEntries.slice(0, 500);
    bibliographyEntries = cleanedBibliography.slice(0, 400);
    structureIndexVersion = STRUCTURE_INDEX_VERSION;
    renderStructureIndex(); renderBibliographyIndex(); rerenderReferenceLinks();
    persistDocumentState();
  } catch (error) {
    console.warn('Mathematical structure index build failed', error);
    if (pdfDoc === sourceDoc && currentFileKey === sourceKey && token === structureIndexBuildToken) {
      structureEmpty.classList.remove('is-hidden');
      structureEmpty.textContent = t('The mathematical structure index could not be built. Use Rebuild index to try again.', '无法生成数学结构索引。可使用“重新生成索引”再次尝试。');
    }
  } finally {
    if (token === structureIndexBuildToken) {
      structureIndexBuilding = false;
      buildStructureIndexButton.disabled = !pdfDoc;
      if (typeof detectionRebuildIndexButton !== 'undefined' && detectionRebuildIndexButton) detectionRebuildIndexButton.disabled = !pdfDoc || !documentTextFeaturesAvailable();
    }
  }
}

function scheduleAutomaticStructureIndex() {
  if (!pdfDoc || !documentTextFeaturesAvailable() || structureIndexVersion === STRUCTURE_INDEX_VERSION || structureIndexBuilding) return;
  const sourceDoc = pdfDoc;
  const sourceKey = currentFileKey;
  const run = () => {
    if (pdfDoc !== sourceDoc || currentFileKey !== sourceKey || structureIndexVersion === STRUCTURE_INDEX_VERSION) return;
    buildStructureIndex();
  };
  if (typeof requestIdleCallback === 'function') requestIdleCallback(run, { timeout: 700 });
  else setTimeout(run, 120);
}

function structureResultRelationLabel(item) {
  return normalizedReferenceLabel(item?.label || '');
}

function restoreStructureResultRelations(entry) {
  const restoredLabel = structureResultRelationLabel(entry);
  if (!restoredLabel) return;
  const byLabel = new Map(structureEntries.map((item) => [structureResultRelationLabel(item), item]).filter(([label]) => label));
  const addRelation = (owner, field, related) => {
    if (!owner || !related?.label) return;
    owner[field] = Array.isArray(owner[field]) ? owner[field] : [];
    const key = structureResultRelationLabel(related);
    if (!owner[field].some((item) => structureResultRelationLabel(item) === key)) owner[field].push(related);
  };
  for (const targetRef of entry.proofUses || []) {
    const target = byLabel.get(structureResultRelationLabel(targetRef));
    if (target) addRelation(target, 'usedByProofs', { label: entry.label, page: entry.proofPage || entry.page, ratio: Number(entry.proofRatio) || Number(entry.ratio) || 0 });
  }
  for (const ownerRef of entry.usedByProofs || []) {
    const owner = byLabel.get(structureResultRelationLabel(ownerRef));
    if (owner) addRelation(owner, 'proofUses', { label: entry.label, page: entry.page, ratio: Number(entry.ratio) || 0 });
  }
  for (const childRef of entry.corollaries || []) {
    const child = byLabel.get(structureResultRelationLabel(childRef));
    if (child) addRelation(child, 'derivedFrom', { label: entry.label, page: entry.page, ratio: Number(entry.ratio) || 0 });
  }
  for (const parentRef of entry.derivedFrom || []) {
    const parent = byLabel.get(structureResultRelationLabel(parentRef));
    if (parent) addRelation(parent, 'corollaries', { label: entry.label, page: entry.page, ratio: Number(entry.ratio) || 0 });
  }
}

function renderStructureIndex() {
  if (!structureIndex || !structureEmpty || !structureCount) return;
  structureIndex.replaceChildren();
  structureCount.textContent = String(structureEntries.length);
  structureEmpty.classList.toggle('is-hidden', structureEntries.length > 0);
  if (!structureEntries.length) {
    structureEmpty.textContent = !pdfDoc
      ? t('Open a PDF to index results.', '打开 PDF 后可建立结果索引。')
      : structureIndexBuilding
        ? t('Indexing results…', '正在建立结果索引……')
        : t('No results indexed.', '尚无结果索引。');
    return;
  }
  const shownStructureEntries = detectionResultsFilter === 'numbered'
    ? structureEntries.filter((entry) => !entry.unnumberedResult && !/\s·\s*p\.\d+/i.test(entry.label || ''))
    : structureEntries;
  if (!shownStructureEntries.length) {
    structureEmpty.classList.remove('is-hidden');
    structureEmpty.textContent = t('No Results match this display filter.', '没有符合筛选条件的数学结果。');
  }
  for (const entry of shownStructureEntries) {
    const row = document.createElement('div'); row.className = 'structure-entry proof-graph-card'; row.dataset.page=String(entry.page);
    const button = document.createElement('button'); button.type = 'button'; button.className = 'structure-item proof-graph-root'; button.dataset.page=String(entry.page);
    const strong = document.createElement('strong'); strong.textContent = entry.displayLabel || entry.label || entry.title.replace(/([.:)].*)$/, '$1').slice(0, 80);
    const meta = document.createElement('span'); meta.textContent = t(`Page ${entry.page}`, `第 ${entry.page} 页`);
    button.append(strong, meta); button.title = entry.title;
    button.addEventListener('click', async () => {
      structureIndex.querySelectorAll('.structure-entry.has-edit-menu').forEach((node) => node.classList.remove('has-edit-menu'));
      setDocumentMapSelectedNode(button);
      const q = entry.label || entry.title;
      const target = { page: entry.page, ratio: Number(entry.ratio) || 0 };
      await goToMatchedLocation(target.page, target.ratio, q);
      updateBacklinksForTarget(q, target);
    });
    row.append(button);
    if (entry.proofPage) {
      const proof = document.createElement('button'); proof.type = 'button'; proof.className = 'structure-proof proof-graph-proof'; proof.dataset.page=String(entry.proofPage);
      proof.textContent = `${entry.proofTitle || t('Proof', '证明')} → ${t(`p. ${entry.proofPage}`, `第 ${entry.proofPage} 页`)}`;
      proof.title = entry.proofEndPage ? t(`Proof ends on page ${entry.proofEndPage}`, `证明结束于第 ${entry.proofEndPage} 页`) : '';
      proof.addEventListener('click', async () => { const q = entry.proofTitle || 'Proof'; const target = { page: entry.proofPage, ratio: Number(entry.proofRatio) || 0 }; await goToMatchedLocation(target.page, target.ratio, q); });
      row.append(proof);
    }
    const relations = [];
    if (Array.isArray(entry.proofUses) && entry.proofUses.length) relations.push({ prefix: t('Proof uses', '证明使用'), type:'uses', items: entry.proofUses });
    if (Array.isArray(entry.usedByProofs) && entry.usedByProofs.length) relations.push({ prefix: t('Used in proofs', '用于证明'), type:'used-in', items: entry.usedByProofs });
    if (Array.isArray(entry.corollaries) && entry.corollaries.length) relations.push({ prefix: t('Corollaries', '推论'), type:'corollary', items: entry.corollaries });
    if (Array.isArray(entry.derivedFrom) && entry.derivedFrom.length) relations.push({ prefix: t('Derived from', '源自'), type:'derived', items: entry.derivedFrom });
    if (showProofRelations && relations.length) {
      const graphWrap=document.createElement('div'); graphWrap.className='proof-graph-relations';
      for (const relation of relations) {
        const graph = document.createElement('div'); graph.className = `structure-relations relation-${relation.type}`;
        const prefix = document.createElement('span'); prefix.className = 'structure-relations-label'; prefix.textContent = `${relation.prefix}:`; graph.append(prefix);
        for (const related of relation.items.slice(0, 8)) {
          const chip = document.createElement('button'); chip.type = 'button'; chip.className = 'structure-relation-chip'; chip.textContent = related.label; chip.dataset.page=String(related.page);
          chip.addEventListener('click', async () => { await goToMatchedLocation(related.page, Number(related.ratio) || 0, related.label, { positionOnly: true }); updateBacklinksForTarget(related.label, { page: related.page, ratio: Number(related.ratio) || 0 }); });
          graph.append(chip);
        }
        graphWrap.append(graph);
      }
      row.append(graphWrap);
    }
    structureIndex.append(row);
  }
  applyDocumentMapFilter(el('map-filter-theorems')); updateDocumentMapCurrentLocation();
}

document.addEventListener('click', (event) => {
  if (event.target.closest?.('.result-edit-actions')) return;
  document.querySelectorAll('#structure-index .structure-entry.has-edit-menu').forEach((node) => node.classList.remove('has-edit-menu'));
});


// v356 — Confirmed cross-paper links. Never infer a PDF or theorem from a title.
function bibliographyLinkKey(entry) {
  const label = String(entry?.label || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
  const title = String(entry?.title || '').normalize('NFC').replace(/\s+/g, ' ').trim().toLowerCase();
  const page = Number(entry?.page);
  if (!label || !Number.isInteger(page) || page < 1) return '';
  // Page disambiguates same-label references. Missing OCR titles can still be
  // linked manually, without guessing which paper the reference names.
  return `${label.slice(0,90)}|p${page}|${title.slice(0,300)}`;
}

function normalizeConfirmedBibliographyLinks(raw) {
  if (raw?.version !== 1 || !Array.isArray(raw.links)) return new Map();
  const output = new Map();
  for (const item of raw.links.slice(0,400)) {
    if (!item || typeof item.key !== 'string' || typeof item.targetId !== 'string') continue;
    if (!item.key || item.key.length > 425 || !item.targetId || item.targetId.length > 256) continue;
    output.set(item.key, item.targetId);
  }
  return output;
}

function bibliographyLinkStorageKey(sourceId) {
  return `crossdoc-links:v1:${sourceId}`;
}

async function loadConfirmedBibliographyLinks(sourceId) {
  confirmedBibliographyLinks = new Map();
  if (!sourceId) return;
  try {
    const raw = await dbMetaGet(bibliographyLinkStorageKey(sourceId));
    if (currentFileKey === sourceId) confirmedBibliographyLinks = normalizeConfirmedBibliographyLinks(raw);
  } catch (error) {
    console.warn('MathReader could not load confirmed bibliography links.', error);
  }
}

function bibliographyLinkTarget(entry) {
  const id = confirmedBibliographyLinks.get(bibliographyLinkKey(entry));
  if (!id || id === currentFileKey) return null;
  return localLibrary.find((item) => item.id === id && item.localAvailable) || null;
}

async function updateConfirmedBibliographyLink(entry, targetId = null) {
  const key = bibliographyLinkKey(entry);
  const source = currentFileKey;
  if (!key || !source || !pdfDoc || confirmedBibliographyWriteInFlight || crossDocumentBusy) return false;
  // Claim the write lock before any async cache validation. In particular,
  // two clicks must not persist snapshots built from the same old link map.
  confirmedBibliographyWriteInFlight = true;
  try {
    const next = new Map(confirmedBibliographyLinks);
    if (targetId) {
      const record = localLibrary.find((item) => item.id === targetId && item.localAvailable && item.id !== source);
      if (!record || !(await dbGet('files', targetId))?.blob) {
        showError(t('The selected PDF is no longer cached locally.', '选中的 PDF 已不在本地缓存中。'));
        return false;
      }
      // The reader can switch PDFs while IndexedDB resolves. Do not write a
      // confirmed association in a document that is no longer active.
      if (currentFileKey !== source) return false;
      next.set(key, targetId);
    } else next.delete(key);
    if (currentFileKey !== source) return false;
    if (next.size > 400) { showError(t('Too many confirmed links for this document.', '当前文档已达到关联数量上限。')); return false; }
    try {
      await dbMetaSet(bibliographyLinkStorageKey(source), { version: 1, links: [...next].map(([k, id]) => ({ key: k, targetId: id })) });
      // Once IndexedDB commits a source-scoped link, it cannot truthfully be
      // reported as cancelled. If the user switched PDFs during the awaited
      // write, leave the active document's link map/UI untouched. Reopening
      // the original source reads its now-committed link record normally.
      if (currentFileKey !== source) return true;
      confirmedBibliographyLinks = next;
      renderBibliographyIndex();
      return true;
    } catch (error) {
      console.warn(error);
      showError(t('Could not save the local PDF link.', '无法保存本地 PDF 关联。'));
      return false;
    }
  } finally {
    confirmedBibliographyWriteInFlight = false;
  }
}

function updateCrossDocumentReturnButton() {
  if (!crossDocumentReturnButton) return;
  let item = crossDocumentReturnStack.at(-1);
  // An unrelated manual PDF open ends the transient return journey. Keeping
  // its old stack would resurrect a misleading Return button if that target
  // were opened again later. Switches performed by P1 itself hold the lock.
  if (!crossDocumentBusy && item && item.targetId !== currentFileKey) {
    crossDocumentReturnStack = [];
    item = null;
  }
  const valid = Boolean(pdfDoc && item && item.targetId === currentFileKey);
  crossDocumentReturnButton.classList.toggle('is-hidden', !valid);
  crossDocumentReturnButton.disabled = !valid || crossDocumentBusy;
  if (valid) {
    crossDocumentReturnButton.title = t(`Return to ${item.sourceName}`, `返回 ${item.sourceName}`);
    crossDocumentReturnButton.setAttribute('aria-label', crossDocumentReturnButton.title);
  }
}

async function openConfirmedBibliographyTarget(entry) {
  if (crossDocumentBusy || !pdfDoc || !currentFileKey) return false;
  const target = bibliographyLinkTarget(entry);
  if (!target) {
    showError(t('Linked PDF is not available in the local library. Relink it.', '关联的 PDF 不在本地文库中，请重新关联。'));
    return false;
  }
  const sourceId = currentFileKey;
  const sourceName = currentFileName || t('Source paper', '原文');
  const captured = snapshotDisplayAnchor();
  const anchor = captured || { page: currentPage, ratio: Math.max(0, Math.min(1, primaryCanvasWrap.scrollTop / Math.max(1, primaryPageSurface?.offsetHeight || 1))) };
  // Claim the lock *before* the first await. Two rapid clicks must never
  // both get through asynchronous IndexedDB availability checks.
  crossDocumentBusy = true;
  updateCrossDocumentReturnButton();
  try {
    // A return path is only guaranteed when the source is cached locally.
    if (!cacheEnabledForCurrent || !(await dbGet('files', sourceId))?.blob) {
      showError(t('Cache this source PDF before opening a linked paper.', '请先将原文存入本地缓存，再打开关联论文。'));
      return false;
    }
    await flushCurrentDocumentSession();
    const opened = await openCachedDocument(target.id);
    if (!opened || currentFileKey !== target.id) {
      // If the linked PDF fails, try to restore the previously open source.
      if (currentFileKey !== sourceId) await openCachedDocument(sourceId);
      return false;
    }
    crossDocumentReturnStack.push({ sourceId, sourceName, targetId: target.id,
      page: Math.max(1, Number(anchor.page) || 1), ratio: Math.max(0, Math.min(1, Number(anchor.ratio) || 0)) });
    if (crossDocumentReturnStack.length > 16) crossDocumentReturnStack.shift();
    showNotice(t('Linked PDF opened. Use Return to paper to go back.', '已打开关联 PDF，可点击“返回原文”。'));
    return true;
  } catch (error) {
    console.warn('Cross-document navigation failed', error);
    if (currentFileKey !== sourceId) await openCachedDocument(sourceId);
    showError(t('Could not open linked PDF.', '无法打开关联的 PDF。'));
    return false;
  } finally {
    crossDocumentBusy = false;
    updateCrossDocumentReturnButton();
  }
}

async function returnToCrossDocumentSource() {
  if (crossDocumentBusy || !pdfDoc) return false;
  const item = crossDocumentReturnStack.at(-1);
  if (!item || item.targetId !== currentFileKey) return false;
  crossDocumentBusy = true;
  try {
    await flushCurrentDocumentSession();
    const opened = await openCachedDocument(item.sourceId);
    if (!opened || currentFileKey !== item.sourceId) {
      if (currentFileKey !== item.targetId) await openCachedDocument(item.targetId);
      return false;
    }
    const returnDocument = pdfDoc;
    const expectedNavigation = readerNavigationSerial + 1;
    await goToLocation(item.page, item.ratio, { contextLead: false, recordHistory: false });
    if (!pdfDoc || pdfDoc !== returnDocument || currentFileKey !== item.sourceId
        || readerNavigationSerial !== expectedNavigation) return false;
    // Only consume this return path after both the source PDF and its exact
    // anchor have been restored. A failed page navigation must stay retryable.
    crossDocumentReturnStack.pop();
    showNavigationLandingCue(item.page, item.ratio);
    return true;
  } catch (error) {
    console.warn('Return to source paper failed', error);
    if (currentFileKey !== item.targetId) await openCachedDocument(item.targetId);
    showError(t('Could not restore the source paper.', '无法返回原文。'));
    return false;
  } finally {
    crossDocumentBusy = false;
    updateCrossDocumentReturnButton();
  }
}

// v361: keep bibliography rows compact. All local-PDF actions live in a
// transient right-click menu instead of permanently occupying the index.
// A single body-level menu avoids clipping by the scrollable bibliography pane.
let bibliographyContextMenuState = null;
function closeBibliographyContextMenu(restoreFocus = false) {
  const state = bibliographyContextMenuState;
  if (!state) return;
  bibliographyContextMenuState = null;
  state.listeners.abort();
  state.menu.remove();
  if (restoreFocus && state.trigger?.isConnected) state.trigger.focus();
}

function showBibliographyLinkPicker(entry, row) {
  const old = row.querySelector('.bibliography-link-picker');
  if (old) { old.remove(); return; }
  const available = localLibrary.filter((r) => r.localAvailable && r.id !== currentFileKey);
  if (!available.length) {
    showNotice(t('Open and cache another PDF before linking it.', '请先打开并缓存另一份 PDF。'));
    return;
  }
  const picker = document.createElement('div'); picker.className = 'bibliography-link-picker';
  const select = document.createElement('select');
  select.setAttribute('aria-label', t('Choose linked local PDF', '选择关联的本地 PDF'));
  const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = t('Select a local PDF…', '选择本地 PDF…');
  select.append(placeholder);
  for (const candidate of available) {
    const option = document.createElement('option'); option.value = candidate.id; option.textContent = candidate.name || candidate.id;
    select.append(option);
  }
  const confirm = document.createElement('button'); confirm.type = 'button'; confirm.className = 'bibliography-local-button';
  confirm.textContent = t('Link', '关联'); confirm.disabled = true;
  select.addEventListener('change', () => { confirm.disabled = !select.value; });
  confirm.addEventListener('click', async () => {
    confirm.disabled = true;
    if (!(await updateConfirmedBibliographyLink(entry, select.value))) confirm.disabled = !select.value;
  });
  const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'bibliography-local-button'; cancel.textContent = t('Cancel', '取消');
  cancel.addEventListener('click', () => picker.remove());
  picker.append(select, confirm, cancel); row.append(picker); select.focus();
}

function openBibliographyContextMenu(entry, row, clientX, clientY, trigger) {
  closeBibliographyContextMenu();
  if (!bibliographyLinkKey(entry) || !pdfDoc || !currentFileKey) return;
  const linkedId = confirmedBibliographyLinks.get(bibliographyLinkKey(entry));
  const linked = bibliographyLinkTarget(entry);
  const menu = document.createElement('div');
  menu.className = 'bibliography-context-menu'; menu.setAttribute('role', 'menu');
  menu.setAttribute('aria-label', t(`Local PDF · ${entry.label}`, `本地 PDF · ${entry.label}`));
  const add = (label, title, handler) => {
    const button = document.createElement('button');
    button.type = 'button'; button.setAttribute('role', 'menuitem');
    button.className = 'bibliography-context-action';
    button.textContent = label; button.title = title;
    button.addEventListener('click', () => { closeBibliographyContextMenu(); handler(); });
    menu.append(button);
  };
  if (linked) {
    add(t('Open PDF', '打开 PDF'), linked.name || linked.id, () => void openConfirmedBibliographyTarget(entry));
  }
  add(linkedId ? t('Relink PDF', '重新关联') : t('Link PDF', '关联 PDF'),
      t('Choose an exact PDF from your local library', '从本地文库中选择准确的 PDF'),
      () => showBibliographyLinkPicker(entry, row));
  if (linkedId) {
    add(t('Unlink', '解除关联'), t('Remove this confirmed link', '解除当前已确认关联'),
      () => void updateConfirmedBibliographyLink(entry));
  }
  document.body.append(menu);
  const bounds = menu.getBoundingClientRect();
  const x = Number.isFinite(clientX) ? clientX : 0;
  const y = Number.isFinite(clientY) ? clientY : 0;
  menu.style.left = `${Math.max(6, Math.min(x, window.innerWidth - bounds.width - 6))}px`;
  menu.style.top = `${Math.max(6, Math.min(y, window.innerHeight - bounds.height - 6))}px`;
  const listeners = new AbortController();
  bibliographyContextMenuState = {menu, listeners, trigger};
  document.addEventListener('pointerdown', (event) => {
    if (!menu.contains(event.target)) closeBibliographyContextMenu();
  }, {capture:true, signal:listeners.signal});
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { event.preventDefault(); closeBibliographyContextMenu(true); }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const items = [...menu.querySelectorAll('[role="menuitem"]')];
      const index = items.indexOf(document.activeElement);
      items[(index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length]?.focus();
    }
  }, {signal:listeners.signal});
  document.addEventListener('scroll', () => closeBibliographyContextMenu(), {capture:true, signal:listeners.signal});
  window.addEventListener('resize', () => closeBibliographyContextMenu(), {signal:listeners.signal});
  menu.querySelector('button')?.focus();
}

function renderBibliographyLocalLink(entry, row, main) {
  if (!bibliographyLinkKey(entry)) return;
  const sourceId = currentFileKey;
  // Right-clicking the reference does not expand citations or navigate.
  row.addEventListener('contextmenu', (event) => {
    if (event.target.closest?.('a,select,.bibliography-link-picker')) return;
    event.preventDefault();
    openBibliographyContextMenu(entry, row, event.clientX, event.clientY, main);
  });
  main.setAttribute('aria-haspopup', 'menu');
  main.setAttribute('aria-keyshortcuts', 'Shift+F10');
  main.addEventListener('keydown', (event) => {
    if (event.key === 'ContextMenu' || (event.shiftKey && event.key === 'F10')) {
      event.preventDefault();
      const bounds = main.getBoundingClientRect();
      openBibliographyContextMenu(entry, row, bounds.left + 12, bounds.top + Math.min(bounds.height, 20), main);
    }
  });
  // Touch browsers do not reliably synthesize contextmenu. A stationary long
  // press provides the same actions without adding a permanent button.
  let pressTimer = null, suppressNextClick = false, startX = 0, startY = 0;
  const cancelPress = () => { if (pressTimer !== null) clearTimeout(pressTimer); pressTimer = null; };
  main.addEventListener('pointerdown', (event) => {
    if (event.pointerType !== 'touch' || event.button !== 0) return;
    cancelPress(); startX = event.clientX; startY = event.clientY;
    pressTimer = setTimeout(() => {
      pressTimer = null;
      if (!row.isConnected || currentFileKey !== sourceId) return;
      suppressNextClick = true;
      openBibliographyContextMenu(entry, row, startX, startY, main);
    }, 550);
  });
  main.addEventListener('pointermove', (event) => {
    if (pressTimer !== null && (Math.abs(event.clientX - startX) > 10 || Math.abs(event.clientY - startY) > 10)) cancelPress();
  });
  for (const type of ['pointerup', 'pointercancel', 'pointerleave']) main.addEventListener(type, () => {
    cancelPress();
    // An OS may emit no click after long-press; do not swallow the next tap.
    if (suppressNextClick) setTimeout(() => { suppressNextClick = false; }, 0);
  });
  main.addEventListener('click', (event) => {
    if (!suppressNextClick) return;
    suppressNextClick = false;
    event.preventDefault(); event.stopImmediatePropagation();
  }, {capture:true});
}

function renderBibliographyIndex() {
  closeBibliographyContextMenu();
  if (!bibliographyIndex || !bibliographyEmpty || !bibliographyCount) return;
  bibliographyIndex.replaceChildren(); bibliographyCount.textContent = String(bibliographyEntries.length);
  bibliographyEmpty.classList.toggle('is-hidden', bibliographyEntries.length > 0);
  if (!bibliographyEntries.length) {
    bibliographyEmpty.textContent = !pdfDoc
      ? t('Open a PDF to index references.', '打开 PDF 后可建立参考文献索引。')
      : structureIndexBuilding
        ? t('Indexing references…', '正在建立参考文献索引……')
        : t('No references indexed.', '尚无参考文献索引。');
    return;
  }
  for (const entry of bibliographyEntries) {
    const row = document.createElement('div'); row.className = 'bibliography-item bibliography-smart-item'; row.dataset.page=String(entry.page);
    const main = document.createElement('button'); main.type='button'; main.className='bibliography-jump bibliography-expand'; main.setAttribute('aria-expanded', bibliographyExpanded.has(entry.number)?'true':'false'); main.title=t('Click to show citations · Double-click to go','单击查看引用 · 双击跳转');
    const label = document.createElement('strong'); label.textContent = entry.label;
    const copy=document.createElement('span'); copy.className='bibliography-copy';
    const text = document.createElement('span'); text.className='bibliography-title'; text.textContent = entry.title;
    const stats=document.createElement('span'); stats.className='bibliography-stats'; stats.textContent=bibliographyCitationSummary(entry);
    copy.append(text,stats); main.append(label,copy);
    // Citation expansion is immediate. Update only this row instead of
    // re-rendering the whole bibliography so the same DOM node survives long
    // enough for the browser's native dblclick event. If a double-click follows,
    // restore the pre-click expansion state before navigating.
    let bibliographyFirstClickWasExpanded = null;
    const renderBibliographyCitations = () => {
      row.querySelector('.bibliography-citations')?.remove();
      const expanded = bibliographyExpanded.has(entry.number);
      main.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      if (!expanded) return;
      const cites=document.createElement('div'); cites.className='bibliography-citations';
      const citations=Array.isArray(entry.citations)?entry.citations:[];
      if (!citations.length) { const empty=document.createElement('div'); empty.className='bibliography-citations-empty'; empty.textContent=t('No in-text citations detected.','未检测到正文引用。'); cites.append(empty); }
      for (const [index,citation] of citations.entries()) {
        const button=document.createElement('button'); button.type='button'; button.className='bibliography-citation-item'; button.dataset.page=String(citation.page);
        const meta=document.createElement('strong'); meta.textContent=index===0?t(`First citation · p. ${citation.page}`,`首次引用 · 第 ${citation.page} 页`):t(`Citation ${index+1} · p. ${citation.page}`,`第 ${index+1} 处引用 · 第 ${citation.page} 页`);
        const snippet=document.createElement('span'); snippet.textContent=citation.snippet||citation.raw||''; button.append(meta,snippet);
        button.addEventListener('click',()=>goToMatchedLocation(citation.page,Number(citation.ratio)||0,citation.raw||entry.label)); cites.append(button);
      }
      row.append(cites);
    };
    main.addEventListener('click',(event)=>{
      if (event.detail > 1) return;
      bibliographyFirstClickWasExpanded = bibliographyExpanded.has(entry.number);
      if (bibliographyFirstClickWasExpanded) bibliographyExpanded.delete(entry.number); else bibliographyExpanded.add(entry.number);
      renderBibliographyCitations();
    });
    main.addEventListener('dblclick',async(event)=>{
      event.preventDefault();
      if (bibliographyFirstClickWasExpanded !== null) {
        if (bibliographyFirstClickWasExpanded) bibliographyExpanded.add(entry.number); else bibliographyExpanded.delete(entry.number);
        renderBibliographyCitations();
        bibliographyFirstClickWasExpanded = null;
      }
      const target={page:entry.page,ratio:Number(entry.ratio)||0};
      await goToMatchedLocation(target.page,target.ratio,entry.label);
      updateBacklinksForTarget(entry.label,target);
    });
    const actions=document.createElement('div'); actions.className='bibliography-actions';
    if (entry.doi || entry.arxiv) {
      const external = document.createElement('a'); external.className = 'bibliography-external'; external.target = '_blank'; external.rel = 'noopener noreferrer';
      if (entry.doi) { external.href = `https://doi.org/${entry.doi}`; external.textContent = 'DOI ↗'; }
      else { external.href = `https://arxiv.org/abs/${entry.arxiv}`; external.textContent = 'arXiv ↗'; }
      actions.append(external);
    }
    row.append(main);
    renderBibliographyLocalLink(entry, row, main);
    if (actions.childElementCount) row.append(actions);
    renderBibliographyCitations();
    bibliographyIndex.append(row);
  }
  applyDocumentMapFilter(el('map-filter-bibliography')); updateDocumentMapCurrentLocation();
}

