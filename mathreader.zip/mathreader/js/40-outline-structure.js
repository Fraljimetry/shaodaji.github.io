// MathReader v306 · Outline inference, legacy heading recovery, and Structure rendering.
function flattenOutline(items, depth = 0, output = []) {
  for (const item of items || []) {
    output.push({ item, depth: Math.min(depth, 3) });
    if (item.items?.length) flattenOutline(item.items, depth + 1, output);
  }
  return output;
}

// PDF bookmark metadata can contain malformed trailing encoding bytes (e.g.,
// an overlong NUL sequence) that PDF.js exposes as a control/replacement glyph.
// Clean ONLY invalid trailing code points. Never remove a meaningful square,
// math symbol, or an uncertain replacement character within the title.
function cleanEmbeddedOutlineTitle(value) {
  return String(value ?? '')
    .replace(/[\u0000-\u001F\u007F-\u009F\uFFFD\uD800-\uDFFF]+$/u, '')
    .trim();
}

function updateOutlineSource() {
  if (!outlineSource) return;
  outlineSource.classList.toggle('is-hidden', outlineMode === 'none');
  if (outlineMode === 'embedded') {
    outlineSource.textContent = inferredOutline.some((entry) => entry?.userEdited === true)
      ? t('Embedded PDF outline · manual additions', 'PDF 嵌入式目录 · 手动添加')
      : t('Embedded PDF outline', 'PDF 嵌入式目录');
  } else if (outlineMode === 'inferred') {
    outlineSource.textContent = t('Detected outline · inferred from page typography and numbering', '自动检测目录 · 根据页面字号与编号推断');
  } else {
    outlineSource.textContent = '';
  }
}

function normalizedHeadingText(value) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    // Some legacy journals extract the section delimiter after §N as a
    // middle dot (for example, "§3· Title") rather than an ASCII period.
    // Normalize only this explicit section-marker form; ordinary math dots
    // and multiplication symbols remain untouched.
    .replace(/^(\s*§\s*\d+(?:\s*\.\s*\d+)*)\s*·\s*/, '$1. ')
    .replace(/\s+([,.;:!?])/g, '$1')
    .trim();
}

function weightedMedianFont(samples) {
  const values = samples
    .filter((sample) => Number.isFinite(sample.size) && sample.size > 3 && sample.size < 80 && sample.weight > 0)
    .sort((a, b) => a.size - b.size);
  if (!values.length) return 10;
  const total = values.reduce((sum, sample) => sum + sample.weight, 0);
  let acc = 0;
  for (const sample of values) {
    acc += sample.weight;
    if (acc >= total / 2) return sample.size;
  }
  return values[values.length - 1].size;
}

function headingNumberDepth(text) {
  const match = text.match(/^\s*(?:§\s*)?((?:\d+(?:\.\d+){0,4}|[A-H](?:\.\d+){1,4}|[A-H][.)]))(?:[.)])?\s+\S/);
  if (!match) return null;
  return Math.min(3, match[1].replace(/[.)]$/, '').split('.').length - 1);
}

function isKnownHeading(text) {
  return /^(?:abstract|introduction|background|preliminaries|notation|setup|main results?|results?|discussion|conclusions?|references|bibliography|acknowledg(?:e)?ments?|purpose|foreword|afterword|preface|appendix(?:\s+[A-Z0-9]+)?\.?|contents)$/i.test(text.trim());
}

function isMathEnvironmentLabel(text) {
  return /^(?:theorem|lemma|proposition|corollary|definition|remark|example|claim|proof)\b/i.test(text.trim());
}

// In classical textbooks, "1.9 Theorem: ..." is a numbered result, not
// Section 1.9. Results owns these declarations even when the text layer gives
// them large typography. Only reject declaration punctuation/numbering: a
// genuine section title such as "2.1 Theorem of Stokes" remains eligible.
function numberedResultDeclarationInOutline(text) {
  const value = normalizedHeadingText(text);
  return /^(?:§\s*)?(?:(?:\d{1,3}|[A-Z]{1,2})(?:\s*[.·\-]\s*[0-9lIO]{1,3}){0,4})[.)]?\s+(?:theorem|lemma|proposition|corollary|definition|remark|example|claim|conjecture|question|assumption|hypothesis)\b(?=\s*[:.(]|\s+\d|\s*$)/i.test(value);
}

// Long sentence fragments in legacy books sometimes appear larger than the
// page's median font. Require multiple prose cues before rejecting an
// unnumbered style heading; short legitimate literary titles are unaffected.
// OCR can read a large formula fragment as a numbered heading (for
// example "2 C (g_ij + ...)"). A one-letter lead followed by a mathematical
// parenthesis and an operator is not a section title.
function numberedFormulaFragmentInOutline(text) {
  const value = normalizedHeadingText(text);
  return /^\d{1,3}\s+[A-Za-z]\s*[([{][^)]{0,90}[+*/=@]/.test(value);
}

function obviousProseFragmentInOutline(text) {
  const value = normalizedHeadingText(text);
  if (!value || isKnownHeading(value) || headingNumberDepth(value) !== null) return false;
  const words = value.split(/\s+/).filter(Boolean);
  if (words.length < 7) return false;
  const sentenceStarter = /^(?:roughly speaking\b|in addition\b|if\b|since\b|obviously\b|now\b|we\b|let\b|given\b|from\b|provided\b|and\b|then\b|thus\b|hence\b|because\b|therefore\b|consequently\b|by\b|for every\b)/i.test(value);
  const sentenceVerb = /\b(?:is|are|was|were|has|have|had|can|could|will|would|must|may|follows?|gives?|gave|defines?|satisfies?|suppose|supposing|letting|minimizes?|shows?|obtain|we have)\b/i.test(value);
  return (sentenceStarter && (sentenceVerb || /[,;:]|\bthen\b/i.test(value)))
    || (words.length >= 10 && sentenceVerb && /[,;:.]\s|[,;:.]$/.test(value));
}


function isLikelyFormulaHeading(text) {
  const value = String(text || '').trim();
  if (!value || isKnownHeading(value)) return false;
  // Strong equation/operator signals are far more likely to be display math
  // than document structure.
  if (/[=≤≥≠≈∫∑∏√∂∇⋃⋂∞±×·^_]|(?:\b(?:lim|sup|inf)\b.*[→∞])/u.test(value)) return true;
  const remainder = value
    .replace(/^\s*(?:§\s*)?\d+(?:\.\d+){0,4}[.)]?\s*/, '')
    .replace(/^\s*[A-Z][.)]\s*/, '')
    .trim();
  const asciiWords = remainder.match(/[A-Za-z]{3,}/g) || [];
  const hanChars = remainder.match(/\p{Script=Han}/gu) || [];
  const tokens = remainder.split(/\s+/).filter(Boolean);
  const shortVariableTokens = tokens.filter((token) => /^[\p{L}\p{N}πρσφθμνξωαβγδκηλ]+$/u.test(token) && [...token].length <= 2).length;
  const symbolCount = (remainder.match(/[+\-*\/(){}[\],:;|]/g) || []).length;
  const digitCount = (remainder.match(/\d/g) || []).length;
  const letterCount = (remainder.match(/\p{L}/gu) || []).length;
  if (headingNumberDepth(value) !== null && asciiWords.length === 0 && hanChars.length < 2) return true;
  if (tokens.length >= 1 && shortVariableTokens / tokens.length >= 0.6 && asciiWords.length < 2 && hanChars.length < 2) return true;
  if (symbolCount >= 2 && asciiWords.length < 2 && hanChars.length < 2) return true;
  if (digitCount > 0 && digitCount >= Math.max(2, letterCount) && asciiWords.length < 2) return true;
  return false;
}
function headingDepthFromStyle(line, bodySize) {
  const numbered = headingNumberDepth(line.text);
  if (numbered !== null) return numbered;
  if (/^appendix\b/i.test(line.text)) return 0;
  const ratio = line.size / Math.max(1, bodySize);
  if (ratio >= 1.55) return 0;
  if (ratio >= 1.30) return 1;
  return 2;
}

function isMarginEquationLabelLineForStructure(line) {
  const text = String(line?.text || '').trim().normalize('NFKC');
  // Equation numbers in older journals are often bare left-margin tokens such
  // as "1.2", "1 . 14" or "3 . 4", rather than parenthesized right tags.
  // Treat only an essentially standalone numeric token as an equation label;
  // real section headings have title text after the number.
  const numericOnly = /^(?:\(\s*)?\d+\s*(?:\.\s*\d+\s*)+(?:\))?$/.test(text)
    || /^\(\s*\d+\s*\)$/.test(text);
  if (!numericOnly) return false;
  const start = Number(line?.xStartRatio);
  const end = Number(line?.xEndRatio);
  const nearLeft = (Number.isFinite(start) && start <= 0.24) || (Number.isFinite(end) && end <= 0.38);
  const nearRight = (Number.isFinite(start) && start >= 0.60) || (Number.isFinite(end) && end >= 0.74);
  return nearLeft || nearRight;
}

function ocrLineSuitableForStructure(line) {
  const text = String(line?.text || '').trim();
  if (!text) return false;
  const confidence = Number(line?.confidence);
  if (Number.isFinite(confidence) && confidence < 58) return false;
  // OCR of displayed mathematics often produces short pseudo-words mixed with
  // operators/digits. Such lines are useful for Equation indexing but are poor
  // Structure candidates.
  const tokens = text.split(/\s+/).filter(Boolean);
  const alphaWords = tokens.filter((token) => /^[A-Za-z][A-Za-z'’.-]{2,}$/.test(token));
  const operatorCount = (text.match(/[=+<>∑∫√∞→←≤≥\\{}_^|]/g) || []).length;
  const digitCount = (text.match(/\d/g) || []).length;
  const letterCount = (text.match(/[A-Za-z]/g) || []).length;
  const hyphenTitleWords = text.match(/[A-Za-z]{2,}/g) || [];
  const hyphenSectionTitle = /^\d{1,2}-\d{1,2}[.)]?\s+[A-Z]/.test(text) && hyphenTitleWords.length >= 2;
  if (operatorCount >= 2 && alphaWords.length < 3 && !hyphenSectionTitle) return false;
  if (tokens.length >= 3 && alphaWords.length === 0 && digitCount >= Math.max(2, letterCount / 2)) return false;
  if (/^\(?\d+(?:\.\d+)+\)?\s+/.test(text) && alphaWords.length < 2) return false;
  return true;
}

// A malformed or densely fragmented PDF text layer can put hundreds of thousands
// of text items on one baseline. Avoid argument-spread limits while preserving
// the established non-finite/negative-width fallback semantics.
function outlineHorizontalLineBounds(items) {
  let xMin = Infinity;
  let xMax = -Infinity;
  for (const item of items) {
    const rawX = Number(item.x);
    const rawWidth = Number(item.width);
    const x = Number.isFinite(rawX) ? rawX : 0;
    const width = Number.isFinite(rawWidth) ? Math.max(0, rawWidth) : 0;
    const right = x + width;
    if (x < xMin) xMin = x;
    if (right > xMax) xMax = right;
  }
  return { xMin, xMax };
}

async function detectOutlineFromTypography() {
  const pages = [];
  const fontSamples = [];
  const repeatMap = new Map();
  let nativeTextChars = 0;
  let nativeControlChars = 0;
  const maxPages = Math.min(pdfDoc.numPages, 600);

  const outlinePages = Array.from({ length: maxPages }, (_, index) => index + 1);
  for await (const { item: pageNum, value: pageData } of orderedPrefetch(
    outlinePages,
    async (candidatePageNum) => {
      const ocrSource = sourceDocumentUsesOcr(candidatePageNum);
      if (ocrSource) {
        const page = await pdfDoc.getPage(candidatePageNum);
        return { viewport: page.getViewport({ scale: 1 }), ocrSource, content: null };
      }
      const { page, content } = await nativePageTextData(pdfDoc, candidatePageNum);
      return { viewport: page.getViewport({ scale: 1 }), ocrSource, content };
    },
    3
  )) {
    const { viewport, ocrSource, content } = pageData;
    let lines = [];
    if (ocrSource) {
      const record = documentOcrPages.get(pageNum);
      lines = (record?.lines || []).map((ocrLine) => {
        const text = normalizedHeadingText(ocrLine.text);
        const size = Math.max(1, (Number(ocrLine.heightRatio) || 0.018) * viewport.height);
        const y = viewport.height * (1 - (Number(ocrLine.ratio) || 0));
        const xStartRatio = Number(ocrLine.xStartRatio) || 0;
        const xEndRatio = Number(ocrLine.xEndRatio) || xStartRatio;
        const x = xStartRatio * viewport.width;
        fontSamples.push({ size, weight: Math.max(1, text.replace(/\s/g, '').length) });
        return { page: pageNum, y, x, items: [], size, pageHeight: viewport.height, text, confidence: ocrLine.confidence, xStartRatio, xEndRatio };
      }).filter((line) => line.text && ocrLineSuitableForStructure(line));
    } else {
      const items = [];
      for (const item of content.items || []) {
        const rawText = String(item.str || '');
        nativeTextChars += rawText.length;
        nativeControlChars += (rawText.match(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g) || []).length;
        const text = normalizedHeadingText(rawText);
        if (!text) continue;
        const tr = item.transform || [1, 0, 0, 1, 0, 0];
        const size = Math.max(1, Math.hypot(Number(tr[0]) || 0, Number(tr[1]) || 0) || Number(item.height) || 1);
        const x = Number(tr[4]) || 0;
        const y = Number(tr[5]) || 0;
        items.push({ text, size, x, y, width: Number(item.width) || 0, fontName: item.fontName || '' });
        fontSamples.push({ size, weight: Math.max(1, text.replace(/\s/g, '').length) });
      }
      items.sort((a, b) => Math.abs(b.y - a.y) > 1.5 ? b.y - a.y : a.x - b.x);
      const lineBuckets = new Map();
      for (const item of items) {
        const tolerance = Math.max(1.8, item.size * 0.22);
        // Preserve the original first-created-line match, but avoid scanning
        // every prior line for each text item on dense pages.
        let line = findFirstRowInYBuckets(lineBuckets, item.y, tolerance, 4);
        if (!line) {
          line = { page: pageNum, y: item.y, x: item.x, items: [], size: item.size, pageHeight: viewport.height, _rowOrder: lines.length };
          lines.push(line);
          addRowToYBuckets(lineBuckets, line, 4);
        }
        line.items.push(item);
        line.size = Math.max(line.size, item.size);
        line.x = Math.min(line.x, item.x);
      }
      const horizontalLines = [];
      for (const sourceLine of lines) {
        sourceLine.items.sort((a, b) => a.x - b.x);
        let segment = null;
        let previousRight = null;
        const splitGap = Math.max(20, viewport.width * 0.055);
        for (const item of sourceLine.items) {
          const itemLeft = Number(item.x) || 0;
          const gap = previousRight === null ? 0 : itemLeft - previousRight;
          if (!segment || gap > splitGap) {
            segment = { page: pageNum, y: sourceLine.y, x: itemLeft, items: [], size: item.size, pageHeight: viewport.height };
            horizontalLines.push(segment);
          }
          segment.items.push(item);
          segment.size = Math.max(segment.size, item.size);
          segment.x = Math.min(segment.x, itemLeft);
          previousRight = Math.max(itemLeft, itemLeft + Math.max(0, Number(item.width) || 0));
        }
      }
      lines = horizontalLines;
      for (const line of lines) {
        line.items.sort((a, b) => a.x - b.x);
        line.text = normalizedHeadingText(line.items.map((item) => item.text).join(' '));
        const { xMin, xMax } = outlineHorizontalLineBounds(line.items);
        line.xStartRatio = Math.min(1, Math.max(0, xMin / Math.max(1, viewport.width)));
        line.xEndRatio = Math.min(1, Math.max(0, xMax / Math.max(1, viewport.width)));
      }

      // Older journal PDFs sometimes encode a centered section heading with a
      // smaller §N marker on a slightly different baseline from its title.
      // PDF text extraction then yields two lines (for example, “§ 2.” and
      // “TANGENT CYLINDERS AT …”), which prevents the repeated §N document
      // profile below from activating. Rejoin only a standalone short §N
      // marker with a nearby, right-adjacent all-caps title. This is deliberately
      // outline-local: page text, equation geometry, search, and OCR stay
      // untouched.
      const consumedSectionTitleLines = new Set();
      for (const markerLine of lines) {
        const markerText = String(markerLine.text || '').trim();
        if (!/^§\s*\d{1,2}(?:\s*\.\s*\d+)*\s*[.)]?\s*$/.test(markerText)) continue;
        const markerStart = Number(markerLine.xStartRatio);
        const markerEnd = Number(markerLine.xEndRatio);
        if (!Number.isFinite(markerStart) || !Number.isFinite(markerEnd) || markerStart > 0.48 || markerEnd - markerStart > 0.16) continue;
        const nearby = lines
          .filter((candidate) => candidate !== markerLine && !consumedSectionTitleLines.has(candidate))
          .map((candidate) => {
            const yGap = Math.abs(Number(candidate.y) - Number(markerLine.y));
            const xGap = Number(candidate.xStartRatio) - markerEnd;
            return { candidate, yGap, xGap };
          })
          .filter(({ candidate, yGap, xGap }) => {
            const title = String(candidate.text || '').trim();
            const titleWords = title.match(/[A-Za-z]{3,}/g) || [];
            const strongTitle = titleWords.length >= 2
              && titleWords.length <= 10
              && /^[A-Z0-9][A-Z0-9 &'’()\-–—]+[A-Z0-9.)]$/.test(title)
              && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title);
            return strongTitle
              && yGap <= Math.max(6, Number(markerLine.size) * 0.85, Number(candidate.size) * 0.70)
              && xGap >= -0.02
              && xGap <= 0.10;
          })
          .sort((a, b) => a.yGap - b.yGap || a.xGap - b.xGap);
        const titleLine = nearby[0]?.candidate;
        if (!titleLine) continue;
        markerLine.text = normalizedHeadingText(`${markerText} ${titleLine.text}`);
        markerLine.items.push(...titleLine.items);
        markerLine.items.sort((a, b) => a.x - b.x);
        markerLine.size = Math.max(Number(markerLine.size) || 0, Number(titleLine.size) || 0);
        markerLine.xStartRatio = Math.min(Number(markerLine.xStartRatio), Number(titleLine.xStartRatio));
        markerLine.xEndRatio = Math.max(Number(markerLine.xEndRatio), Number(titleLine.xEndRatio));
        consumedSectionTitleLines.add(titleLine);
      }
      if (consumedSectionTitleLines.size) lines = lines.filter((line) => !consumedSectionTitleLines.has(line));
    }
    for (const line of lines) {
      line.normalized = line.text.toLocaleLowerCase().replace(/\d+/g, '#').replace(/[^\p{L}#]+/gu, ' ').trim();
      if (line.normalized) {
        const key = line.normalized;
        const repeatRecord = repeatMap.get(key) || { pages: new Set(), top: 0, bottom: 0 };
        repeatRecord.pages.add(pageNum);
        if (line.y > viewport.height * 0.88) repeatRecord.top += 1;
        if (line.y < viewport.height * 0.10) repeatRecord.bottom += 1;
        repeatMap.set(key, repeatRecord);
      }
    }
    pages.push(lines);
  }

  // Some digitized books contain a nominal text layer whose custom-font
  // character map is badly broken: there may be hundreds of thousands of
  // characters, but a large fraction are C0/C1 control codes.  Such text is
  // not a trustworthy source for inferred Structure.  Prefer an empty
  // Structure over a long list of garbage headings; equation/OCR pipelines
  // remain independent.  The threshold is intentionally high so ordinary old
  // PDFs with a few damaged glyphs remain on the native-text path.
  if (nativeTextChars >= 1000 && nativeControlChars / nativeTextChars >= 0.18) return [];

  const bodySize = weightedMedianFont(fontSamples);
  // Infer one heading profile from repeated document-level evidence. This
  // prevents a fix for one old paper from weakening every other PDF.
  const allLines = pages.flat();
  // In historical OCR, the section sign § can be recognized as a dollar sign
  // ("$1. Statement", "$2, Lemmas"). This is outline-local, OCR-only, and
  // activated only by at least three distinct short, centered numbered title
  // lines on three pages; a solitary mathematical $ amount is not a heading.
  if (documentOcrActive) {
    const dollarSections = allLines.filter((line) => {
      const value = String(line?.text || '').trim();
      const match = value.match(/^\$\s*(\d{1,2})\s*[.,)]\s+([A-Z][A-Za-z].*)$/);
      if (!match || Number(line?.confidence) < 70) return false;
      const title = match[2].trim();
      const words = title.match(/[A-Za-z]{3,}/g) || [];
      const center = (Number(line.xStartRatio) + Number(line.xEndRatio)) / 2;
      const width = Number(line.xEndRatio) - Number(line.xStartRatio);
      return words.length >= 1 && words.length <= 13
        && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)
        && Number.isFinite(center) && Math.abs(center - 0.5) <= 0.14
        && width <= 0.72;
    });
    const numbers = new Set(dollarSections.map((line) => String(line.text).match(/^\$\s*(\d+)/)?.[1]));
    const spread = new Set(dollarSections.map((line) => line.page));
    if (numbers.size >= 3 && spread.size >= 3) {
      for (const line of dollarSections) line.text = line.text.replace(/^\$\s*(\d{1,2})\s*[.,)]\s+/, '§$1. ');
    }
    // The same printed section sign may OCR as an uppercase S ("S1.").
    // Resolve it only against an established multi-page §N profile and an
    // immediately neighboring *observed* section number, never as a generic
    // S-number heading (common in supplements and unrelated documents).
    const established = allLines.filter((line) => /^§\s*\d{1,2}\s*[.,)]\s+[A-Z]/.test(String(line.text || '').trim()));
    const existingNumbers = new Set(established.map((line) => Number(String(line.text).match(/^§\s*(\d+)/)?.[1])).filter(Number.isInteger));
    const existingPages = new Set(established.map((line) => line.page));
    if (existingNumbers.size >= 3 && existingPages.size >= 3) {
      for (const line of allLines) {
        const match = String(line?.text || '').trim().match(/^S\s*(\d{1,2})\s*[.,)]\s+([A-Z][A-Za-z].*)$/);
        if (!match || Number(line.confidence) < 70) continue;
        const number = Number(match[1]);
        if (existingNumbers.has(number) || !existingNumbers.has(number + 1)) continue;
        const title = match[2].trim();
        const words = title.match(/[A-Za-z]{3,}/g) || [];
        const center = (Number(line.xStartRatio) + Number(line.xEndRatio)) / 2;
        const width = Number(line.xEndRatio) - Number(line.xStartRatio);
        if (words.length < 2 || words.length > 12
            || /[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)
            || !Number.isFinite(center) || Math.abs(center - 0.5) > 0.14
            || width > 0.70) continue;
        line.text = `§${number}. ${title}`;
      }
    }
  }
  const lineMetrics = (line) => {
    const value = String(line?.text || '').trim();
    const ratio = Number(line?.size) / Math.max(1, bodySize);
    const center = (Number(line?.xStartRatio) + Number(line?.xEndRatio)) / 2;
    const width = Number(line?.xEndRatio) - Number(line?.xStartRatio);
    const words = value.split(/\s+/).filter(Boolean);
    return { value, ratio, center, width, words };
  };

  const numberedBodyLooksLikeProse = (body) => {
    const value = normalizedHeadingText(body);
    if (!value) return false;
    const words = value.split(/\s+/).filter(Boolean);
    const proseLead = /^(?:let|assume|suppose|then|if|for|where|when|by|from|to|we|choose|since|using|applying|combining|conversely|inserting|substituting|differentiating|there)\b/i.test(value);
    const finiteVerb = /\b(?:is|are|was|were|has|have|had|does|do|did|can|could|will|would|shall|should|may|might|must|proved?|shows?|showed|gives?|gave|means?|contains?|concerns?|concerned|becomes?|follows?|implies?|satisfies?|holds?|likes?|came|reflects?)\b/i.test(value);
    const sentenceLead = /^(?:the|this|that|these|those|we|i|he|she|it|they|there|most|not|in|on|at|by|since|because|although)\b/i.test(value);
    const citationLike = /\[[^\]]{1,16}\]/.test(value);
    const clauseCue = /\b(?:and hence|and therefore|and thus|we have|we obtain)\b/i.test(value);
    return proseLead || clauseCue || (finiteVerb && (words.length >= 5 || sentenceLead || citationLike));
  };

  const qualifiedSectionMarkerLines = allLines.filter((line) => {
    const { value, ratio, center, width, words } = lineMetrics(line);
    const match = value.match(/^§\s*\d+(?:\s*\.\s*\d+)*\s*[.)]?\s+(.+)/i);
    const title = String(match?.[1] || '').trim();
    const titleWords = title.match(/[A-Za-z]{3,}/g) || [];
    // Older digitized journals often print genuine §N section headings at
    // body size and flush left. Requiring enlarged or centered typography made
    // one such heading disappear, which in turn disabled the document-level
    // §N profile and let ordinary prose/formula fragments pollute Structure.
    // A short multi-word all-caps title is itself strong section evidence; the
    // repeated §N grammar across the document remains the profile gate.
    const strongLegacyMarker = titleWords.length >= 2
      && /^[A-Z0-9][A-Z0-9 &'’()\-–—]+[A-Z0-9.)]$/.test(title);
    return Boolean(match)
      && /^[A-Z][A-Za-z]{2,}/.test(title)
      && titleWords.length >= 2
      && words.length <= 14
      && (strongLegacyMarker || !/[.!?]$/.test(value))
      && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)
      && (strongLegacyMarker || ratio >= 1.10 || (Number.isFinite(center) && Math.abs(center - 0.5) <= 0.14 && width <= 0.70));
  });
  const sectionMarkerNumbers = new Set(qualifiedSectionMarkerLines.map((line) => String(line.text || '').match(/^§\s*(\d+(?:\s*\.\s*\d+)*)/)?.[1]).filter(Boolean));
  const explicitSectionMarkerMode = sectionMarkerNumbers.size >= 2;
  // Once repeated multi-word §N headings establish the document's heading
  // grammar, their short single-word peers are also real sections. Older
  // journals commonly end with "§5. Supplement", "§6. Notes", etc. Requiring
  // two title words silently drops them, while accepting all bare §N prose
  // without a document profile would be too permissive.
  const explicitSingleWordSectionLines = new Set(explicitSectionMarkerMode ? allLines.filter((line) => {
    const { value, ratio, center, width } = lineMetrics(line);
    return /^§\s*\d+(?:\s*\.\s*\d+)*\s*[.)]\s+[A-Z][a-z]{3,30}$/.test(value)
      && (ratio >= 1.08 || (Number.isFinite(center) && Math.abs(center - 0.5) <= 0.14 && width <= 0.45));
  }) : []);

  const strongModernNumberedLines = allLines.filter((line) => {
    const { value, ratio, words } = lineMetrics(line);
    if (words.length > 18 || ratio < 1.15) return false;
    if (headingNumberDepth(value) === null || numberedResultDeclarationInOutline(value)) return false;
    const match = value.match(/^\s*(?:§\s*)?(?:\d+(?:\.\d+){0,4}|[A-H](?:\.\d+){1,4}|[A-H][.)])(?:[.)])?\s+(.+)$/);
    const title = String(match?.[1] || '').trim();
    if (!match || !/^[A-Z][A-Za-z]{2,}/.test(title)) return false;
    if (/^(?:Let|Assume|Suppose|Then|If|For|Where|When|We|Choose|Since|Using|To)\b/i.test(title)) return false;
    if (isLikelyFormulaHeading(value) || isMathEnvironmentLabel(value)) return false;
    return (title.match(/[A-Za-z]{3,}/g) || []).length >= 1;
  });
  const modernHierarchyMode = !documentOcrActive && !explicitSectionMarkerMode && strongModernNumberedLines.length >= 5;

  // Real scanned-text-layer books can have a strongly bimodal font profile:
  // true chapter titles use noticeably larger type, while display mathematics
  // has enlarged glyph boxes (integrals, fractions, sums). If several genuine
  // large lexical titles occur across distinct pages, do not allow the loose
  // 1.18x native fallback to promote those math glyphs or prose fragments.
  // Explicit numbered headings and canonical headings still use their own
  // independent rules; this applies ONLY to unnumbered style inference.
  const nativeStrongTitle = (text) => {
    const value = normalizedHeadingText(text);
    const alphaWords = value.match(/[A-Za-z]{3,}/g) || [];
    const letters = (value.match(/[A-Za-z]/g) || []).length;
    const compact = value.replace(/\s/g, '');
    if (/^(?:part|chapter|lecture|appendix)\s+(?:\d+|[IVXLC]+|[A-Z])[.]?$/i.test(value)) return true;
    if (/^(?:Let|Consider|Now|Then|For|If|Since|Suppose|Assume|We|By|In|Using|There|Given)\b/i.test(value)) return false;
    return alphaWords.length >= 2 && alphaWords.length <= 11
      && letters / Math.max(1, compact.length) >= 0.72
      && !/[=+*<>~{}\[\]\\∫∑∏√∂∇∞]/u.test(value)
      && (value.match(/[;?!:]/g) || []).length < 2
      && !isLikelyFormulaHeading(value) && !obviousProseFragmentInOutline(value)
      && (!/\.[ \t]+[A-Z][a-z]/.test(value) || /^appendix\s+[A-Z]\.\s+/i.test(value));
  };
  const nativeLargeTitlePages = new Set(!documentOcrActive ? allLines
    .filter((line) => Number(line.size) / Math.max(1, bodySize) >= 1.63
      && Number(line.xStartRatio) <= 0.48
      && nativeStrongTitle(line.text))
    .map((line) => line.page) : []);
  const nativeBookTitleProfile = nativeLargeTitlePages.size >= 5;

  const paragraphLeadLines = allLines.filter((line) => {
    const value = String(line?.text || '').trim();
    const match = value.match(/^(\d{1,2})[.)]\s+([^.!?]{2,90})[.]\s+(?=[A-Z][a-z])/);
    if (!match) return false;
    const title = match[2].trim();
    if (!/^[A-Z]/.test(title) || /[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)) return false;
    return (title.match(/[A-Za-z]{3,}/g) || []).length >= 1;
  });
  const paragraphLeadNumbers = new Set(paragraphLeadLines.map((line) => String(line.text || '').match(/^(\d{1,2})/)?.[1]).filter(Boolean));
  const legacyParagraphMode = !explicitSectionMarkerMode && !modernHierarchyMode && paragraphLeadNumbers.size >= 3;

  const legacyCenteredLines = allLines.filter((line) => {
    const { value, ratio, center, width, words } = lineMetrics(line);
    const match = value.match(/^(\d{1,2})[.)]\s+(.+)$/);
    if (!match || words.length > 12 || ratio < 0.98) return false;
    const title = match[2].trim();
    if (!/^[A-Z]/.test(title)) return false;
    if (/^(?:Let|Assume|Suppose|Then|If|For|Where|When|We|Choose|Since|Using|To)\b/i.test(title)) return false;
    if (/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)) return false;
    return Number.isFinite(center) && Math.abs(center - 0.5) <= 0.13 && width <= 0.72;
  });
  const legacyCenteredNumbers = new Set(legacyCenteredLines.map((line) => String(line.text || '').match(/^(\d{1,2})/)?.[1]).filter(Boolean));
  const legacyCenteredMode = !explicitSectionMarkerMode && !modernHierarchyMode && !legacyParagraphMode && legacyCenteredNumbers.size >= 3;

  // OCR bounding boxes in old journal scans are not reliable font metrics: a
  // genuine centered section heading can have the same (or even smaller) box
  // height as body text.  Promote only a repeated, high-confidence numbered
  // grammar at the document level.  This keeps OCR typography from becoming a
  // general prose detector.
  const ocrCenteredNumberedLines = documentOcrActive ? allLines.filter((line) => {
    const value = String(line?.text || '').trim();
    const match = value.match(/^(\d{1,2})[.,)]\s+(.+)$/);
    if (!match || Number(line?.confidence) < 72) return false;
    const title = String(match[2] || '').trim();
    const center = (Number(line?.xStartRatio) + Number(line?.xEndRatio)) / 2;
    const width = Number(line?.xEndRatio) - Number(line?.xStartRatio);
    const titleWords = title.match(/[A-Za-z]{3,}/g) || [];
    return /^[A-Z]/.test(title)
      && titleWords.length >= 1
      && titleWords.length <= 12
      && !numberedBodyLooksLikeProse(title)
      && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)
      && Number.isFinite(center) && Math.abs(center - 0.5) <= 0.15
      && width <= 0.76;
  }) : [];
  const ocrCenteredNumbers = new Set(ocrCenteredNumberedLines.map((line) => String(line.text || '').match(/^(\d{1,2})/)?.[1]).filter(Boolean));
  const ocrCenteredNumberedMode = documentOcrActive && ocrCenteredNumbers.size >= 3;

  // Applied-math notes and modern papers often use ordinary left-aligned
  // numbered section headings. OCR preserves the numbering and words far more
  // reliably than it preserves relative font height. Infer this grammar only
  // from repeated, high-confidence, non-prose headings spanning multiple pages.
  // Once established, the profile suppresses random enlarged OCR fragments
  // such as short formula residues from becoming Structure entries.
  const ocrExplicitNumberedStrongLines = documentOcrActive ? allLines.filter((line) => {
    const value = String(line?.text || '').trim();
    const match = value.match(/^(\d{1,2})[.)]?\s+(.+)$/);
    if (!match || Number(line?.confidence) < 70) return false;
    const title = String(match[2] || '').trim();
    const titleWords = title.match(/[A-Za-z]{3,}/g) || [];
    const titleCaseWords = title.match(/\b[A-Z][A-Za-z]{2,}\b/g) || [];
    const titleCaseOverride = titleWords.length >= 2 && titleCaseWords.length >= Math.ceil(titleWords.length * 0.6);
    const shortTitleOverride = titleWords.length === 1 && titleCaseWords.length === 1 && title.split(/\s+/).length <= 5 && !numberedBodyLooksLikeProse(title);
    if (!/^[\"'‘’]?[A-Z]/.test(title) || (titleWords.length < 2 && !shortTitleOverride && !isKnownHeading(title.replace(/^[\"'‘’]/, ''))) || titleWords.length > 14) return false;
    if ((numberedBodyLooksLikeProse(title) && !titleCaseOverride) || isMathEnvironmentLabel(title)) return false;
    if (/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)) return false;
    return true;
  }) : [];
  const ocrExplicitNumberedStrongNumbers = new Set(ocrExplicitNumberedStrongLines.map((line) => String(line.text || '').match(/^(\d{1,2})/)?.[1]).filter(Boolean));
  const ocrExplicitNumberedStrongPages = new Set(ocrExplicitNumberedStrongLines.map((line) => Number(line.page)).filter(Number.isFinite));
  const ocrExplicitNumberedMode = documentOcrActive && (
    (ocrExplicitNumberedStrongNumbers.size >= 4 && ocrExplicitNumberedStrongPages.size >= 2) ||
    (ocrExplicitNumberedStrongNumbers.size >= 3 && ocrExplicitNumberedStrongPages.size >= 3)
  );
  const ocrExplicitNumberedLines = ocrExplicitNumberedMode ? allLines.filter((line) => {
    const value = String(line?.text || '').trim();
    const match = value.match(/^(\d{1,2})[.)]?\s+(.+)$/);
    if (!match || Number(line?.confidence) < 66) return false;
    const title = String(match[2] || '').trim();
    const titleWords = title.match(/[A-Za-z]{3,}/g) || [];
    const titleCaseWords = title.match(/\b[A-Z][A-Za-z]{2,}\b/g) || [];
    const titleCaseOverride = titleWords.length >= 2 && titleCaseWords.length >= Math.ceil(titleWords.length * 0.6);
    const shortTitleOverride = titleWords.length === 1 && titleCaseWords.length === 1 && title.split(/\s+/).length <= 5 && !numberedBodyLooksLikeProse(title);
    if (!/^[\"'‘’]?[A-Z]/.test(title) || (titleWords.length < 1 && !shortTitleOverride) || titleWords.length > 14) return false;
    if ((numberedBodyLooksLikeProse(title) && !titleCaseOverride) || isMathEnvironmentLabel(title)) return false;
    if (/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)) return false;
    return true;
  }) : [];

  // Several classic books/journals number sections with a hyphen (6-2, 6-3)
  // while equations use the parenthesized form (6-7).  OCR frequently preserves
  // the former even when font sizing is unreliable.  Require repeated section
  // grammar plus title words; equation-only lines cannot activate this profile.
  const ocrHyphenSectionLines = documentOcrActive ? allLines.filter((line) => {
    const value = String(line?.text || '').trim();
    const match = value.match(/^(\d{1,2})-(\d{1,2})[.)]?\s+(.+)$/);
    if (!match || Number(line?.confidence) < 62) return false;
    const title = String(match[3] || '').trim();
    const titleWords = title.match(/[A-Za-z]{2,}/g) || [];
    return titleWords.length >= 1
      && titleWords.length <= 12
      && !numberedBodyLooksLikeProse(title)
      && !/^[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title);
  }) : [];
  const ocrHyphenSectionMode = documentOcrActive && new Set(ocrHyphenSectionLines.map((line) => String(line.text || '').match(/^(\d{1,2}-\d{1,2})/)?.[1]).filter(Boolean)).size >= 2;
  // Classic books can use the same 1-2 / 1-3 section
  // grammar in a native text layer. When that grammar repeats strongly, use
  // it as the document profile instead of treating every slightly enlarged
  // prose/formula line as a possible heading.
  const nativeHyphenSectionLines = !documentOcrActive ? allLines.filter((line) => {
    const value = String(line?.text || '').trim();
    const match = value.match(/^(\d{1,2})-(\d{1,2})[.)]?\s+(.+)$/);
    if (!match) return false;
    const title = String(match[3] || '').trim();
    const titleWords = title.match(/[A-Za-z]{2,}/g) || [];
    const letters = title.replace(/[^A-Za-z]/g, '');
    const strongUppercaseTitle = letters.length >= 4 && letters === letters.toUpperCase();
    return strongUppercaseTitle
      && titleWords.length >= 1
      && titleWords.length <= 14
      && !numberedBodyLooksLikeProse(title)
      && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(title)
      && Number(line?.xStartRatio) < 0.30;
  }) : [];
  const nativeHyphenSectionMode = !documentOcrActive
    && new Set(nativeHyphenSectionLines.map((line) => String(line.text || '').match(/^(\d{1,2}-\d{1,2})/)?.[1]).filter(Boolean)).size >= 3;
  const ocrCenteredLineSet = new Set(ocrCenteredNumberedLines);
  const ocrHyphenLineSet = new Set(ocrHyphenSectionLines);
  const nativeHyphenLineSet = new Set(nativeHyphenSectionLines);
  const ocrExplicitNumberedLineSet = new Set(ocrExplicitNumberedLines);
  // Contents blocks are navigational summaries, not document-body headings.
  // Do not discard the entire page: older papers often put the real first
  // section immediately below the table of contents on page 1. Mark only the
  // actual TOC lines so the body heading remains eligible.
  const contentsLines = new Set();
  // Old scans may carry a printed running folio and OCR-confusable letters in
  // the Contents header ("CONTEN1'S vii"). Accept the variant ONLY as a
  // candidate header; multiple navigation rows below must still corroborate
  // that this is a real table of contents before it suppresses any headings.
  const contentsHeader = (text) => /^(?:(?:table\s+of\s+)?contents|conten1'?s)(?:\s+[ivxlcdm]{1,7})?$/i.test(String(text || '').trim());
  const shortTocEntry = (text) => {
    const value = String(text || '').trim();
    if (!value || value.length > 100) return false;
    if (/^(?:bibliography|references|index|errata)(?:\s+\d{1,4})?$/i.test(value)) return true;
    if (/^appendix(?:\s+[A-Z0-9]+)?\s*$/i.test(value)) return true;
    if (/^appendix(?:\s+[A-Z0-9]+)?(?:[:.]|\s)\s*\S/i.test(value)) return true;
    if (!/^(?:\d+(?:[.\-]\d+){0,4}|[A-H](?:\.\d+){1,4}|[A-H][.)])(?:[.)])?\s+\S/.test(value)) return false;
    const words = value.split(/\s+/).filter(Boolean);
    if (words.length > 12) return false;
    // A body section that immediately continues into prose is not a TOC row.
    if (/^[^.!?]{2,90}\.\s+[A-Z][a-z]/.test(value)) return false;
    return true;
  };
  for (const lines of pages) {
    const orderedLines = [...lines].sort((a, b) => Number(b.y) - Number(a.y));
    const contentsIndex = orderedLines.findIndex((line) => contentsHeader(line.text));
    if (contentsIndex >= 0) {
      const possibleContents = [orderedLines[contentsIndex]];
      let tocRows = 0;
      const tocKeys = new Set();
      const tocRowKey = (value) => normalizedHeadingText(value)
        .replace(/(?:\.\s*){3,}.*$/, '')
        .replace(/\s+\d+\s*$/, '')
        .toLocaleLowerCase();
      for (let i = contentsIndex + 1; i < orderedLines.length; i += 1) {
        const line = orderedLines[i];
        if (shortTocEntry(line.text)) {
          const key = tocRowKey(line.text);
          // A short document may begin its real body on the same page as the
          // contents. Once a TOC title repeats without its trailing page
          // number, the duplicate is the body heading, not another TOC row.
          if (tocRows >= 2 && key && tocKeys.has(key)) break;
          possibleContents.push(line);
          if (key) tocKeys.add(key);
          tocRows += 1;
          continue;
        }
        if (tocRows >= 2) break;
      }
      // A single ambiguous "Contents"-looking line is not enough to
      // suppress a real section or Appendix. Require at least two TOC rows.
      if (tocRows >= 2) for (const line of possibleContents) contentsLines.add(line);
    }
    // Also cover traditional dotted-leader TOCs even when the word Contents
    // is absent or extracted poorly.
    const dottedRows = orderedLines.filter((line) => /^(?:\d+(?:\.\d+)*|[A-Z](?:\.\d+)*)\s+.*(?:\.\s*){3,}.*\d+\s*$/.test(line.text));
    if (dottedRows.length >= 4) for (const line of dottedRows) contentsLines.add(line);
  }
  // A preliminary Contents page is reliable evidence that preceding large
  // typography belongs to the book's cover/series/author metadata. Do not
  // remove genuine numbered headings or known Preface/Introduction headings.
  const preliminaryContentsPage = pages
    .flatMap((lines) => lines.filter((line) => contentsHeader(line.text)).map((line) => line.page))
    .filter((page) => Number.isInteger(page) && page <= Math.min(12, Math.ceil(maxPages * 0.10)))
    .sort((a, b) => a - b)[0] || null;
  const candidates = [];
  for (const lines of pages) {
    for (const line of lines) {
      const text = line.text;
      if (!text || text.length < 2) continue;
      if (contentsLines.has(line)) continue;
      if (preliminaryContentsPage && line.page < preliminaryContentsPage
          && !isKnownHeading(text) && headingNumberDepth(text) === null) continue;
      if (numberedResultDeclarationInOutline(text) || numberedFormulaFragmentInOutline(text)
          || obviousProseFragmentInOutline(text)) continue;
      if (explicitSectionMarkerMode) {
        const value = String(text || '').trim();
        const explicitSection = qualifiedSectionMarkerLines.includes(line);
        const conventional = /^(?:abstract|introduction|references|bibliography|appendix(?:\s+[A-Z0-9]+)?(?:[:.]|\s|$))/i.test(value);
        if (!explicitSection && !explicitSingleWordSectionLines.has(line) && !conventional) continue;
      }
      // On a title page, material above an Abstract heading is title/author
      // metadata rather than document structure.
      if (line.page === 1) {
        const abstractLine = lines.find((item) => /^abstract$/i.test(item.text));
        if (abstractLine && line.y > abstractLine.y + 1.5) continue;
        const firstBodyHeading = lines.find((item) => isKnownHeading(item.text) || headingNumberDepth(item.text) !== null);
        if (firstBodyHeading && line.y > firstBodyHeading.y + 1.5) continue;
      }
      // A section heading can share one extracted line with the first sentence
      // of its paragraph, e.g. "1. Introduction. Riemannian ...". Keep the
      // heading prefix while preserving the original line geometry as anchor.
      let headingText = text;
      if (documentOcrActive && /^(\d{1,2}),\s+[A-Z]/.test(headingText)) headingText = headingText.replace(/^(\d{1,2}),/, '$1.');
      if (documentOcrActive) headingText = headingText.replace(/^(\s*\d{1,2}(?:[.)])?\s+)[\"'‘’](?=[A-Z])/, '$1');
      let headingWasParagraphLead = false;
      // Paragraph-leading section recovery is primarily for OCR/scanned papers.
      // A narrow exception lets an already-established legacy centered profile
      // recover explicit hierarchical subsections such as 2.1; ordinary native
      // numbered prose remains excluded from this relaxation.
      if (legacyParagraphMode || documentOcrActive || (legacyCenteredMode && /^\s*\d+(?:\.\d+)+/.test(headingText))) {
        const numberedLead = headingText.match(/^(\s*(?:§\s*)?(?:\d+(?:\.\d+){0,4}|[A-H](?:\.\d+){1,4}|[A-H][.)])(?:[.)])?\s+)(.+)$/);
        if (numberedLead) {
          const body = numberedLead[2];
          // A body sentence can begin with an author's initial, for example
          // "B. Gidas, W. M. Ni and L. Nirenberg [2]. ...".  Treating the
          // leading "B." as an alphabetic section marker made the sentence
          // boundary after an author initial look like a heading boundary.
          // Reject only this citation-shaped paragraph lead; legitimate
          // alphabetic sections such as "B. Methods. ..." remain eligible.
          const authorCitationLead = /^[A-Z][A-Za-z'’.-]{2,},\s+(?:[A-Z]\.\s*){1,3}/.test(body)
            && /\[\s*\d{1,3}\s*\]/.test(body.slice(0, 100));
          const boundary = body.match(/^(.{2,90}?)\.\s+(?=[A-Z][a-z])/);
          if (boundary && !authorCitationLead && !numberedBodyLooksLikeProse(boundary[1])) {
            headingText = normalizedHeadingText(`${numberedLead[1]}${boundary[1]}`);
            headingWasParagraphLead = true;
          }
        }
      }
      if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/.test(headingText)) continue;
      if (headingText.length > 125) continue;
      const words = headingText.split(/\s+/).filter(Boolean);
      if (words.length > 18) continue;
      // In OCR text, an author initial at the start of a paragraph (for
      // example, ‘B. Gidas, W. M. Ni ... [2]’) can look exactly like an
      // alphabetic section marker. Reject only that citation-shaped author
      // form; genuine ‘B. Methods’ style section headings remain eligible.
      if (/^[A-H][.)]\s+[A-Z][A-Za-z'’.-]{2,},\s+(?:[A-Z]\.\s*){1,4}/.test(headingText)
          && /\[\s*\d{1,3}\s*\]/.test(headingText.slice(0, 120))) continue;
      // Parenthesized numeric labels sitting in either page margin are display
      // equation tags, not document headings. This matters especially for older
      // papers whose equation numbers are consistently left-aligned.
      if (isMarginEquationLabelLineForStructure(line)) continue;
      const numberedDepth = headingNumberDepth(headingText);
      const known = isKnownHeading(headingText);
      const ratio = line.size / Math.max(1, bodySize);
      const lineCenter = (Number(line.xStartRatio) + Number(line.xEndRatio)) / 2;
      const lineWidth = Number(line.xEndRatio) - Number(line.xStartRatio);
      const centered = Number.isFinite(lineCenter) && Math.abs(lineCenter - 0.5) <= 0.12;
      const containerHeading = /^(?:chapter|lecture)\s+(?:\d+|[IVXLC]+)\s*$/i.test(headingText) && ratio >= 1.25;

      if (modernHierarchyMode || (!documentOcrActive && !nativeHyphenSectionMode && !legacyParagraphMode && !legacyCenteredMode && !explicitSectionMarkerMode)) {
        // Modern/default native-text profile: typography first.
        const acronymHeading = /^(?:[A-Z][A-Z0-9&/+\-]{1,9})(?:\s+[A-Z][A-Z0-9&/+\-]{1,9}){0,3}$/.test(headingText) && ratio >= 1.08;
        // Dense tables can pull the document-wide body-size estimate downward,
        // making ordinary prose look slightly "large".  Reject only prose-shaped
        // native fallback lines near that threshold; keep the long-established
        // numbered, multilingual, short-title and continuation behavior intact.
        const nativeStyleCommaCount = (headingText.match(/[,;]/g) || []).length;
        const nativeStyleProseLike = ratio < 1.35 && (
          (words.length >= 9 && lineWidth >= 0.72)
          || (/^[a-z]/.test(headingText) && words.length >= 5)
          || (nativeStyleCommaCount >= 2 && words.length >= 6)
          || /[.!?]\s+[A-Z]/.test(headingText)
        );
        const styleHeading = ratio >= (nativeBookTitleProfile && numberedDepth === null && !known ? 1.55 : 1.18)
          && words.length <= 14 && !/[.;,]$/.test(headingText) && !nativeStyleProseLike
          && (!nativeBookTitleProfile || numberedDepth !== null || known || nativeStrongTitle(headingText));
        if (numberedDepth !== null && ratio < 1.08 && !known) continue;
        // A number followed by prose or OCR formula debris is not a heading.
        // Require book headings to have a lexical, title-like body, but leave
        // the established journal/modern profile unchanged.
        if (nativeBookTitleProfile && numberedDepth !== null && !known) {
          const numberedBody = headingText.replace(/^\s*(?:§\s*)?(?:\d+(?:\.\d+){0,4}|[A-H](?:\.\d+){1,4}|[A-H][.)])(?:[.)])?\s+/, '');
          if (!/^[A-Z]/.test(numberedBody) || numberedBodyLooksLikeProse(numberedBody)
              || !nativeStrongTitle(numberedBody)) continue;
        }
        if (!known && numberedDepth === null && !styleHeading && !acronymHeading && !containerHeading) continue;
        if (isMathEnvironmentLabel(headingText) && ratio < 1.35) continue;
      } else {
        // Legacy/OCR profiles admit only the repeated grammar selected above.
        const numberedTitleMatch = headingText.match(/^\s*(?:§\s*)?((?:\d+(?:\.\d+){0,4}|[A-H](?:\.\d+){1,4}|[A-H][.)]))(?:[.)])?\s+(.+)$/);
        const numberedTitleBody = String(numberedTitleMatch?.[2] || '').trim();
        const proseLead = numberedBodyLooksLikeProse(numberedTitleBody);
        const titleWords = numberedTitleBody.match(/[A-Za-z]{3,}/g) || [];
        const centeredNumbered = Boolean(numberedTitleMatch)
          && !proseLead
          && !/[.!?]\s+(?:Then|Thus|Hence|This|The|We|It|By|Since|For)\b/i.test(numberedTitleBody)
          && /^[A-Z]/.test(numberedTitleBody)
          && titleWords.length >= 1
          && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(numberedTitleBody)
          && centered
          && (lineWidth <= 0.74 || (lineWidth <= 0.82 && titleWords.length >= 3 && !/[@~]/.test(numberedTitleBody)));
        const explicitMarkerHeading = explicitSectionMarkerMode
          && (qualifiedSectionMarkerLines.includes(line) || explicitSingleWordSectionLines.has(line));
        const paragraphNumbered = headingWasParagraphLead && numberedDepth !== null && (legacyParagraphMode || (legacyCenteredMode && numberedDepth >= 1));
        const legacyCenteredNumbered = legacyCenteredMode && centeredNumbered;
        const ocrProfileNumbered = (ocrCenteredNumberedMode && ocrCenteredLineSet.has(line))
          || (ocrHyphenSectionMode && ocrHyphenLineSet.has(line))
          || (ocrExplicitNumberedMode && ocrExplicitNumberedLineSet.has(line));
        const ocrNumbered = documentOcrActive && (ocrProfileNumbered || (centeredNumbered && (ratio >= 1.04 || headingWasParagraphLead)));
        const nativeHyphenNumbered = nativeHyphenSectionMode && nativeHyphenLineSet.has(line);
        const acronymHeading = /^(?:[A-Z][A-Z0-9&/+\-]{1,9})(?:\s+[A-Z][A-Z0-9&/+\-]{1,9}){0,3}$/.test(headingText)
          && ratio >= 1.08 && centered && !ocrExplicitNumberedMode;
        const styleHeading = documentOcrActive && !ocrExplicitNumberedMode
          && ratio >= 1.42 && words.length <= 10 && centered && lineWidth <= 0.65
          && /^[A-Z][A-Za-z0-9 &'’()\-–—]+$/.test(headingText)
          && !numberedBodyLooksLikeProse(headingText);
        if (!known && !explicitMarkerHeading && !paragraphNumbered && !legacyCenteredNumbered && !ocrNumbered && !nativeHyphenNumbered && !styleHeading && !acronymHeading && !containerHeading) continue;
        if (isMathEnvironmentLabel(headingText) && !(documentOcrActive && ocrHyphenSectionMode && ocrHyphenLineSet.has(line))) continue;
      }
      if (/^(?:©|copyright\b)/i.test(headingText)) continue;
      const metadataHeadingText = headingText.normalize('NFKC');
      if (/^(?:\d{4}\s+)?Mathematics Subject Classification\b/i.test(metadataHeadingText)) continue;
      if (/\barXiv:|\b(?:department|university|e-?mail|address:)\b/i.test(headingText)) continue;
      if (!known && numberedDepth === null) {
        const lexicalWords = headingText.match(/[A-Za-z]{2,}|\p{Script=Han}{2,}/gu) || [];
        if (!lexicalWords.length) continue;
      }
      // Standalone theorem/lemma/proof headings are indexed by Results/proof
      // relations, not by the document outline. Numbered section titles that
      // merely contain words like "PROOF OF THEOREM 2" have already passed
      // through the numbered-heading grammar above and do not start with a
      // math-environment label themselves.
      if (nativeBookTitleProfile && !documentOcrActive && isKnownHeading(headingText)
          && /^appendix(?:\s+[A-Z0-9]+)?[.]?$/i.test(headingText)
          && Number(line.size) < bodySize * 0.96
          && Number(line.y) > Number(line.pageHeight) * 0.87) continue;
      if (isLikelyFormulaHeading(headingText) && !(documentOcrActive && ocrHyphenSectionMode && ocrHyphenLineSet.has(line))) continue;
      if (/^[\d\s()[\]{}.,:+\-–—=<>≤≥∑∫∞]+$/.test(headingText)) continue;
      // Bibliography/reference fragments can be typographically prominent in
      // extracted PDFs and used to leak into the detected Contents list.
      // Reject only strong reference metadata signatures; ordinary headings
      // remain eligible.
      if (/https?:\/\/|\b(?:doi|arXiv|ISBN)\b|\b10\.\d{4,9}\//i.test(headingText)) continue;
      if (/^\d{4}\b.*\b(?:Springer(?:-Verlag)?|Press|Proceedings?|Journal|Communications?|Lecture Notes)\b/i.test(headingText)) continue;
      if (/^\d{4,}\s+[a-z]/.test(headingText) && words.length >= 5) continue;

      const repetition = repeatMap.get(line.normalized);
      const repeatedOn = repetition?.pages?.size || 0;
      const repeatedPages = [...(repetition?.pages || [])].sort((a, b) => a - b);
      let consecutiveRepeats = repeatedPages.length ? 1 : 0;
      let longestConsecutiveRepeats = consecutiveRepeats;
      for (let i = 1; i < repeatedPages.length; i += 1) {
        consecutiveRepeats = repeatedPages[i] === repeatedPages[i - 1] + 1 ? consecutiveRepeats + 1 : 1;
        longestConsecutiveRepeats = Math.max(longestConsecutiveRepeats, consecutiveRepeats);
      }
      const edgeRepeat = ((repetition?.top || 0) + (repetition?.bottom || 0)) >= repeatedOn * 0.7;
      // Facing-page book headers often repeat every *other* page. The old
      // consecutive-page check missed Appendix A/B/C running heads and indexed
      // them as separate chapter entries. Restrict this additional pattern to
      // small, top-margin lines in native books with a strong title profile.
      // Discard distant TOC/header occurrences before looking for repeated
      // facing-page headers: an Appendix C TOC row on page 6 must not break
      // the even-page running-header sequence at pages 240, 242, 244, 246.
      const alternatingHeaderPages = repeatedPages.some((page) =>
        repeatedPages.includes(page + 2) && repeatedPages.includes(page + 4)
        && (line.page === page || line.page === page + 2 || line.page === page + 4));
      const alternatingBookHeader = !documentOcrActive && nativeBookTitleProfile
        && alternatingHeaderPages && repeatedOn >= 3
        && Number(line.size) < bodySize * 1.08
        && Number(line.y) > Number(line.pageHeight) * 0.87;
      const likelyRunningHeader = repeatedOn >= 3 && edgeRepeat && (
        repeatedOn >= Math.max(3, Math.ceil(maxPages * 0.25)) || longestConsecutiveRepeats >= 3
        || alternatingBookHeader
      );
      if (likelyRunningHeader) continue;

      candidates.push({
        title: headingText,
        page: line.page,
        depth: (documentOcrActive && ocrHyphenSectionMode && ocrHyphenLineSet.has(line))
          || (nativeHyphenSectionMode && nativeHyphenLineSet.has(line))
          ? 1
          : headingDepthFromStyle({ ...line, text: headingText }, bodySize),
        size: Number(line.size.toFixed(2)),
        y: line.y,
        xStartRatio: Number(line.xStartRatio),
        xEndRatio: Number(line.xEndRatio),
        ratio: Math.min(1, Math.max(0, (line.pageHeight - line.y) / Math.max(1, line.pageHeight)))
      });
    }
  }

  // Older journals often wrap a centered section heading onto a second
  // body-size line (for example, "... More General" / "Right-Hand Side").
  // Promote only a short centered line immediately below an already accepted
  // numbered heading; this is deliberately not a general style-heading rule.
  if (documentOcrActive || legacyCenteredMode) for (const candidate of [...candidates]) {
    if (headingNumberDepth(candidate.title) === null) continue;
    const lines = pages[candidate.page - 1] || [];
    const continuation = lines
      .filter((line) => {
        if (!line?.text || line.text === candidate.title) return false;
        const center = (Number(line.xStartRatio) + Number(line.xEndRatio)) / 2;
        const width = Number(line.xEndRatio) - Number(line.xStartRatio);
        const verticalGap = candidate.y - Number(line.y);
        const words = String(line.text).trim().split(/\s+/).filter(Boolean);
        return Number.isFinite(center)
          && Math.abs(center - 0.5) <= 0.10
          && width <= 0.42
          && verticalGap > 0
          && verticalGap <= Math.max(30, Number(candidate.size) * 2.2)
          && words.length >= 1
          && words.length <= 8
          && !/[=≤≥≠≈∫∑∏√∂∇∞^_]/u.test(line.text)
          && !/[.!?]$/.test(candidate.title);
      })
      .sort((a, b) => Number(b.y) - Number(a.y))[0];
    if (!continuation) continue;
    const continuationKey = `${candidate.page}:${continuation.text.toLocaleLowerCase()}`;
    if (!candidates.some((item) => `${item.page}:${item.title.toLocaleLowerCase()}` === continuationKey)) {
      candidates.push({
        title: continuation.text,
        page: candidate.page,
        depth: candidate.depth,
        size: Number(continuation.size.toFixed(2)),
        y: continuation.y,
        xStartRatio: Number(continuation.xStartRatio),
        xEndRatio: Number(continuation.xEndRatio),
        ratio: Math.min(1, Math.max(0, (continuation.pageHeight - continuation.y) / Math.max(1, continuation.pageHeight))),
        continuationOnly: true,
      });
    }
  }

  // Book/lecture headings are often set across several large-font lines, and
  // an intermediate title line may end in punctuation (for example a comma).
  // Once a Chapter/Lecture anchor is accepted, recover only adjacent
  // same-style lines directly below it. This keeps body prose out while avoiding
  // fragmented Structure rows for books and lecture notes.
  for (const anchor of [...candidates]) {
    if (!/^(?:chapter|lecture|part|appendix)\s+(?:\d+|[IVXLC]+|[A-Z])\b/i.test(String(anchor.title || '').trim())
        || Number(anchor.size) < bodySize * 1.45) continue;
    const pageLines = [...(pages[anchor.page - 1] || [])].filter((line) => Number(line.y) < Number(anchor.y)).sort((a, b) => Number(b.y) - Number(a.y));
    let tailY = Number(anchor.y);
    let tailSize = Number(anchor.size);
    for (const line of pageLines) {
      const gap = tailY - Number(line.y);
      if (gap <= 0) continue;
      if (gap > 86) break;
      const size = Number(line.size);
      if (!Number.isFinite(size) || size < Math.max(1, tailSize) * 0.92 || size > Math.max(1, tailSize) * 1.38) continue;
      // Old PDF character maps occasionally append a stray interpunct to
      // otherwise clear large-print part titles ("Minimal Surfaces.·").
      // Clean that residue ONLY after a verified chapter/part/appendix anchor.
      const text = normalizedHeadingText(line.text).replace(/[.·]\s*[·.]*\s*$/, '');
      const words = text.split(/\s+/).filter(Boolean);
      if (!text || words.length > 16 || headingNumberDepth(text) !== null || isMathEnvironmentLabel(text) || isLikelyFormulaHeading(text)) break;
      const existing = candidates.find((item) => item.page === anchor.page && normalizedHeadingText(item.title).toLocaleLowerCase() === text.toLocaleLowerCase());
      if (existing) existing.continuationOnly = true;
      else candidates.push({
        title: text, page: anchor.page, depth: anchor.depth, size: Number(size.toFixed(2)), y: line.y,
        ratio: Math.min(1, Math.max(0, (line.pageHeight - line.y) / Math.max(1, line.pageHeight))), continuationOnly: true,
      });
      tailY = Number(line.y);
      tailSize = size;
    }
  }

  // Multi-line large type titles in older books do not always begin with a
  // Chapter/Part token: e.g. "Approximation of Minimal" + "Sets (I)" and
  // "The a priori Estimate" + "for the Gradient". The continuation may have
  // only one substantive word, so it is not a standalone heading candidate.
  // Extend only an already accepted, oversized lexical book title; never
  // promote an orphan line or an equation using this reconstruction path.
  if (nativeBookTitleProfile) {
    for (const anchor of [...candidates]) {
      if (Number(anchor.size) < bodySize * 1.65 || !nativeStrongTitle(anchor.title)
          || /^(?:chapter|lecture|part|appendix)\b/i.test(anchor.title)) continue;
      let tailY = Number(anchor.y);
      let tailSize = Number(anchor.size);
      const pageLines = [...(pages[anchor.page - 1] || [])]
        .filter((line) => Number(line.y) < tailY)
        .sort((a, b) => Number(b.y) - Number(a.y));
      for (const line of pageLines) {
        const gap = tailY - Number(line.y);
        if (gap <= 0) continue;
        if (gap > 32) break;
        const text = normalizedHeadingText(line.text);
        const size = Number(line.size);
        const compact = text.replace(/\s/g, '');
        const letterCount = (text.match(/[A-Za-z]/g) || []).length;
        if (size < tailSize * 0.90 || size > tailSize * 1.12
            || Math.abs(Number(line.xStartRatio) - Number(anchor.xStartRatio)) > 0.075
            || !/^[A-Za-z]/.test(text) || letterCount < 4
            || letterCount / Math.max(1, compact.length) < 0.63
            || text.split(/\s+/).length > 10 || /[=+*<>~{}\[\]\\∫∑∏√∂∇∞]/u.test(text)
            || isMathEnvironmentLabel(text)
            || (isLikelyFormulaHeading(text) && !/^[A-Za-z]{3,}\s*\([IVX]+\)$/i.test(text))
            || numberedResultDeclarationInOutline(text) || headingNumberDepth(text) !== null
            || /[.!?]\s+[A-Z]/.test(text)) break;
        const existing = candidates.find((item) => item.page === anchor.page
          && normalizedHeadingText(item.title).toLocaleLowerCase() === text.toLocaleLowerCase());
        if (existing) existing.continuationOnly = true;
        else candidates.push({
          title: text, page: anchor.page, depth: anchor.depth, size: Number(size.toFixed(2)),
          y: line.y, xStartRatio: line.xStartRatio, xEndRatio: line.xEndRatio,
          ratio: Math.min(1, Math.max(0, (line.pageHeight - line.y) / Math.max(1, line.pageHeight))),
          continuationOnly: true,
        });
        tailY = Number(line.y);
        tailSize = size;
      }
    }
  }

// A native-text two-column journal page can have perfectly valid headings in
// both columns. Sorting all headings by page-y interleaves the two independent
// streams (2.3 before 2.1, etc.). Do not infer two columns merely because a
// heading is indented: require repeated BODY text confined to each half, with
// overlapping vertical spans and few full-width body lines.
function nativeOutlineTwoColumnPage(lines) {
  const usable = (lines || []).filter((row) => {
    const text = String(row?.text || '').trim();
    const start = Number(row?.xStartRatio), end = Number(row?.xEndRatio);
    return text.length >= 22 && Number.isFinite(start) && Number.isFinite(end)
      && end - start >= 0.13 && end - start <= 0.70;
  });
  const left = usable.filter((row) => Number(row.xStartRatio) <= 0.43 && Number(row.xEndRatio) <= 0.535);
  const right = usable.filter((row) => Number(row.xStartRatio) >= 0.49 && Number(row.xEndRatio) >= 0.65);
  const across = usable.filter((row) => Number(row.xStartRatio) < 0.43 && Number(row.xEndRatio) > 0.62);
  if (left.length < 7 || right.length < 7 || (left.length + right.length) < usable.length * 0.67
      || across.length > (left.length + right.length) * 0.30) return false;
  // Never spread an unbounded text-layer array into Math.min/Math.max:
  // scanned books can contain hundreds of thousands of glyph fragments.
  const bounds = (column) => {
    let min = Infinity, max = -Infinity, count = 0;
    for (const row of column) {
      const y = Number(row.y);
      if (!Number.isFinite(y)) continue;
      min = Math.min(min, y);
      max = Math.max(max, y);
      count++;
    }
    return {min, max, count};
  };
  const leftY = bounds(left), rightY = bounds(right);
  if (leftY.count < 7 || rightY.count < 7) return false;
  const commonSpan = Math.min(leftY.max, rightY.max)
    - Math.max(leftY.min, rightY.min);
  return commonSpan >= Number(lines[0]?.pageHeight || 700) * 0.22;
}

  const ocrSplitPages = new Set();
  if (documentOcrActive) {
    const pageCandidates = new Map();
    for (const candidate of candidates) {
      const list = pageCandidates.get(candidate.page) || [];
      list.push(candidate);
      pageCandidates.set(candidate.page, list);
    }
    for (const [pageNum, list] of pageCandidates) {
      const hasLeft = list.some((item) => Number(item.xStartRatio) < 0.44);
      const hasRight = list.some((item) => Number(item.xStartRatio) >= 0.52);
      if (hasLeft && hasRight) ocrSplitPages.add(pageNum);
    }
  }
  const nativeSplitPages = new Set();
  if (!documentOcrActive) for (let i = 0; i < pages.length; i += 1) {
    if (nativeOutlineTwoColumnPage(pages[i])) nativeSplitPages.add(i + 1);
  }
  const ordered = candidates.sort((a, b) => {
    if (a.page !== b.page) return a.page - b.page;
    if (ocrSplitPages.has(a.page) || nativeSplitPages.has(a.page)) {
      const aColumn = Number(a.xStartRatio) >= 0.49 ? 1 : 0;
      const bColumn = Number(b.xStartRatio) >= 0.49 ? 1 : 0;
      if (aColumn !== bColumn) return aColumn - bColumn;
    }
    return b.y - a.y || (Number(a.xStartRatio) || 0) - (Number(b.xStartRatio) || 0);
  });
  const merged = [];
  for (const candidate of ordered) {
    const previous = merged[merged.length - 1];
    const previousContainer = previous && /^(?:chapter|lecture|part|appendix)\s+(?:\d+|[IVXLC]+|[A-Z])\b/i.test(previous.title)
      && Number(previous.size) >= bodySize * 1.45;
    const tailY = Number(previous?._tailY ?? previous?.y);
    const tailSize = Number(previous?._tailSize ?? previous?.size);
    const verticalGap = tailY - Number(candidate.y);
    const numberedContinuation = previous && headingNumberDepth(previous.title) !== null
      && (Boolean(candidate.continuationOnly) || (Math.abs(tailSize - Number(candidate.size)) <= 0.85 && !isKnownHeading(candidate.title)));
    const containerContinuation = previousContainer
      && Number(candidate.size) >= Math.max(1, tailSize) * 0.90
      && Number(candidate.size) <= Math.max(1, tailSize) * 1.35;
    const bookTitleContinuation = nativeBookTitleProfile && previous && !previousContainer
      && Number(candidate.size) >= bodySize * 1.65
      && tailSize >= bodySize * 1.65
      && Number(candidate.size) >= tailSize * 0.90
      && Number(candidate.size) <= tailSize * 1.12
      && Math.abs(Number(candidate.xStartRatio) - Number(previous.xStartRatio)) <= 0.065
      && nativeStrongTitle(previous.title)
      && (Boolean(candidate.continuationOnly) || nativeStrongTitle(candidate.title) || /^(?:and|of|the|or|with)\s+[A-Za-z]/i.test(candidate.title));
    const inlineContainerContinuation = previousContainer && previous.page === candidate.page
      && Math.abs(verticalGap) <= 2
      && Number(candidate.xStartRatio) >= Number(previous.xEndRatio)
      && Number(candidate.xStartRatio) - Number(previous.xEndRatio) <= 0.10
      && Number(candidate.size) >= tailSize * 0.85
      && Number(candidate.size) <= tailSize * 1.20;
    const continuation = previous
      && previous.page === candidate.page
      && headingNumberDepth(candidate.title) === null
      && verticalGap > 0
      && verticalGap <= (previousContainer ? 82 : Math.max(32, tailSize * 2.1))
      && (!/[.!?]$/.test(previous.title) || /^appendix\s+[A-Z]\.$/i.test(previous.title))
      && (numberedContinuation || containerContinuation || bookTitleContinuation);
    const shouldMerge = continuation || inlineContainerContinuation;
    if (shouldMerge) {
      previous.title = normalizedHeadingText(`${previous.title.replace(/-$/, '')}${/-$/.test(previous.title) ? '' : ' '}${candidate.title}`);
      previous._tailY = candidate.y;
      previous._tailSize = candidate.size;
      continue;
    }
    merged.push({ ...candidate, _tailY: candidate.y, _tailSize: candidate.size });
  }

  const deduped = [];
  const seen = new Set();
  for (const candidate of merged) {
    const key = `${candidate.page}:${candidate.title.toLocaleLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(candidate);
  }
  const contentsPages = new Set();
  for (let pageIndex = 0; pageIndex < pages.length; pageIndex += 1) {
    if ((pages[pageIndex] || []).some((line) => contentsHeader(line?.text))) contentsPages.add(pageIndex + 1);
  }
  const cleaned = deduped.filter((candidate, index) => {
    if (!contentsPages.has(candidate.page)) return true;
    const key = normalizedHeadingText(candidate.title).toLocaleLowerCase();
    return !deduped.slice(index + 1).some((later) => later.page > candidate.page && (
      normalizedHeadingText(later.title).toLocaleLowerCase() === key
      || (/^appendix\s+[A-Z]$/i.test(candidate.title) && normalizedHeadingText(later.title).toLocaleLowerCase().startsWith(`${key}.`))
    ));
  });
  const seenTerminalHeadings = new Set();
  const finalCandidates = cleaned.filter((candidate) => {
    const terminal = /^(?:bibliography|references)$/i.test(String(candidate.title || '').trim());
    if (!terminal) return true;
    const key = String(candidate.title || '').trim().toLocaleLowerCase();
    if (seenTerminalHeadings.has(key)) return false;
    seenTerminalHeadings.add(key);
    return true;
  });
  // In old books the printed chapter number may occupy its own PDF.js text
  // run on the same baseline as the large title. Join only the measured marker
  // immediately to the left, without synthesizing any absent chapter number.
  if (nativeBookTitleProfile) {
    for (const candidate of finalCandidates) {
      if (Number(candidate.size) < bodySize * 1.65
          || headingNumberDepth(candidate.title) !== null || isKnownHeading(candidate.title)
          || /^(?:part|chapter|lecture|appendix)\b/i.test(candidate.title)) continue;
      const marker = (pages[candidate.page - 1] || []).find((line) => {
        const text = normalizedHeadingText(line.text);
        return /^\d{1,2}\.$/.test(text)
          && Math.abs(Number(line.y) - Number(candidate.y)) <= 2.4
          && Number(line.xEndRatio) <= Number(candidate.xStartRatio)
          && Number(candidate.xStartRatio) - Number(line.xEndRatio) < 0.12
          && Number(line.size) >= Number(candidate.size) * 0.85;
      });
      if (marker) candidate.title = normalizedHeadingText(`${normalizedHeadingText(marker.text)} ${candidate.title}`);
    }
  }
  // A page-top running head can repeat an actual front-matter title on the
  // very next page. Preserve the first heading, and reject only a measured,
  // substantially smaller adjacent echo (e.g. Foreword -> FOREWORD). Later
  // genuine sections with the same name and similarly sized typography stay.
  const headingsWithoutRunningEchoes = finalCandidates.filter((candidate, index) => {
    if (!isKnownHeading(candidate.title) || Number(candidate.ratio) > 0.16) return true;
    const key = normalizedHeadingText(candidate.title).toLocaleLowerCase();
    const preceding = finalCandidates.slice(0, index).reverse().find((earlier) =>
      normalizedHeadingText(earlier.title).toLocaleLowerCase() === key
      && earlier.page < candidate.page);
    if (!preceding || Number(candidate.page) - Number(preceding.page) !== 1) return true;
    if (Number(preceding.ratio) > 0.16) return true;
    return !(Number(candidate.size) > 0 && Number(preceding.size) > 0
      && Number(candidate.size) < Number(preceding.size) * 0.82);
  });
  return headingsWithoutRunningEchoes.slice(0, MAX_INFERRED_OUTLINE_ENTRIES).map(({ _tailY, _tailSize, ...candidate }) => candidate);
}

function positionOutlineEditActions(trigger, actions) {
  if (!trigger || !actions) return;
  const rect = trigger.getBoundingClientRect();
  const sidebar = trigger.closest('.sidebar') || trigger.closest('.sidebar-left');
  const sidebarRect = sidebar?.getBoundingClientRect?.();
  const gap = 10;
  const margin = 8;
  const width = Math.max(1, actions.offsetWidth);
  const height = Math.max(1, actions.offsetHeight);

  // Native scrollbars live outside the element's client box and can win hit testing
  // even when a fixed element is visually painted above them. Keep the action
  // surface strictly inside the sidebar client box so it never overlaps the
  // scrollbar track or thumb.
  const safeLeft = sidebarRect ? sidebarRect.left + margin : margin;
  const safeRight = sidebar
    ? sidebarRect.left + Math.max(1, sidebar.clientWidth) - margin
    : window.innerWidth - margin;

  let left = rect.right + gap;
  if (left + width > safeRight) left = rect.left - gap - width;
  left = Math.max(safeLeft, Math.min(left, safeRight - width));

  const safeTop = sidebarRect ? sidebarRect.top + margin : margin;
  const safeBottom = sidebarRect ? sidebarRect.bottom - margin : window.innerHeight - margin;
  let top = rect.top + (rect.height - height) / 2;
  top = Math.max(safeTop, Math.min(top, safeBottom - height));

  actions.style.left = `${Math.round(left)}px`;
  actions.style.top = `${Math.round(top)}px`;
}

function embeddedOutlineSourceKey(entry) {
  return String(entry?.sourceKey || '').trim();
}

function applyEmbeddedOutlineEdits(entries) {
  const edits = new Map(embeddedOutlineEdits.map((item) => [String(item.sourceKey), item]));
  const out = [];
  for (const entry of entries || []) {
    const key = embeddedOutlineSourceKey(entry);
    const edit = edits.get(key);
    if (edit?.action === 'remove') continue;
    if (edit?.action === 'reselect') {
      out.push({
        ...entry,
        title: String(edit.title || entry.title),
        matchText: String(edit.matchText || edit.title || entry.title),
        page: Number(edit.page) || entry.page,
        ratio: Number(edit.ratio) || 0,
        positionKnown: true,
        userEdited: true,
      });
    } else out.push(entry);
  }
  return out;
}

// Manual Structure entries and detector results share persistence, but a new
// detector must never erase a reader-selected passage or overflow it off the
// index. Keep the user-authored entries when applying the bounded row limit.
function boundedOutlineWithManualPriority(entries) {
  const sorted = (Array.isArray(entries) ? entries : []).slice().sort((a, b) =>
    Number(a.page) - Number(b.page) || Number(a.ratio) - Number(b.ratio));
  if (sorted.length <= MAX_INFERRED_OUTLINE_ENTRIES) return sorted;
  const autoLimit = Math.max(0, MAX_INFERRED_OUTLINE_ENTRIES - sorted.filter((entry) => entry.userEdited === true).length);
  let autoKept = 0;
  return sorted.filter((entry) => entry.userEdited === true || autoKept++ < autoLimit)
    .slice(0, MAX_INFERRED_OUTLINE_ENTRIES);
}

function mergeDetectedAndManualOutline(detected, existing = inferredOutline) {
  const manual = (existing || []).filter((entry) => entry?.userEdited === true);
  const manualKeys = new Set(manual.map((entry) => outlineEntryKey(entry)));
  const automatic = (Array.isArray(detected) ? detected : []).filter((entry) =>
    entry && entry.userEdited !== true && !manualKeys.has(outlineEntryKey(entry)));
  return boundedOutlineWithManualPriority([...automatic, ...manual]);
}

// Preserve the PDF's native bookmark order and depth. Insert manual items at
// their page positions without sorting or rewriting the embedded tree.
function interleaveEmbeddedAndManualOutline(embedded, manual) {
  const combined = (embedded || []).slice();
  const additions = (manual || []).filter((entry) => entry?.userEdited === true)
    .slice().sort((a, b) => Number(a.page) - Number(b.page) || Number(a.ratio) - Number(b.ratio));
  for (const added of additions) {
    const next = combined.findIndex((entry) => Number(entry.page) > Number(added.page)
      || (Number(entry.page) === Number(added.page) && Number(entry.ratio || 0) > Number(added.ratio || 0)));
    if (next < 0) combined.push(added);
    else combined.splice(next, 0, added);
  }
  return combined;
}

// Some embedded bookmarks specify only a page (Fit/FitB/XYZ with null top),
// so a page-top jump is the only *literal* PDF destination available. When
// the actual heading is unambiguous in that page's existing text layer, use
// its measured y instead. Never replace an explicit PDF destination, a
// manually chosen position, or a merely similar prose/reference line.
function comparableStructureNavigationText(value) {
  return String(value || '').normalize('NFKC').toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ').replace(/\s+/g, ' ').trim();
}

// PDF.js can merge text from the left and right columns into a single
// baseline row. Match a bookmark against column-local text, not a row that
// starts with a true heading but ends with unrelated text from the other
// column. The pageTextLines() parts retain their actual x positions, even
// when the row's .text has already been joined across columns.
function structureHeadingRowSegments(line) {
  const text = String(line?.text || '');
  const parts = Array.isArray(line?.parts) ? line.parts : [];
  const ratio = Number(line?.ratio);
  const fallback = [{ text, ratio, xStartRatio: Number(line?.xStartRatio), xEndRatio: Number(line?.xEndRatio) }];
  if (parts.length < 2) return fallback;
  if (parts.some((part) => !Number.isInteger(part.start) || !Number.isInteger(part.end)
      || part.end <= part.start || part.start < 0 || part.end > text.length
      || part.xStartRatio === null || part.xStartRatio === undefined || part.xStartRatio === ''
      || part.xEndRatio === null || part.xEndRatio === undefined || part.xEndRatio === ''
      || !Number.isFinite(Number(part.xStartRatio)) || !Number.isFinite(Number(part.xEndRatio))
      || Number(part.xEndRatio) < Number(part.xStartRatio))) return fallback;
  // The geometry and source-text offsets must advance together. Malformed
  // or overlapping part ranges otherwise fabricate a different heading when
  // reconstructing two-column lines from imported / OCR text.
  for (let i = 1; i < parts.length; i++) {
    if (parts[i].start < parts[i - 1].end
        || Number(parts[i].xStartRatio) < Number(parts[i - 1].xStartRatio)) return fallback;
  }
  const fragments = [];
  let current = '';
  let start = null;
  let previousEnd = null;
  const flush = () => {
    if (current) fragments.push({text: current, ratio, xStartRatio: start, xEndRatio: previousEnd});
    current = '';
    start = null;
  };
  for (const part of parts) {
    const startX = Number(part.xStartRatio);
    const endX = Number(part.xEndRatio);
    const gap = previousEnd === null ? 0 : startX - previousEnd;
    const crossesGutter = previousEnd !== null && previousEnd <= 0.49
      && startX >= 0.51 && gap >= 0.025;
    const broadGap = previousEnd !== null && gap >= 0.11;
    if (current && (crossesGutter || broadGap)) flush();
    const value = text.slice(part.start, part.end).trim();
    if (value) {
      if (start === null) start = startX;
      current = current ? `${current} ${value}` : value;
    }
    previousEnd = endX;
  }
  flush();
  return fragments.length ? fragments : fallback;
}

function structureHeadingRowFragments(line) {
  return structureHeadingRowSegments(line).map((part) => part.text);
}

// Mathematical PDF fonts routinely split A_0 into "𝑨 0" or serialize
// subscripted expressions without the punctuation present in PDF bookmarks.
// Use a whitespace/punctuation-free comparison only when the entire heading
// is otherwise present; never use a substring search through body prose.
function compactStructureNavigationText(value) {
  return String(value || '').normalize('NFKC').toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '');
}

function structureHeadingMatchQuality(candidate, wanted, wantedCompact) {
  const actual = comparableStructureNavigationText(candidate);
  // PDF bookmark titles often omit the printed section number, e.g.
  // "Norms and three basic inequalities" vs "2.1 Norms and three basic
  // inequalities". Strip only a LEADING hierarchical section identifier,
  // never arbitrary words or trailing TOC page numbers.
  const numbered = actual.match(/^(?:\d+(?: \d+)*[a-z]?|[ivxlcdm]+) (.+)$/u);
  if (numbered && numbered[1] === wanted) return 98;
  if (!actual) return 0;
  if (actual === wanted) return 100;
  // An optional parenthetical subtitle or a small PDF extraction omission
  // must not turn a heading into a page-top-only bookmark.
  if (wanted.length >= 12 && actual.length >= 10
      && actual.startsWith(`${wanted} `) && actual.length <= wanted.length * 1.25) return 85;
  if (wanted.length >= 12 && actual.length >= wanted.length * 0.70
      && wanted.startsWith(`${actual} `)) return 75;
  const compact = compactStructureNavigationText(candidate);
  if (wantedCompact.length < 7 || compact.length < 7) return 0;
  if (compact === wantedCompact) return 95;
  // A single trailing math variable can be a subscript in the print, but a
  // full extra prose word (or an equation/reference paragraph) cannot.
  const excess = compact.length - wantedCompact.length;
  if (compact.startsWith(wantedCompact) && excess > 0 && excess <= 2) return 82;
  return 0;
}

function structureSameColumnContinuation(first, next) {
  const x = Number(first?.xStartRatio);
  const nx = Number(next?.xStartRatio);
  const xe = Number(first?.xEndRatio);
  const ne = Number(next?.xEndRatio);
  if (![x, nx, xe, ne].every(Number.isFinite)) return false;
  // In two-column layouts never merge a heading with text from the other
  // column, even if both share consecutive baselines.
  if ((x < 0.49 && nx > 0.51) || (x > 0.51 && nx < 0.49)) return false;
  if (Math.abs(x - nx) > 0.17) return false;
  return Math.min(xe, ne) - Math.max(x, nx) >= -0.008;
}

function uniqueStructureHeadingRatio(lines, title) {
  const wanted = comparableStructureNavigationText(title);
  const wantedCompact = compactStructureNavigationText(title);
  if (wanted.length < 6) return null;
  const fragments = [];
  for (const line of lines || []) {
    if (line?.ratio === null || line?.ratio === undefined || line?.ratio === '') continue;
    const ratio = Number(line.ratio);
    if (!Number.isFinite(ratio) || ratio < 0 || ratio > 1) continue;
    fragments.push(...structureHeadingRowSegments(line).filter((part) => part.text));
  }
  fragments.sort((a, b) => a.ratio - b.ratio || a.xStartRatio - b.xStartRatio);
  const matches = new Map();
  for (let i = 0; i < fragments.length; i++) {
    const anchor = fragments[i];
    const ratio = anchor.ratio;
    let quality = structureHeadingMatchQuality(anchor.text, wanted, wantedCompact);
    let candidate = anchor.text;
    let cursor = anchor;
    // A chapter heading may wrap over several baselines. Build candidate
    // strings from the *same column*, retaining the first baseline's Y.
    // Bound the search to a few following rows, not arbitrary nearby prose.
    let joined = 0;
    for (let j = i + 1; j < fragments.length && joined < 3; j++) {
      const following = fragments[j];
      const verticalGap = following.ratio - cursor.ratio;
      if (following.ratio - ratio > 0.075) break;
      if (verticalGap < 0.003) continue;  // simultaneous other-column row
      if (verticalGap > 0.032) break;
      if (!structureSameColumnContinuation(anchor, following)) continue;
      candidate += ` ${following.text}`;
      quality = Math.max(quality, structureHeadingMatchQuality(candidate, wanted, wantedCompact));
      cursor = following;
      joined++;
    }
    if (!quality) continue;
    // Multiple readings of the same printed baseline are one candidate;
    // distinct Y coordinates remain ambiguous and cannot be guessed.
    const key = Math.round(ratio * 10000);
    matches.set(key, Math.max(matches.get(key) || 0, quality));
  }
  if (!matches.size) return null;
  const ranked = [...matches.entries()].sort((a, b) => b[1] - a[1]);
  // Prefer one exact heading over a different, weaker partial match. If two
  // printed occurrences have comparable evidence, keep the PDF destination.
  if (ranked.length > 1 && ranked[0][1] - ranked[1][1] < 16) return null;
  return ranked[0][0] / 10000;
}

// The existing typography detector already has precise, measured y values.
// They are a second independent source for bookmarks when native line
// reconstruction is unavailable (e.g. an OCR-backed Structure index). Do not
// borrow a vaguely similar title, a different page, or a manual selection.
function uniqueDetectedStructureHeadingRatio(entry) {
  const entries = typeof inferredOutline === 'undefined' ? [] : inferredOutline;
  if (!Array.isArray(entries)) return null;
  const title = comparableStructureNavigationText(entry?.matchText || entry?.title);
  const page = Number(entry?.page);
  if (title.length < 6 || !Number.isInteger(page)) return null;
  const matches = entries.filter((item) => item?.userEdited !== true
    && Number(item?.page) === page
    && comparableStructureNavigationText(item.title) === title
    // Null/empty OCR geometry is missing evidence, not a measured page-top.
    && item.ratio !== null && item.ratio !== undefined && item.ratio !== ''
    && Number.isFinite(Number(item.ratio)) && Number(item.ratio) >= 0 && Number(item.ratio) <= 1);
  return matches.length === 1 ? Number(matches[0].ratio) : null;
}

// Recover the printed heading location from MathReader's already-reviewed
// typography index before trusting a PDF bookmark. Some generators give every
// chapter bookmark the same (72, 36) page-margin destination. Matching a
// unique numbered detector heading also supports bookmarks that omit the
// printed section number; manual and genuinely precise destinations are not
// rewritten. Never borrow a nearby prose occurrence or another page.
function detectedStructureBookmarkRatio(entry) {
  const page = Number(entry?.page);
  const wanted = comparableStructureNavigationText(entry?.matchText || entry?.title);
  const compact = compactStructureNavigationText(entry?.matchText || entry?.title);
  if (!Number.isInteger(page) || wanted.length < 6 || typeof inferredOutline === 'undefined' || !Array.isArray(inferredOutline)) return null;
  const candidates = inferredOutline.filter((item) => item?.userEdited !== true
    && Number(item.page) === page && item.ratio !== null && item.ratio !== undefined
    && Number.isFinite(Number(item.ratio)) && Number(item.ratio) >= 0 && Number(item.ratio) <= 1
    && structureHeadingMatchQuality(item.title, wanted, compact) >= 95);
  return candidates.length === 1 ? Number(candidates[0].ratio) : null;
}

// A heading's final on-screen geometry is the authoritative navigation target.
// PDF bookmarks, cached OCR coordinates and PDF.js line reconstruction are
// useful candidates, but they can disagree with the *rendered* text layer.
// Re-measure its visible text spans after the destination page finishes painting.
function renderedStructureHeadingRatio(page, title) {
  const surface = readingFlow === 'continuous'
    ? continuousPageNodes.get(Number(page))?.surface
    : (Number(page) === Number(currentPage) ? primaryPageSurface : null);
  const layer = readingFlow === 'continuous'
    ? continuousPageNodes.get(Number(page))?.textLayer
    : (Number(page) === Number(currentPage) ? primaryTextLayer : null);
  if (!surface || !layer) return null;
  const bounds = surface.getBoundingClientRect();
  if (!(bounds.height > 0) || !(bounds.width > 0)) return null;
  const rows = new Map();
  for (const span of layer.querySelectorAll('span')) {
    const value = String(span.textContent || '').trim();
    if (!value) continue;
    const rect = span.getBoundingClientRect();
    if (!(rect.width > 0) || !(rect.height > 0)) continue;
    const ratio = (rect.top - bounds.top) / bounds.height;
    const x = (rect.left - bounds.left) / bounds.width;
    if (![ratio, x].every(Number.isFinite) || ratio < -0.02 || ratio > 1.02) continue;
    const key = Math.round(ratio * bounds.height / 3);
    if (!rows.has(key)) rows.set(key, []);
    rows.get(key).push({ text: value, ratio: Math.max(0, Math.min(1, ratio)), x });
  }
  const lines = [...rows.values()].map((items) => {
    items.sort((a, b) => a.x - b.x);
    const last = items[items.length - 1];
    return { text: items.map((item) => item.text).join(' '), ratio: items[0].ratio,
      xStartRatio: items[0].x, xEndRatio: (last.x + 0.002) };
  });
  return uniqueStructureHeadingRatio(lines, title);
}

async function alignStructureToRenderedHeading(page, title, stillCurrent) {
  if (!stillCurrent()) return false;
  // The page's native PDF text layer is asynchronously painted, and a
  // continuous-page lazy renderer may complete on a later frame.
  for (let attempt = 0; attempt < 3; attempt++) {
    await nextFrame();
    if (!stillCurrent()) return false;
    const ratio = renderedStructureHeadingRatio(page, title);
    if (ratio === null) continue;
    const lead = navigationTargetLeadPx();
    ensureReaderPositionScrollRange(page, ratio, lead);
    alignReaderNavigationToSurface(page, ratio, lead);
    await nextFrame();
    if (!stillCurrent()) return false;
    alignReaderNavigationToSurface(page, ratio, lead);
    if (readingFlow === 'continuous') continuousSavedAnchor = { page, ratio };
    scrollByPage[String(page)] = { top: primaryCanvasWrap.scrollTop, left: primaryCanvasWrap.scrollLeft };
    persistDocumentState();
    return true;
  }
  return false;
}

let structureNavigationSerial = 0;

async function navigateToStructureEntry(entry) {
  if (!pdfDoc || !entry) return;
  const requestSerial = ++structureNavigationSerial;
  const readerSerial = readerNavigationSerial;
  const sourceDoc = pdfDoc;
  const sourceKey = currentFileKey;
  const stillCurrent = () => requestSerial === structureNavigationSerial
    && readerSerial === readerNavigationSerial
    && pdfDoc === sourceDoc && currentFileKey === sourceKey;
  const stillLanding = () => requestSerial === structureNavigationSerial
    && readerNavigationSerial === readerSerial + 1
    && pdfDoc === sourceDoc && currentFileKey === sourceKey;
  // Missing, out-of-range, and non-finite bookmark positions are not
  // authoritative coordinates. In particular, Number(null) === 0 must not
  // turn a missing bookmark destination into a deliberate page-top target.
  const rawPage = Number(entry.page);
  const page = Number.isInteger(rawPage) ? Math.min(Math.max(1, rawPage), pdfDoc.numPages) : 1;
  const hasPosition = entry.ratio !== null && entry.ratio !== undefined && entry.ratio !== ''
    && Number.isFinite(Number(entry.ratio)) && Number(entry.ratio) >= 0 && Number(entry.ratio) <= 1;
  let ratio = hasPosition ? Number(entry.ratio) : 0;
  // Many PDF generators give EVERY bookmark on a page an identical XYZ
  // destination at the upper text margin (e.g. 36 pt), not y=0. Treat such
  // near-top locations as coarse candidates rather than authoritative heading
  // positions. Only replace them with an independently matched, unique title;
  // retain manual selections and precise destinations farther down the page.
  const needsRecovery = entry.userEdited !== true
    && (!hasPosition || entry.positionKnown !== true || ratio <= 0.12 || entry.coarseDestination === true);
  let headingRecovered = false;
  if (needsRecovery) {
    // An existing detector anchor is direct page geometry, whereas the
    // embedded PDF bookmark may encode only the page's upper text margin.
    const indexed = detectedStructureBookmarkRatio(entry);
    if (indexed !== null) {
      ratio = indexed;
      headingRecovered = true;
    }
    // Do not re-extract the whole page on every click when a unique, measured
    // heading is already in the detector index. The rendered-text-layer pass
    // below still corrects the final on-screen geometry after painting.
    if (!headingRecovered) {
      try {
        const lines = await pageTextLines(page);
        // A different PDF must never receive an async position resolved for the
        // previous document, even if both happen to have the same page count.
        if (!stillCurrent()) return;
        const recovered = uniqueStructureHeadingRatio(lines, entry.matchText || entry.title);
        if (recovered !== null) {
          ratio = recovered;
          headingRecovered = true;
        }
      } catch (error) {
        if (!stillCurrent()) return;
        console.warn('Structure heading position unavailable', error);
      }
    }
  }
  if (!stillCurrent()) return;
  if (needsRecovery && !headingRecovered) {
    const detected = uniqueDetectedStructureHeadingRatio(entry);
    if (detected !== null) ratio = detected;
  }
  await goToMatchedLocation(page, ratio, '', { positionOnly: true });
  if (!stillLanding()) return;
  // A rendered title beats a generic bookmark destination. The older
  // navigation path could calculate the right ratio, yet still leave users
  // at the page top when PDF.js painted/adjusted the layout afterwards.
  // Preserve author-selected coordinates; never guess at an unmatched title.
  if (needsRecovery) {
    await alignStructureToRenderedHeading(page, entry.matchText || entry.title, stillLanding);
  }
}

function renderActiveOutline() {
  if (outlineMode === 'embedded') renderEmbeddedOutline(embeddedOutlineEntries);
  else renderInferredOutline(inferredOutline);
}

function renderEmbeddedOutline(entries) {
  outlineList.replaceChildren();
  const visible = interleaveEmbeddedAndManualOutline(applyEmbeddedOutlineEdits(entries), inferredOutline);
  outlineMode = 'embedded';
  updateOutlineSource();
  outlineCount.textContent = String(visible.length);
  outlineEmpty.classList.toggle('is-hidden', visible.length > 0);
  for (const entry of visible) {
    if (entry.userEdited === true && !entry.sourceKey) {
      appendInferredOutlineRow(entry);
      continue;
    }
    const row = document.createElement('div');
    row.className = 'outline-edit-row';
    row.dataset.mapFilterText = entry.title;
    row.dataset.depth = String(Math.min(3, Math.max(0, Number(entry.depth) || 0)));
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'outline-item';
    button.dataset.depth = row.dataset.depth;
    button.dataset.page = String(entry.page);
    button.textContent = entry.title || t('Untitled', '未命名');
    button.title = t(`PDF outline · page ${entry.page}`, `PDF 目录 · 第 ${entry.page} 页`);
    button.addEventListener('click', async () => {
      outlineList.querySelectorAll('.outline-edit-row.has-edit-menu').forEach((node) => node.classList.remove('has-edit-menu'));
      setDocumentMapSelectedNode(button);
      await navigateToStructureEntry(entry);
    });

    const menu = document.createElement('button');
    menu.type = 'button';
    menu.className = 'outline-overflow-button';
    menu.textContent = '⋯';
    menu.title = t('Edit structure item', '编辑结构条目');
    menu.setAttribute('aria-label', menu.title);
    menu.setAttribute('aria-expanded', 'false');

    const actions = document.createElement('div');
    actions.className = 'outline-edit-actions';
    const reselect = document.createElement('button');
    reselect.type = 'button';
    reselect.className = 'outline-edit-button';
    reselect.textContent = t('Reselect', '重新选择');
    reselect.addEventListener('click', (event) => {
      event.preventDefault(); event.stopPropagation();
      row.classList.remove('has-edit-menu');
      pendingOutlineReselectKey = `embedded:${entry.sourceKey}`;
      refreshSelectionUI();
    });
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'outline-edit-button';
    remove.textContent = t('Remove', '移除');
    remove.addEventListener('click', (event) => {
      event.preventDefault(); event.stopPropagation();
      row.classList.remove('has-edit-menu');
      pushUndo('structure-embedded', entry.title || t('Structure item','结构条目'), {
        sourceKey: String(entry.sourceKey),
        title: String(entry.title || ''),
        page: Number(entry.page) || 1,
        ratio: Number(entry.ratio) || 0,
        depth: Math.min(3, Math.max(0, Number(entry.depth) || 0)),
        matchText: String(entry.matchText || entry.title || '')
      });
      embeddedOutlineEdits = embeddedOutlineEdits.filter((item) => String(item.sourceKey) !== String(entry.sourceKey));
      embeddedOutlineEdits.push({ action:'remove', sourceKey:String(entry.sourceKey) });
      if (pendingOutlineReselectKey === `embedded:${entry.sourceKey}`) pendingOutlineReselectKey = null;
      persistDocumentState();
      renderEmbeddedOutline(embeddedOutlineEntries);
      rerenderReferenceLinksAfterStructureEdit();
      refreshSelectionUI();
    });
    actions.append(reselect, remove);
    menu.addEventListener('click', (event) => {
      event.preventDefault(); event.stopPropagation();
      const willOpen = !row.classList.contains('has-edit-menu');
      outlineList.querySelectorAll('.outline-edit-row.has-edit-menu').forEach((node) => {
        node.classList.remove('has-edit-menu');
        node.querySelector('.outline-overflow-button')?.setAttribute('aria-expanded', 'false');
      });
      row.classList.toggle('has-edit-menu', willOpen);
      menu.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      if (willOpen) requestAnimationFrame(() => positionOutlineEditActions(menu, actions));
    });
    row.append(button, menu, actions);
    outlineList.append(row);
  }
  applyDocumentMapFilter(el('map-filter-structure')); updateDocumentMapCurrentLocation();
}

function renderInferredOutline(entries) {
  outlineList.replaceChildren();
  outlineCount.textContent = String(entries.length);
  outlineEmpty.classList.toggle('is-hidden', entries.length > 0);
  if (!entries.length) {
    outlineMode = 'none';
    updateOutlineSource();
    outlineEmpty.textContent = t('No reliable document headings were detected.', '未检测到足够可靠的文档标题。');
    return;
  }
  outlineMode = 'inferred';
  updateOutlineSource();
  for (const entry of entries) appendInferredOutlineRow(entry);
  applyDocumentMapFilter(el('map-filter-structure')); updateDocumentMapCurrentLocation();
}

function appendInferredOutlineRow(entry) {
    const row = document.createElement('div');
    row.className = 'outline-edit-row';
    row.dataset.mapFilterText = entry.title;
    row.dataset.depth = String(Math.min(3, Math.max(0, Number(entry.depth) || 0)));
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'outline-item';
    button.dataset.depth = row.dataset.depth;
    button.dataset.page = String(entry.page);
    button.textContent = entry.title;
    button.title = entry.userEdited === true
      ? t(`Manual Structure · page ${entry.page}`, `手动结构条目 · 第 ${entry.page} 页`)
      : t(`Detected heading · page ${entry.page}`, `自动检测标题 · 第 ${entry.page} 页`);
    button.addEventListener('click', () => {
      outlineList.querySelectorAll('.outline-edit-row.has-edit-menu').forEach((node) => node.classList.remove('has-edit-menu'));
      setDocumentMapSelectedNode(button);
      navigateToStructureEntry(entry);
    });
    const menu = document.createElement('button');
    menu.type = 'button';
    menu.className = 'outline-overflow-button';
    menu.textContent = '⋯';
    menu.title = t('Edit structure item', '编辑结构条目');
    menu.setAttribute('aria-label', menu.title);
    menu.setAttribute('aria-expanded', 'false');
    menu.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const willOpen = !row.classList.contains('has-edit-menu');
      outlineList.querySelectorAll('.outline-edit-row.has-edit-menu').forEach((node) => {
        node.classList.remove('has-edit-menu');
        node.querySelector('.outline-overflow-button')?.setAttribute('aria-expanded', 'false');
      });
      row.classList.toggle('has-edit-menu', willOpen);
      menu.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      if (willOpen) requestAnimationFrame(() => positionOutlineEditActions(menu, actions));
    });

    const actions = document.createElement('div');
    actions.className = 'outline-edit-actions';
    if (entry.userEdited) {
      const currentDepth = Math.min(3, Math.max(0, Number(entry.depth) || 0));
      if (currentDepth > 0) {
        const moveLeft = document.createElement('button');
        moveLeft.type = 'button';
        moveLeft.className = 'outline-edit-button';
        moveLeft.textContent = '←';
        moveLeft.title = t('Move left one level', '向左移一级');
        moveLeft.setAttribute('aria-label', moveLeft.title);
        moveLeft.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          entry.depth = currentDepth - 1;
          row.classList.remove('has-edit-menu');
          persistDocumentState();
          renderActiveOutline();
        });
        actions.append(moveLeft);
      }
      if (currentDepth < 3) {
        const moveRight = document.createElement('button');
        moveRight.type = 'button';
        moveRight.className = 'outline-edit-button';
        moveRight.textContent = '→';
        moveRight.title = t('Move right one level', '向右移一级');
        moveRight.setAttribute('aria-label', moveRight.title);
        moveRight.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          entry.depth = currentDepth + 1;
          row.classList.remove('has-edit-menu');
          persistDocumentState();
          renderActiveOutline();
        });
        actions.append(moveRight);
      }
    }
    const reselect = document.createElement('button');
    reselect.type = 'button';
    reselect.className = 'outline-edit-button';
    reselect.textContent = t('Reselect', '重新选择');
    reselect.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      row.classList.remove('has-edit-menu');
      pendingOutlineReselectKey = outlineEntryKey(entry);
      refreshSelectionUI();
    });
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'outline-edit-button';
    remove.textContent = t('Remove', '移除');
    remove.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      row.classList.remove('has-edit-menu');
      const key = outlineEntryKey(entry);
      if (pendingOutlineReselectKey === key) pendingOutlineReselectKey = null;
      pushUndo('structure-outline', entry.title || t('Structure item','结构条目'), entry);
      inferredOutline = inferredOutline.filter((item) => outlineEntryKey(item) !== key);
      tocOutlineTargets = null;
      persistDocumentState();
      renderActiveOutline();
      rerenderReferenceLinksAfterStructureEdit();
      refreshSelectionUI();
    });
    actions.append(reselect, remove);
    row.append(button, menu, actions);
    outlineList.append(row);
}

document.addEventListener('click', (event) => {
  if (event.target.closest?.('.outline-edit-actions, .outline-overflow-button')) return;
  document.querySelectorAll('#outline-list .outline-edit-row.has-edit-menu, #equation-index .equation-edit-row.has-edit-menu').forEach((node) => {
    node.classList.remove('has-edit-menu');
    node.querySelector('.outline-overflow-button')?.setAttribute('aria-expanded', 'false');
  });
});

const STRUCTURE_REFERENCE_RE = /\b(?:Theorem|Lemma|Proposition|Corollary|Definition|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis)\s+(?:[A-Z]{1,2}[.·-][0-9lIO]+(?:[.·-][0-9lIO]+)*|[A-Z]?\d+(?:(?:\s*[.·]\s*\d+)+|(?:\s*[-–—]\s*\d+)+)?(?:['’])?|[A-Z])\b/gi;
const EQUATION_TAG_SYMBOL_CLASS = '*∗⋆★☆†‡※◇◆○●◦•△▲▽▼□■♢♦⊙⊗⊕⊖⊥∥';
const EQUATION_TAG_SYMBOL_PATTERN = `[${EQUATION_TAG_SYMBOL_CLASS.replace(/[\]\-^]/g, '\\$&')}]`;
const CLICKABLE_REFERENCE_RE = new RegExp(
  `\\b(?:Theorem|Lemma|Proposition|Corollary|Definition|Remark|Example|Claim|Conjecture|Question|Assumption|Hypothesis|Section)\\s+[A-Z]?\\d+(?:\\.\\d+)*\\b|` +
  `\\(\\s*(?:\\d+(?:(?:\\.\\d+)+|(?:-\\d+)+)?|${EQUATION_TAG_SYMBOL_PATTERN}(?:\\s*${EQUATION_TAG_SYMBOL_PATTERN}){0,7})\\s*\\)|` +
  `\\[\\s*\\d{1,3}\\s*\\]`,
  'gi',
);
const GROUPED_BIBLIOGRAPHY_RE = /\[\s*\d{1,3}(?:\s*(?:,|;|[-–—])\s*\d{1,3})+\s*\]/g;

