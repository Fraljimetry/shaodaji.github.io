# Standing rule — look for subtle defects in every bug fix and regression

**Mandatory for every MathReader code change, bug fix, and regression sweep.** Do not stop when the reported symptom disappears or the happy-path test passes. Deliberately search for **subtle, second-order, easily missed failures** in the *affected code paths and their neighbors*, including defects introduced by the proposed fix. Apply this requirement to UI, Settings, PDF reading, Content Detection, Formula OCR, storage, and import/export alike. It is a **permanent development and release gate**, not an optional audit performed only when requested.

### Required adversarial review (risk-based, not a claim to test every possible input)

Before declaring the change complete, explicitly consider the applicable cases below:

- **Transitions and time:** rapid/repeated clicks, reentrancy, overlapping renders/jobs, cancellation, out-of-order Promise completion, stale work after PDF switch, import, reset, navigation or unmount, and controls left busy/active.
- **State and persistence:** defaults, missing/`null`/corrupted/out-of-range saved values, failed or partial storage writes, multiple tabs, lost updates, cache/index invalidation, reload/reopen, and preservation of user edits.
- **Failure and rollback:** exceptions, rejection/timeout, model or PDF extraction failure, partial results, disposal errors, interrupted cleanup, error visibility, and restoration of a usable consistent UI. Never present fallback, skipped work, or stale results as success.
- **Interactions and boundaries:** neighboring settings or features, mode changes during layout updates, responsive widths and both languages, zero/large/malformed inputs, single-/multi-column geometries, equation positions, text selection, and import/export schema compatibility.
- **Evidence integrity:** distinguish source-level assertions, mocks, simulated events, original-PDF text replay, real PDF.js/Chromium navigation, and genuine model inference. A passing test is evidence only for the path actually exercised; a timeout, skipped case, or absent dependency is **not PASS**.

### Required fix-and-regression workflow

1. **Inspect the current real source and latest applied overlay**; name the failed invariant, not only the visible symptom. Identify which subtle-case categories above apply and why.
2. **Attempt to break the proposed fix:** exercise at least one relevant adversarial or negative path whenever a stateful/runtime path is affected, especially delayed completions and failure cleanup. Check that the fix cannot overwrite newer state or regress a neighboring feature.
3. **Reproduce confirmed defects first** using the closest faithful test available. Add a targeted regression that fails on the unmodified baseline and passes after the fix whenever feasible. Include success, failure, and cleanup/rollback assertions where applicable.
4. **Keep corrections general and small.** No document-specific exceptions, silent fallbacks, swallowed errors, or misleading quality/success states. Re-run affected tests, broad regressions, syntax checks, and clean-overlay verification; retain genuine failures/timeouts in the report.
5. **Report explicitly:** (a) the reported symptom and root cause, (b) subtle cases actively checked and any additional defects found, (c) exact passing/failing/skipped test counts and test provenance, (d) known unverified or accepted risks, and (e) changed files. If a high-risk category could not be tested, mark it **UNVERIFIED**, never implicitly covered.

A documentation-only edit needs documentation/overlay integrity checks rather than fictitious runtime acceptance. This rule remains in force for every future release; do not delete it when older version-specific records are archived.

---

# v436 — Cross-tab Settings consistency and same-mode Reset failures (2026-11-11)

Starting from v435, fixed stale Settings state in multiple tabs and a race where a pending reading-mode transition could overwrite another tab's newer appearance changes. The previously unguarded same-mode Reset Display PDF refresh now reports failures, releases controls, and rejects stale completions. Invalid/missing Display preferences reset every field. OCR engine/extraction method changes from another tab require an explicit reload instead of an unsafe live model switch. **96/96** Settings Chromium assertions, **19/19** two-page simulated storage-event assertions, **80/80** JavaScript test files and **39/39** Python test files PASS (36 bounded + 3 isolated). Syntax/assembly gates pass; actual shared-origin browser storage transport, original-PDF acceptance and real Texify inference are **not verified**. [Full v436 report](docs/releases/V436_RELEASE.md).

---

# v435 — Subtle Settings races, corrupted preferences and explicit OCR mode boundaries (2026-11-11)

Starting from v434, addressed reading-flow/reflow collisions, safe mode rollback on render failure, stale PDF completion, malformed numeric preferences, PDF-vector fallback to image inference, OCR engine unload errors/overlap, and busy-control release. Existing Settings, Content Detection, Formula OCR and bilingual Tutorial behavior remain covered. **90/90** Settings Chromium assertions, **80/80** JavaScript test files and **38/38** Python test files PASS in bounded/isolated runs; the original combined Python runner stalled and was not counted as a pass. JavaScript modules/bootstrap/concatenated runtime syntax PASS. Real original-PDF page geometry and genuine Texify inference **not verified**. [Full report](docs/releases/V435_RELEASE.md); [gate](regression/v435_release_gate.json).

---

# v434 — Comprehensive Settings controls and lifecycle sweep (2026-11-11)

Audited all 22 Settings controls/actions in v433 against production preferences and handlers. Fixed Reset display's single-to-continuous transition bypass, silent WebGPU-to-CPU model fallback, busy-state availability for Content Detection rebuild/scan actions, and silent Settings persistence failures when localStorage writes are blocked. New bilingual Tutorial text explains explicit engines and storage limits. No detector/OCR accuracy thresholds changed. **64/64** production-source offline Chromium Settings assertions and **79/79** JavaScript test files passed. Python/Chromium summary and precise test boundaries: [v434 release](docs/releases/V434_RELEASE.md) and [gate](regression/v434_release_gate.json). No complete real-PDF/browser-host/Texify model inference validation is claimed.

---

# v433 — General sidebar and Tutorial prose wrapping (2026-11-11)

Reproduced the v432 **`text-wrap: balance`** policy truncating otherwise usable intermediate lines in narrow Settings help text. The old one-sentence Formula OCR copy change did not solve the shared defect. v433 switches readable sidebar/help/tutorial prose to natural-width `text-wrap: pretty` (normal wrap fallback), with overflow protection and compact bilingual explanatory copy. This avoids artificial line balancing and minimizes very short final lines **where possible**; no browser CSS can guarantee both fully packed preceding lines and substantial final-line content at every width. Mathematical notation, user-selected PDF text, buttons, and preformatted data are untouched. No OCR or detector algorithms changed.

**Red/green:** `tests/prose_flow_v433_regression.py` fails on the unchanged v432 stylesheet and passes on v433; real Chromium measured line widths at 204–360px, EN/ZH, Tutorial, and overflow. JS 80/80 PASS; 37/37 Python/Chromium files PASS individually (concurrent monolithic batch timed out); Tutorial 130/130, orphan-width/theme 12/12, responsive 176/176. [Release](docs/releases/V433_RELEASE.md); evidence `regression/v433_release_gate.json`.

---

# v432 — Content Detection and Formula OCR settings (2026-11-11)

A separate Content Detection settings group now offers non-destructive Results/Equation visibility filters, proof-relationship visibility, and explicit rebuild/margin-scan actions. Display zoom-step and Formula OCR first-crop/retry preferences are browser-local. No detection thresholds, annotations, reading-data schemas, PDF.js version, or actual Texify model were changed. Regression: 80/80 JavaScript suites, 35/35 isolated Python/Chromium test files, 176/176 responsive assertions, P0 isolated browser shell PASS. The combined P0 command timed out and true model mathematical accuracy remains UNVERIFIED. See [v432 release](docs/releases/V432_RELEASE.md) and [gate](regression/v432_release_gate.json).

---

# v431 — Comprehensive reading and cross-column search bug sweep (2026-11-11)

Unchanged v430 baseline passed 77 JS and 33 Python/Chromium test files. Reproduction from actual PMESTOC25 PDF.js spans and adversarial independent columns exposed three Search faults: phantom cross-gutter phrases, missing exact navigation for fuzzy results (especially duplicate phrases), and false impression of complete search after page extraction failure. Fixed in search-only code without changing detector modules, data schemas, or OCR model inference; the user-facing English/Chinese Tutorial documents Search and its limitations alongside Content Detection and Formula OCR. Original-PDF detector proxy replay ran 41 PDFs / 2,039 pages / 123 stages with no exceptions; image OCR and mathematical accuracy remain unverified. See [v431 release](docs/releases/V431_RELEASE.md) and [gate](regression/v431_release_gate.json).

---

# v430 — Formula OCR November 11 feedback (2026-11-11)

Ten verbatim OCR outputs and ten image crops identified a reproducible MathJax environment-scope failure, flattened matrix columns, a repeated-integral **false hard reject**, and a quality-state bug in the alternative Image OCR path. Fixes preserve editable LaTeX, replace raw MathJax error previews with a clear warning, keep multiple-integral syntax for review without futile automatic retry, and allow gentle contrast only on a bounded severe-error retry for faded source pixels. Actual Texify model inference and mathematical transcription accuracy **remain unverified**, particularly symbols, long dense formulas and diagrams. The *user-facing bilingual Tutorial* now covers Content Detection and Formula OCR abilities, limits and remedies. Evidence: [release](docs/releases/V430_RELEASE.md), [gate](regression/v430_release_gate.json); JS 77/77, Python/Chromium 33/33, 10 source image pre-processing checks.

---

# v429 — Extreme Formula OCR quality and bounded retry (2026-11-10)

Twenty user-supplied challenging OCR outputs and 20 original embedded formula screenshots expose previously missed catastrophic array-column and fragmented-equation failures; see [v429 release](docs/releases/V429_RELEASE.md). New severe quality classification is 5/20 vs 3/20 in v428, **not an OCR accuracy score**. A single *visible* bounded local retry is permitted only for first-pass severe errors, with no engine switching; unresolved results remain editable and explicitly for review. Tall-image short-output warnings do not hallucinate missing lines. Actual Texify inference was unavailable in the test environment; the 20 PNG crop checks use real Chromium canvases and the Texify coordinator tests use a mocked inference output. No mathematical correctness rate is claimed.

---

# v428 — Varied-format native PDF stability (2026-11-10)

**Confirmed:** A true two-column page can join the tail of a left-column sentence with a right-column numbered Structure heading when its physical gutter is narrower than the native outline segment threshold. In a 15-page contemporary paper, sections `1 Introduction` and `2 Characterizing Multimodal Safety` were missing from the inferred Structure index. Reproduce with measured source spans in `tests/modern_gutter_outline_v428_regression.js`, which fails against unmodified v427 and passes with the two-pass gutter correction. Do not apply narrow-gap splitting to unproven multi-column pages: single-column equation margin tags must remain intact.

**Verification:** 11 additional original PDFs (1,331 pages) and 30 previously available PDFs (708 pages) ran three production JavaScript detection stages successfully via a PyMuPDF-native-span proxy, total 41 documents / 2,039 pages. Only the two confirmed headings changed; prior 40 outputs remain stable. OCR, actual PDF.js browser text extraction, full-page search/copy/export order, and exhaustive detection accuracy were not certified. See [release](docs/releases/V428_RELEASE.md) and [evidence](regression/v428_varied_format_corpus.json).

---

# v427 — Other cross-column reading/navigation defects (2026-11-09)

**Baseline:** v426. An actual PDF.js-native STOC source fixture reproduced a missed wrapped TOC destination, and independent-column synthetic rows reproduced false reference matches and backlinks (`Lemma` + `5` from different columns). The v426 Structure-panel fix did not cover these TOC and reference consumers.

**Repair:** add column-local reading-line projection guarded by substantial evidence from both page halves. Apply it to TOC-section/text resolution, TOC-page recognition, reference-text fallback, and backlink search. Recover wrapped TOC headings using the existing bounded Structure locator. Preserve single-column pages, embedded/manual Structure navigation, detector indexes, OCR, and saved reading-data schemas.

**Proof:** `tests/multicolumn_reading_links_v427_regression.js` is red on v426 at the genuine section-3 wrapped heading, green after the fix, and includes phantom-cross-column and single-column controls. `tests/multicolumn_toc_browser_v427.py` checks actual Chromium clicks/scroll against two source-measured headings. The 30-original-PDF native-geometry detector proxy replay is unchanged in all four index outputs. See [release](docs/releases/V427_RELEASE.md) and [gate](regression/v427_release_gate.json). Search-text/copy/export column order and full live-PDF object behavior remain **unverified**, not silently marked solved.

---

# v426 — Multiline and mathematical Structure bookmark recovery (2026-11-09)

**Baseline:** v425. The two remaining reported bookmarks in the 12-page STOC paper, section **3** (PDF page 5) and **5.1** (PDF page 11), still landed at the page top. The former heading is split across two right-column baselines, interleaved with left-column mathematics; the latter uses mathematical-bold glyphs and separately extracted subscript digits. v425 required nearly the entire title on one line with matching word breaks. This is a general layout/text-normalization error, not a title-specific exception.

**Fix:** recover headings by column-local multi-line geometry; normalize mathematical Unicode and separated identifiers conservatively; prefer a unique high-quality match while retaining ambiguity guards. An exact `(page, title)` match to an existing measured Structure detector entry is a documented secondary source when the live text layer is insufficient. Preserve explicit non-top PDF destinations, manual Reselect positions, request serial checks, and unrelated detector/OCR code. No persisted schema changes.

**Evidence:** `tests/structure_multiline_math_navigation_v426_regression.js` fails on v425 and passes on v426, exercising real exported PDF.js native items. All **15** observable heading positions in the STOC export/embedded outline are recovered (14 source-detected titles plus the mathematical section 5.1). `tests/structure_multiline_math_navigation_v426.py` exercises actual Chromium clicks and physical scrolling for 2.1, 2.5, 3, and 5.1. Original source PDF bookmark objects were not supplied, so live-site verification remains outstanding. Full test counts and overlay integrity appear in `regression/v426_release_gate.json`.

---

# v425 — Embedded Structure heading jumps in two-column PDFs (2026-11-09)

**Baseline:** v424 assembled from v418 complete + v419–v424 overlays. **User reproduction:** the embedded Structure entries `2.1 Principal Minor Equivalence` (PDF page 4) and `2.5 Cut-Transpose Operation` (PDF page 5) in the STOC 2025 *Characterizing and Testing Principal Minor Equivalence of Matrices* paper both jumped to the page top rather than the printed heading. The v423 heading recovery had matched a complete, joined PDF.js row, but `pageTextLines()` groups same-y text from *both* columns. Actual exported native item replay (not reconstructed from MathReader index) produced merged text containing the heading followed by unrelated right-column text. Thus the bounded prefix match returned `null` and navigation used ratio `0`.

**Fix:** reconstruct column-local heading fragments from preexisting PDF.js `line.parts` x-coordinates, splitting only across a sufficiently broad horizontal gap or column gutter. Match full titles and safe near-prefixes *within each fragment*, never by concatenating across different columns. When an embedded bookmark is at exact page top and a unique heading is measured deeper in the page, use that measured heading even if the bookmark has an explicit page-top mode; otherwise preserve all non-top author coordinates and manual Reselect positions. Multiple matches and missing text remain conservative; document-switch and newer-navigation cancellation remains unchanged. No persisted schema, equation detection, OCR, or manual Structure edit changes.

**Red/green:** new `tests/structure_two_column_navigation_v425_regression.js` failed on the unchanged v424 at section 2.1 with ratio `0`, and passes on v425; its negative cases cover crossed-column false headings, repeated headings, manual edits, and non-top XYZ destinations. The actual 12-page `PMESTOC25-mathreader.json` native PDF-text replay measured section 2.1 at `0.3206123737` (page 4) and section 2.5 at `0.2244292929` (page 5). The unchanged v424 matcher returned `null` for both and page-top jumps, while v425 returns the exact extracted ratios. Production row building and the production navigation matcher were invoked in the replay. `tests/structure_jump_position_v423.py` now also verifies both clicks against physical Chromium scroll offsets, rather than checking only the requested ratio.

**Validation scope:** Chromium uses controlled page surfaces and mocked PDF destinations; actual website testing with the source paper's original embedded PDF outline is not claimed. The original export provides its native text geometry but not the PDF's raw bookmark objects. Reading/display rendering and the previously accepted Ahlfors OCR-persistence limitation are unchanged. v425 is overlay-only.

---

# MathReader — Regression policy and recent history

## v424 — Reading navigation and search cancellation (2026-11-10 UTC)

- Independent audit of the reconstructed v423 source (70/70 baseline JS PASS) reproduced stale asynchronous Results/reference/text-search alignment that moved a viewport **after** a newer navigation request; a delayed search could also mix old/new query results or write stale results into another PDF. The document-switch reset retained visible search rows from the previous file.
- Source-backed Chromium regression `tests/reading_navigation_races_v424.py` fails on v423 at delayed semantic alignment (`scrollTop` moves from 730 to 1300), and separately confirms outdated searches and previous-document hits. v424 guards semantic landing, search-result alignment, equation-bookmark/search alignment, reference lookup and visible search-list reset with document identity and request serials. Active navigation still works normally.
- Regression: 70/70 JavaScript tests, 31/31 Python/Chromium test files, 176/176 responsive assertions. Source syntax and assembled runtime verified. No index format/OCR/detection changes. Real-user PDF/PDF.js integration and model inference remain unverified. [Release](docs/releases/V424_RELEASE.md) and [gate](regression/v424_release_gate.json).

## v423 — Structure heading navigation (2026-11-10 UTC)

- Reproduced on unchanged v422 with a real Chromium DOM test and the production embedded bookmark resolver/Structure click handler: page-only `Fit` to a heading at 62.5% of the page navigated to ratio 0. Another `XYZ` bookmark with a `null` top was misinterpreted as PDF y=0.
- The new conservative text-line recovery applies only when the embedded bookmark lacks an authoritative vertical coordinate or when an inferred heading has no useful ratio; exactly one matching page-local heading line is required. Explicit PDF destinations and manual Reselect coordinates are preserved; asynchronous document-switch/click races are guarded.
- The actual `goToLocation()` and a real scrollable Chromium layout were exercised after the Structure click. Other index detectors and the Structure index schema were not changed. [v423 release and limitations](docs/releases/V423_RELEASE.md).


## v420 — local-column equation tag recovery

- Reproduced on the complete 12-page native-text export of the STOC 2025 paper: v419 missed printed (1), (12), (13), (14), (18). New regression fails before the fix, passes with 21/21 labels and no extras; numbered list conditions remain excluded.
- The root cause is two-column line attribution and short determinant-display classification, not a one-off numbering dialect. The fix has no PDF-specific conditions. Equation index schema: 28 → 29; existing reading data and v419 manual Structure are preserved.
- Broader regression: 67/67 JavaScript suites, 29/29 isolated Python/Chromium files. The combined Python batch timed out; passing isolated test files do not imply a monolithic batch passed. Leon Simon PDE (224 pages) remained 20 label strings / 171 native occurrences before and after.
- See [`docs/releases/V420_RELEASE.md`](docs/releases/V420_RELEASE.md) and `regression/v420_release_gate.json` for evidence, assumptions and remaining limitations.

This is the stable entry point for MathReader's development and verification record. The archived v414–v405 release entries follow **unchanged** below the current v419 findings. Earlier records were reorganized into the [historical archive](docs/README.md#regression-history) without dropping or silently rewriting their evidence.

## Standing verification requirements

- Verify **Structure, Results, Equations, and Bibliography** together; track false positives, omissions, printed page coordinates, ordering, and reference navigation. Results and Bibliography cannot currently be edited manually.
- Pair document/index regressions with **formula image-to-LaTeX** checks in the same source PDFs. Distinguish real OCR inference and independently checked mathematical truth from source-level, native-text-proxy, or Chromium-shell tests. Successful tests alone do not certify 100% accuracy.
- Preserve conservative equation-label click geometry, reading-position behavior, existing WebGPU-to-CPU fallback, document identity, annotations, and local-first storage. Do not introduce hidden fallback behavior.
- Preserve the accepted limitation: equation-margin OCR evidence may be lost after hard reload (Ahlfors); do not reopen persistence repair without explicit approval.
- Record baseline-failing evidence before corrections, actual validation commands/results, and unresolved or unverified conditions. Never silently recategorize old FAIL/UNVERIFIED findings as PASS.

## Finding older regression records

See [Documentation map](docs/README.md) for OCR, export, audit, and release documents, and the [regression history archive](docs/README.md#regression-history) for older v338–v404 notes. The historical archive preserves the supplied v414 source record in its original order, including later appendices.

---

## v419 — Manual Structure additions alongside embedded PDF bookmarks (2026-11-09 UTC)

**Reproduced on untouched v418:** `tests/structure_manual_embedded_v419_regression.js` constructs an embedded PDF outline and selects arbitrary prose for the Structure action; baseline rejects it with “Use Reselect on an existing Structure item; embedded outlines do not support adding new items.” The new test fails before the fix and checks interleaving, manual indent, Reselect, Remove, original embedded bookmark metadata, Undo and saved session behavior.

**Correction:** manual Structure items now coexist with existing embedded bookmark rows in reading order without rewriting native bookmark hierarchy/order. Manually chosen text is not required to be an automatically detected heading. A common row renderer keeps manual indentation, navigation and edit actions consistent in embedded and inferred modes. Rebuilding typography indexes merges the current manual edits (including those made during in-flight detection) instead of replacing them. Schema-version cache invalidation retains user-edited entries; reading-only exports retain them. Embedded PDF bookmarks are usable even when page text is not extractable. The shared 1200-entry limit retains manual entries ahead of detector output; duplicate manual selections do not create extra rows.

**Regression scope:** source-driven VM behavior, a DOM integration test in local Chromium using controlled PDF bookmark destinations, existing JavaScript suites, and focused Python/Chromium shell checks. This is *not* a deployed-site original-PDF test, nor does it certify Structure precision on every source PDF. Exact results are recorded in [v419 patch manifest](docs/releases/V419_PATCH_MANIFEST.md) and `regression/v419_release_gate.json`.

**Distribution:** only changed files under a single `mathreader/` root in `mathreader_v419_patch.zip`, intended to overwrite the existing v418 folder; no full-folder delivery.

---

## v418 — Local printed-label occurrences and wider mathematical numbering (2026-11-09 UTC)

**Reproduced on the supplied v417 sources:** Leon Simon, *Lectures on PDE*, has 224 pages and its exported v417 equation snapshot retained only **19 printed-label entries** despite repeated, physically distinct, left-margin `(1)`, `(2)`, ... series in separate lectures. On PDF page 125, actual native PDF.js text preserves `(2)`–`(8)`, whereas v417 retained only `(7)` and `(8)`. The new `tests/equation_numbering_scope_v418_regression.js` runs the complete production equation builder against twelve frozen native-text pages selected from the user export, and fails on v417 before the fix. It separately checks real displayed `(1)`,`(2)`,`(3)` on p.95 and excludes a wrapped `(2))` reference on p.61. It is a **native-text proxy**, not an original-page visual truth audit.

**General correction:** equation labels are display strings, **not document-wide occurrence IDs**. For strict native-margin labels retain individual verified pages, deduplicating same-label repeats *on one page* conservatively (unchanged v415 protection). Preserve existing chapter-specific and colon-font `(3:6)` → `(3.6)` safeguards. Avoid rejecting math operators and two-letter indexed variables as prose or programming syntax; explicitly exclude malformed prose `(2))`. Expand parser grammar to numbered letters `(1a)` / `(1.2a)` / `(2.4b)`, full chapter–section–equation `(1.2.3)`, Roman-prefixed `(II.7.14)`, `(III.6)`, and appendix `(A1)`, `(C.2a)` without globally rewriting strings. Exclude explicit `refer to (II.7.14)` prose contexts. A separate parser regression fails on unmodified v417, then passes on v418. Standalone numbers under definition lists remain excluded.

**Independent numbering-convention research:** Atkinson and Han, *Theoretical Numerical Analysis*, explicitly document `(1.2.3)`; Ronold W. P. King, *The Theory of Linear Antennas*, explicitly documents within-section `(1)`, cross-section `(7.14)`, and cross-chapter `(II.7.14)`; R. K. Livesley, *An Introduction to Automatic Digital Computers*, Cambridge excerpt shows `(1.2a)`–`(1.2c)`; IEEE *Editing Mathematics* documents `(1a)`, `(A1)`, and `(1.2.1)`. These provide **convention-level tests**, not MathReader runs on those books' source PDF bytes. Reference URLs and test scopes are in [v418 release note](docs/releases/V418_RELEASE.md).

**Measurements and gates:** full-source native replay of the supplied 224-page Simon PDE export: **v417 19 occurrences → v418 171 candidate occurrences across 20 labels** (counts alone are **not** precision/recall). The frozen 12-page source fixture yields 32 occurrences/19 labels. Previously reported Simon GMT colon-font regression retains its expected printed label pages and its conservative same-page de-duplication. All **64/64 JS** suites, **28/28 Python/isolated Chromium** tests, **176/176 responsive assertions**, 80/80 source syntax checks and P0 Chromium shell passed. Cache key v417→v418 and local equation snapshot schema 27→28 force local detector refresh; portable old exports remain importable. Evidence: `regression/v418_release_gate.json`, `regression/v418_js_results.json`, `regression/v418_python_results.json`, [release note](docs/releases/V418_RELEASE.md).

**Not certified:** mathematical truth across all 224 printed PDF pages, real Texify/image-formula accuracy, real browser PDF.js on the original PDF, same-page section resets with duplicated printed labels (still conservatively collapsed), and historical Ahlfors OCR evidence persistence. No user-specific filename exceptions or new automatic OCR workload were introduced.

---

## v417 — Keep first-crop OCR exclusive through inference (2026-11-09 UTC)

**Reproduced on untouched v416:** `tests/formula_ocr_pending_crop_race_v417_regression.js` executed the original initialization and crop handlers with a successfully loaded, deferred pipeline. `initializeMathOcrPipeline()` cleared the shared `mathOcrLoading` flag before the waiting crop completed its actual image inference. The assertion that OCR remained busy during inference failed. This could prematurely enable selection, engine reset/settings, and competing extraction while one crop was still running.

**Correction:** track an active crop separately from initialization. The engine-init `finally` keeps OCR controls busy while an outer crop is pending; both the ordinary image extraction and image-comparison path own and release the crop token, and reject a competing crop while the token is held. The existing PDF object and identity checks still prevent stale OCR commits after changing documents. A pending crop displays processing status rather than claiming that OCR is ready and finished; the rest of the reader remains interactive. No equation/Results/Bibliography detector, PDF cache schema, model backend, or persistence format change is made. Browser asset cache advanced to v417.

**Verification:** the new test demonstrably fails on the original v416 source and passes after the correction. Independently reran all **62/62 JavaScript regression suites** (including the added test), **28/28 Python/isolated Chromium suites**, and `regression_tools/p0_browser.py --shell-only` (**PASS** on the assembled v417 app). Regression evidence is in `regression/v417_release_gate.json` and [the v417 release note](docs/releases/V417_RELEASE.md). Browser-shell checks are not real Texify inference and do not certify actual WASM frame responsiveness. No source-matched original PDF binaries accompanied this ZIP; neither mathematical detection completeness nor mathematical OCR accuracy was newly certified on original PDFs. The accepted Ahlfors reload limitation remains unchanged.

---

## v416 — Non-blocking first-crop Formula OCR initialization (2026-11-09 UTC)

**Reproduced on unchanged v415:** the first image-formula crop displayed `#formula-ocr-init-overlay` as a full-screen `aria-modal` dialog, made all other document-body children `inert`, and intercepted global keyboard and file-drop actions. This disabled PDF reading and navigation during model initialization even though the model import and pipeline construction were asynchronous.

**Correction:** remove the blocking modal, its styling and global interception. First crop still starts exactly one asynchronous lazy Texify initialization; the saved crop waits for readiness and then follows the existing recognition path. The Formula OCR sidebar displays the work state, while page controls stay active. Keep browser asset cache v416; no mathematical index format changes. Failed, timed-out and late initialization do not lock the reader or silently retry. OCR selection and engine reset/settings remain disabled while the single recognition job is active, to prevent replacing a pipeline while its first crop is pending.

**Verification:** baseline v415 fails the v416 nonblocking regression checks; all 61 Node.js tests and all 28 Python tests, including isolated Chromium UI tests, pass on v416. The P0 Chromium shell failure injection verifies theme controls remain usable while model loading is pending. The OCR lazy test confirms a queued crop produces its result after asynchronous completion, while a crop left behind by a PDF switch cannot contaminate the next document. Source/module syntax and full ZIP integrity checked separately. Actual Texify model download/initialization, original-PDF imaging, continuous frame responsiveness during synchronous ONNX/WASM compilation or inference, and mathematical OCR accuracy were **not** verified; no Web Worker conversion is claimed. Details: [v416 release note](docs/releases/V416_RELEASE.md).

---

## v415 — Section-local equation numbering and damaged-font colon labels (2026-11-09 UTC)

**Evidence:** user's MathReader export for Leon Simon, *Introduction to Geometric Measure Theory*, 267 pages; document ID `sha256:8a261ff912d78cf839d102e99f317a391949d69c017e109dd2629796d4c3b999`. The export reports **48** equation-index labels and includes 267 pages of PDF.js native text lines and geometry. Several printed-margin numbering candidates are extracted as `3:6`, `3:7`, `3:8` rather than dotted labels. Independently, section-local `(1.1)` labels restart in later chapters, but v414 canonicalized all locations with a shared label to one entry. Definition 1.4's numbered conditions `(1)`–`(3)` on PDF page 7 were incorrectly indexed as equations.

**Corrections:** preserve native text offsets and derive a candidate for *leading* colon-encoded two-part numbers, but promote it only when independent document-wide left-margin alignment, distinct labels over multiple pages, and formula-like text support the damaged-font convention. Reject time/prose/axis/table/heading candidates. For credible chapter-local repetitions, retain separate physical page/ratio occurrences, render each with a stable drag key and protect navigation against cross-chapter misdirection. Because Remove/Reselect edits currently target a printed label globally, suppress those actions only for ambiguous repeated labels rather than silently modifying another chapter's equation. Strengthen exclusion of numbered conditions introduced by a Definition. Advance browser asset cache v414→v415 and local equation-index schema 26→27; **old local snapshots must rebuild**, while portable imported snapshots remain preserved when source text is unavailable. This is a general detector change, not a filename exception.

**Regression evidence and limitations:** the new `tests/simon_colon_font_v415_regression.js` reproduces a **failure on untouched v414** and passes with the new source. A full **267-page native-text replay** of the production equation builder from the user's export changes recognized distinct label IDs **48→145**, producing **223 occurrence candidates** over the full document, with one duplicate label on the same page conservatively collapsed; `(1.1)` survives in multiple chapters and PDF page 7's `(1)`–`(3)` false positives are absent. These are *candidate/index counts*, **not independently certified correct printed equations**. The original PDF bytes were not provided; no original-page image comparison, live deployment, mathematical formula OCR, or comprehensive recall/precision certification is claimed. A separate cache boundary test verifies local invalidation and portable preservation. The old `tests/equation_margin_navigation_regression.js` contained an overly greedy source-function extraction causing a v414 VM syntax failure; this was corrected without altering application behavior.

**Known limitations:** old v414 **imported portable** detection may intentionally retain its old 48-row snapshot; use **Rebuild index** with the native-text PDF open to refresh. Ambiguous repeated printed labels are navigable and orderable, but not safely individually Remove/Reselect-editable until edit identity includes a page/ratio. Existing hard-reload OCR-evidence loss remains accepted and unchanged. Full formula-transcription accuracy on this source remains unverified.

---

## Latest regression entries (v414–v405)

# v414 — Additional PDF corpus, Results precision, and academic UI copy/layout (2026-11-08, Beijing UTC+08)

**Baseline:** intact v413 source assembled from the complete v405 archive plus the v406–v413 root-level patches. Scope is conservative mathematical declaration detection and precise welcome/empty-state copy/compact styling. There is no OCR-engine, browser persistence, PDF navigation, bibliography parsing, equation hit-testing, or UI-layout redesign in this release.

**Eight additional original mathematical PDFs, 145 pages:** independent SHA-256 identifiers and per-document native-text proxy measurements are in `regression/v414_extra_pdf_wording_aesthetic_audit.json`. The actual `buildStructureIndex` is replayed with original PDF native line geometry; this is **not** a full live PDF.js/OCR rendering test. The Lean examples collection (76 pp) exposed three genuine numbered declarations missing in v413: `Example 191` on PDF p57 and `Example 192` and `Example 193` on p58. Their imperative heading text (`Prove ...`) was incorrectly treated as a narrative reference. The narrowly scoped fix accepts such explicit Example declarations without admitting narrative `Example 191 proves ...` references. Separately, the 22-page Chinese real-analysis text prints `定理 4.1 (Egorov)` on PDF p8; v413 missed it. v414 recognizes **explicitly numbered Chinese statement headings** with bounded punctuation and statement context, without inferring labels from gaps or attempting broad Chinese OCR.

**Measured changes in this new corpus:** Lean Results **259→262**; real-analysis Results **0→1**; the other six original PDFs have unchanged Results. **Four additions, zero removals.** The Lean example labels 1–261 are all present in v414's native-text replay, but this is not an exhaustive independent page-image audit of all 261. Bibliography entries are unchanged in all eight; seven printed bibliography keys in two documents were checked against original page images. Six historical saved PDF.js detector-input exports (Giusti 207/75, Ahlfors 95/66, SPS 7/17, Simon 4/18, Banach 14/9, saved Yamabe 51/46) replay through the full builder with **identical Results and Bibliography labels, titles, page locations and ratios** between v413 and v414. The separately available original Yamabe PDF is not SHA-identical to the old saved Yamabe export; do not treat them as a paired original.

**Wording and aesthetics:** shorten welcome headline/descriptions and privacy explanation (English/Chinese), and use a shorter Chinese heading; replace inaccurate `Filter theorems` with `Filter results`; distinguish unopened-PDF, currently-building and empty-detection states for Structure, Equations and Bibliography. On **320×568**, the welcome panel previously clipped lower content with no way to scroll; it now scrolls vertically only when needed and stays centered at ordinary dimensions. Isolated real Chromium DOM/CSS checks exercise five sizes, both languages and light/dark themes. The UI changes do not add controls, enlarge panels, or introduce background loading work.

**Regression gate and limitations:** 61/61 JavaScript suites, 27/27 bounded Python/Chromium suites, including the new bilingual copy/layout test (80 assertions) and the established responsive suite (176 assertions). New declaration tests failed on v413 and passed on v414. Syntax, the assembled 10-module runtime, ZIP integrity and clean v413 overlay are documented in `regression/v414_release_gate.json`. Original-pdf proxy and isolated Chromium are not live production-site acceptance, and neither semantic formula OCR nor independent full-document Results/Bibliography precision/recall is certified. Unnumbered Chinese examples remain unsupported. The accepted Ahlfors equation-margin evidence loss on hard browser reload is unchanged and not revisited.

---

# v413 — Expanded original-PDF content detection regression (2026-11-08, Beijing UTC+08)

**Baseline and source scope:** v412 complete source tree; minimal correction in `js/41-equations-bibliography.js`, old Results-cache invalidation 53→54, asset key 412→413, regression suites and durable audit documents. No PDF editing, UI redesign, OCR-model change, formula-generation change or storage persistence repair.

**Evidence-based discovery:** 14 **additional** distinct original PDFs (1,062 pages), distinct from the prior 19-PDF v412 corpus. Includes Simon *Lectures on PDE* (236 pp), Simon *Introduction to Geometric Measure Theory* (274 pp), an 18-page covering-space note, 14-page conformal summary, two Yamabe manuscripts, a Radon/Riesz note, a six-page geometric-integration note, a 13-page formula-stress PDF, four handwritten lecture-note PDFs (12 pages total) and a 441-page writing textbook as a deliberate mathematical false-positive control. Original SHA-256 was computed from each materialized source PDF. The new work uses original PDF text extraction to feed the **actual** MathReader full Results/Bibliography builder under a Node VM. This is a **native-text proxy**, not production PDF.js or a real MathReader site session.

**Confirmed v412 omission:** Simon PDE p52 printed `Lemma 3. (Sobolev embedding theorem.) If...` and p53 printed `Lemma 4 (Rellich’s Theorem.) Suppose...`; the PDF text layer joins the closing parenthesis directly to statement text (`)Ifk...`, `)Suppose...`) and may contain non-ASCII glyph/control fragments. The v412 named-heading gate rejected these genuine declarations, along with named theorems such as Weyl and the weak maximum principle. Separately, *yamabe_missing_lemmas.pdf* p13 `Proposition 5.3 (Asymptotic flatness of the Green blow-up). In...` and p14 `Corollary 6.3 (Green constant equals one half the mass). Under...` were rejected by an overly broad post-name prepositional filter. Representative original pages were rendered and inspected visually; do not confuse this with exhaustive manual validation of every recovered entry.

**Narrow correction:** permit a substantive parenthetical theorem name immediately followed by a restricted mathematical statement opener; allow only the specific genuine statement contexts `In the...` and `Under the...` after a valid named heading, without disabling general narrative/citation rejection. Treat PDF-extraction joins `SupposeF...` / `Ifu...` after an explicit numbered declaration as independent statement evidence so repeated chapter-local theorem numbers are retained. Preserve rejection of `(a)` subparts, `(see...)` and `from/in previous proof` references; no label is created from a numbering gap.

**Measured Results delta:** Simon PDE **54→78** (24 additional candidate declarations, 0 removed). *yamabe_missing_lemmas* **26→28** (2 additions, 0 removed). The other **12 new PDFs** have unchanged Results and Bibliography. All six earlier MathReader saved full-builder PDF.js-input replays retain their v412 Results and Bibliography labels, pages, ratios and totals; historical bibliography untouched. In the new PDFs, Simon GMT Bibliography **27/27**, Yamabe manuscript **5/5**, and Radon/Riesz **2/2** keyed references agree with the actual printed reference keys and PDF pages (34 checked). The 441-page nonmathematical control yields no Results or Bibliography. This is **not** a universal zero-error certificate, and some weak/repeated/unnumbered Results may still be omitted.

**Formula OCR and non-native evidence:** the formula stress PDF has native-layer formula examples plus two raster-only challenge pages. Four handwritten PDFs (12 pages) contain practically no usable native mathematical text; one offline Tesseract sample from handwriting and one raster formula challenge yielded unreliable mathematical transcriptions. These samples are **not** evidence of full model OCR success, and neither authentic Texify browser OCR nor independent formula-level semantic ground truth was evaluated in this round. Existing Equation, Structure and navigation regression suites remain part of the release gate, but full new-document mathematical precision/recall is unverified. The accepted hard-reload OCR-evidence limitation remains unchanged.

**Release gates:** see `regression/v413_release_gate.json`, `regression/v413_results_bibliography_corpus.json`, and `V413_PATCH_MANIFEST.md`. No live production-browser acceptance is claimed.

---

# v412 — Mathematical Results detection: joined headings, split baselines, and conservative reference boundaries (2026-11-08, Beijing UTC+08)

**Baseline:** complete v411 MathReader source. **Scope:** conservative, evidence-backed result-declaration recognition; no UI redesign, equation OCR alteration, formula transcription change, or background persistence repair. Results and Bibliography are non-editable, so both false positives and missing printed declarations are treated as serious correctness issues.

**Reproduced defect 1 — historical joined headings:** original 56-page Lee–Parker *Yamabe Problem* PDF stores headings in its native text as `THEOREM5.1...`, `LEMMA3.5...`, `DEFINITION6.2...`, sometimes without a space before the opening sentence. v411 missed many genuinely printed theorem/lemma/definition/corollary declarations. v412 accepts only bounded, heading-shaped uppercase joins and preserves the actual observed label/position. It does not infer any missing number from a numerical sequence. Prose statements like `THEOREM5.1 shows ...` remain rejected.

**Reproduced defect 2 — independent baselines for title and number:** e.g. printed `THEOREM 5.2` on original p23 is represented by separate PDF text spans on slightly different vertical baselines. The PDF.js-shaped text-line builder can split these into separate entries, leaving a bare `THEOREM` line and a `5.2` number fragment. v412 recovers a label only when the uppercase heading and an explicitly printed numeric fragment have very close x/y geometry (tight baseline, same local column, measured native parts). It rejects separated/ambiguous numbers, lower-case prose heading, distant margin and missing native parts. Such independently printed evidence is stronger than a later weak prose-looking mention of the label.

**Reproduced defect 3 — superscript interrupts prose reference:** in Yamabe p40, the sentence ends `... by`, followed by a tiny math superscript line and `Lemma 9.1. If ...`; previous Results detection indexed that **reference** on p40 instead of the printed lemma statement on p39. v412 checks back over at most two tiny superscript-only intervening lines to detect reference grammar and retains the actual lemma on p39. Reference-tail rejection also covers `therefore shows`, `then implies`, and similar narrative phrasing without excluding actual declaration statements.

**Independent original-PDF evidence and measured boundaries:** the 56-page Yamabe native text-line proxy changes 4→48 result entries; a closer **PDF.js-shaped native-span replay using actual production pageTextLines + buildStructureIndex** changes **15→48**. The 48 recognized label/page pairs agree between the two independent text-segmentation paths and with targeted printed-page inspection (see `regression/v412_content_corpus_audit.json` and saved page montage). This is NOT a full 56-page manually adjudicated recall/precision certification and NOT a real browser's PDF.js output. Bibliography in this replay remains **46**. A separate 88-page math paper keeps **62 Results / 183 bibliography** under the closer span replay in both v411 and v412; the earlier crude 5-entry text-line proxy result is an extraction artifact, not evidence of a deployed v411 failure.

**Historical exact-export regression:** full actual MathReader builder replay from six saved PDF.js `detectorInputLines` exports retains every prior Results and Bibliography entry, count and position: Giusti 207/75, Ahlfors 95/66, SPS 7/17, Simon 4/18, Banach 14/9, saved Yamabe 51/46. The first five original PDFs match export SHA-256; available standalone Yamabe PDF has a DIFFERENT SHA-256 from the saved export and is treated as a distinct evidence source. It is not a verified matching pair.

**Broader corpus:** 19 distinct mathematics PDFs, 1,367 pages, consisting of the earlier 14-PDF/1,228-page audit plus five independent documents / 139 pages (algebraic/Monge–Ampère research paper, Yamabe commentary, plateau compactness, positive mass theorem, lemma proof). Includes both text-layer and scanned/image-only PDFs. The expanded tests include native-text proxy comparisons for Structure/Results/Bibliography but no claim of complete independent visual ground truth for every page, complete formula semantic accuracy, or error-free OCR. Existing raw equation-margin evidence loss after browser hard reload remains an accepted unchanged limitation.

**Regression:** 58 JavaScript suites, 25 Python/Chromium suites including a new parser-in-Chromium test; 30 new JavaScript assertions and 9 Chromium assertions. See `regression/v412_release_gate.json` for the final executed gate and `V412_PATCH_MANIFEST.md` for every changed file. Source changes are restricted to declaration parsing, Results index cache version (52→53), browser asset-cache keys (v412), regression tests and audit documentation. ZIP is a *root-level patch over v411*, not a full-source archive. No live production-website acceptance with the user's PDF was run; the precise OCR accuracy and detection recall for arbitrary previously unseen scans remain **unverified**.

---

# v411 — Exact-click Equation Add; prohibit adjacent label capture (2026-11-08, Beijing UTC+08)

**Baseline:** exact v410 assembled source. **User evidence:** screenshot of original Giusti (1984), PDF p20, showing printed `(1.4)` at the left of a display formula and prose `(1.2)` on the preceding line. The original matching PDF's native text extracts `(1.2)` in the prose line, but omits the visible printed `(1.4)` label. v410 `equationLabelNearPagePoint(page,ratio,exclude)` scans up to **0.065 page height** vertically and never compares the click's horizontal coordinate to the candidate tag. On the subsequent Add path, the `applyEquationEdits()` map blindly calls `out.set(label,...)` and replaces an existing label's position. This explains how clicking `(1.4)` could incorrectly relocate `(1.2)`.

**Correction:** propagate both normalized x and y from the actual primary or continuous page surface; only auto-match a candidate whose measured word-level tag bounds contain the pointer, with a strict vertical line/word bound and at most a 0.002 page-fraction edge allowance. Require *fine-grained word/token geometry*; do not trust a whole-line range or a long PDF.js part's proportional character estimate. If the precise tag cannot be identified (including missing PDF text/OCR), request manual label input for the clicked point; never borrow the nearest tag. A duplicate Add (observed, typed, or selected) is rejected with an actionable Reselect message, leaving the pending Add active; imported historical duplicate additions cannot shadow an automatic index entry on replay. Reselect collisions with an existing distinct label are also blocked. Async stale-document/pending-operation completion cannot create a cross-document edit. Preserve existing saved manual records, editing order, navigated ratio, and index schema.

**Red/green evidence:** `tests/manual_equation_click_precision_v411_regression.js` fails on pristine v410 at the original miscapture (x=.085,y=.265 near prose `(1.2)` at x≈.44,y=.229), then passes **21** assertions in v411 including direct-hit acceptance, vertical/horizontal separation, previously saved duplicates, coarse-geometry rejection, and text-selection Add. `tests/manual_equation_click_browser_v411.py` executes actual production pointer event listeners/functions in headless Chromium against synthetic page surfaces and grounded line geometry: **5** DOM scenarios, including primary and continuous clicks, duplicate clicks, and typed duplicates. It is not a deployed browser/real PDF.js-original-PDF end-to-end certification. The existing `manual_appendix_equation_v405_regression.js` retains **38** assertions and now supplies a 2D point and newly extracted duplicate guards.

**Gate:** 56/56 JavaScript suites; 24/24 Python/Chromium suites (slow harnesses verified separately); all JavaScript syntax and assembled module validation; root ZIP CRC and byte-exact clean overlay replay over the exact original v410. Only manual Equation Add/Reselect geometry and persistence collision handling changed, plus PDF.js native `pageTextLines` exposes measured native item heights for correct hit-testing. Structure/Results/Bibliography/automatic equation detection, OCR jobs, canvas rendering, storage schema, and the accepted hard-reload OCR evidence limitation are unchanged. v411 updates only browser asset cache keys.

---

# v410 — Recover intermittent first-open continuous-page paint failures (2026-11-08, Beijing UTC+08)

**Baseline:** exact v409 source and root-level differential patch. **Symptom:** when first opening a PDF, continuous reading occasionally displays `Continuous reading could not render the current page.` and the active page stays blank until the user changes zoom. The message originates only in the first continuous-document builder, after an initial PDF.js canvas render and a primary-render fallback. The original release treated the 48×48 downsampled canvas brightness-variation heuristic as a hard failure; genuinely white/sparse pages also fail this heuristic, while the normal zoom rebuild skips this verification entirely. A genuinely rejected PDF.js render can also be transient at first open.

**Correction:** keep PDF.js paint success and a non-placeholder canvas as the decisive conditions; treat the 48×48 content sample as diagnostic rather than proof of failure. If the first paint seems blank, retain the existing independent primary-render fallback and then retry the original page at the **same zoom** on a **freshly attached canvas** after two layout frames. Failed continuous PDF.js tasks also receive the bounded fresh-canvas attempt, and only then the independent primary-render fallback. A genuine unrecoverable task failure still reports the existing error. Successful blank or sparse pages no longer prevent neighboring pages from initializing. Retry guards reject stale generation/document/page ownership; reading anchor, sidebar and zoom mode are unchanged. The recovered-primary path now restores selectable text/annotations when the continuous task never supplied overlays.

**Reproduced red/green:** new Playwright/Chromium regression `tests/continuous_initial_repaint_v410.py` executes the production `30-rendering-navigation.js` lifecycle with real DOM/canvas/requestAnimationFrame/observer and mock PDF.js page paints. On unmodified v409 its first case fails with the exact reported error (`first_blank_then_good`, retry never attempted). On v410, 25 assertions pass across initial blank then successful repaint, legitimate all-white page, transient PDF.js rejection, independent primary-only recovery, persistent failure/error, normal no-extra-repaint, and invalidated generation. This simulates paint timing; **not live-site acceptance with actual PDF.js rendering of the user's intermittently failing PDF**. A bounded retry may not solve every browser/GPU issue; residual failures are reported rather than hidden.

**Regression gate:** 55/55 existing JavaScript suites; 23/23 Python/Chromium suites (the two historically stalled harness suites were checked separately); v410 JS/bootstrap syntax and ten-part assembled-runtime syntax; root ZIP CRC and byte-exact replay against the untouched v409 source. No changes to mathematical OCR, Structure/Results/Equations/Bibliography detection, annotations persistence or document exports. Previously accepted raw OCR evidence loss after hard reload remains untouched.

---

# v409 — Results declarations and cross-document content-detection regression (2026-11-07, Beijing UTC+08)

**Baseline:** the exact v408 source. **Problem:** Results and Bibliography are not editable in the current interface, so a falsely indexed theorem/reference or a missing real statement is particularly disruptive. This release is a conservative parser correction and expanded source-level audit, *not a claim of error-free recognition for every PDF*.

**Confirmed on original historical source:** Giusti (1984) PDF p150 wraps `(see Theorem 14.5)` across text lines. v408 promotes the wrapped citation to a real Theorem 14.5. Its global monotonic theorem-number rule then removes 12 genuine Theorem declarations on pp154–175. v409 checks the immediately preceding visual line for a grammatical reference lead with page-relative geometry, and prioritizes physically printed number-first declarations above weak reference candidates. Full production builder replay on the original saved PDF.js inputs: **196 → 207 Results** (+12 true printed statements, −1 p150 false citation); actual Theorem 14.5 moves to p175. No inferred missing theorems.

**Yau (1978) p38–39:** `... we can deduce / Lemma 1.` is a sentence continuation on p39, not another statement. The real unnumbered `LEMMA` on p38 remains. Historical exact PDF.js fixture: **13 → 12** Results. Saved Yau JSON does not include `detectorInputLines`, therefore Yau was *not* counted as a full-export replay.

**Additional grammar and document-local numbering:** accept explicit names with no PDF-text gap, such as `Theorem 1(Positive mass).Let ...`, `Definition 1(Radon transform).For ...`; reject partial-number fallthrough (`Proposition 3.1` → `Proposition 3`) and subpart references (`Theorem 2.1(a)`). Do not deduplicate genuinely separate `Definition 1` or `Proposition 1` declarations when lecture numbering restarts; link proof references to the nearest physically preceding matching declaration. Keep actual observed page/ratio coordinates.

**Bibliography:** algebraic-geometry source `0810.5645v6.pdf` p198 has printed `[16]Anneaux ...` with no extracted separator. A supplementary no-space author-heading regex recovers it; the offline native-text proxy returns all 105 distinct numbered references `[1]`–`[105]`. **Critical adjacent regression caught during full replays:** replacing the old whitespace grammar dropped Greek-initial Banach `[6]` and comma-prefixed repeat-author Yamabe references. Fixed by retaining the old grammar verbatim and adding only the no-space alternative. Full builder replay of **six saved exports:** Results counts Giusti 196→207, Ahlfors 95→95, Simon 4→4, SPS 7→7, Banach 14→14, Yamabe 51→51; **Bibliography counts remain exactly 75, 66, 18, 17, 9, 46** respectively, with no dropped or displaced entries. The separately available Yamabe PDF has a different SHA-256 from its export, so that combination is explicitly not a verified original/export pair.

**Expanded corpus:** 14 distinct PDFs, 1,228 pages: 7 established historical PDFs/595 pages; 5 additional native-text PDFs/299 pages; and 2 image-only PDFs/334 pages (a historical minimal-surfaces paper and do Carmo's *Riemannian Geometry*). All six historical original/export pairs used in the full builder replay were SHA-matched except Yamabe, which has the known mismatch. The added 299 pages are native-text PyMuPDF-to-production-parser **proxy** evidence, not genuine PDF.js/browser input. Selected statements and reference-key positions were compared with printed PDF content; complete visual ground truth over 1,228 pages was **not** established. The historical minimal-surfaces scan p19 shows an OCR-sample failure for a printed `[11]` bibliography entry, and the reader must not guess it from neighboring numbers. See `regression/v409_corpus_audit.json` for per-file counts, provenance and unresolved limitations.

**Structure and formulas:** no modification to Outline, equation detection, OCR engine, mathematical LaTeX generation or UI layout. Existing Structure/TOC/navigation, bibliography, formula, cancellation and cross-document regression suites passed, but that does not certify complete mathematically accurate content recognition. The Ahlfors hard-reload OCR-evidence persistence limitation remains accepted and unchanged.

**Regression:** 55/55 JS suites; 22/22 bounded Python/Chromium suites (the two harness-stalled suites were rerun successfully in isolation); 70/70 JS syntax files. New JS tests cover historical Giusti/Yau lines, named headings, chapter-local repeated labels, Unicode author keys, comma-prefixed author repetitions and no-space bibliography keys. No deployed/live-original-PDF browser test was performed. Cache version advanced to v409 and Structure index version 52; an existing imported snapshot may require **Rebuild index**.

**Acceptance boundary:** this release fixes the documented, reproducible failures without replacing trustworthy data with guessed entries. The user requirement of **zero mistakes** in uneditable Results/Bibliography indexes cannot yet be certified across arbitrary historic/scanned PDFs. Actual OCR, uncertain/invisible print evidence, missing labels and full precision/recall remain risks; report them rather than implying perfect accuracy.

---

# v408 — Reject sentence-start Result citations; restore printed declaration locations (2026-11-07, Beijing UTC+08)

**Baseline:** complete attached v405 ZIP with the validated v406 and v407 root-level patches applied in order. **User evidence:** `Principal_Minor_Theorem_4_1_Correction-mathreader.json` (9 pages, full PDF.js `detectorInputLines`; JSON SHA-256 `892cc87e913ba72c9302c9cec7b502e423b9517f59f79bcc0f2b52f47ae1e625`). Exact unmodified v407 parser replay reproduces the exported wrong Results index: a paragraph beginning `Theorem 4.1 of the cited ...` on p.1 becomes a phantom theorem; `Lemma 4.4 from the main obstruction.` on p.1 becomes a phantom local lemma. Then global label deduplication retains that first Theorem 4.1 and discards the real p.4 declaration; monotone lemma numbering drops the real p.3 `Lemma 2.1` because the earlier false `Lemma 4.4` claims a higher number. **This is a parser-precision defect, not a PDF scroll-coordinate error.**

**Correction:** restrict unpunctuated label-first narrative continuations that begin with lower-case grammatical references (`of`, `from`, `in`, `on`, `with`, `for`, `and`, etc.). Check the *complete label* first so a rejected appendix reference `Theorem B.3 from ...` cannot fall through as invented `Theorem B`. Preserve explicit declaration punctuation, parenthetical theorem names, `Theorem 4.1 Let ...` / numbered-first headings, and authentic PDF.js line ratios. No broad numbering relaxations or inferred missing Results. Advance source cache key from v407 to v408 and `STRUCTURE_INDEX_VERSION` from 50 to 51 for ordinary local index rebuilds. User-imported detection remains protected under the existing portable-data rule; use **Rebuild index** on any imported old snapshot.

**Exact nine-page export replay:** before/after Results both contain 10 entries, but the phantom `Theorem 4.1` p.1/ratio .3856 and `Lemma 4.4` p.1/ratio .5818 are removed. The real `Lemma 2.1` p.3/ratio .1892537879 and `Theorem 4.1` p.4/ratio .3735366162 are restored. Correct Theorem 6.2 p.7/.1102007576, Corollary 6.3 p.7/.5514393939 and Proposition 6.4 p.7/.6488017677 survive unchanged. A new v408 regression **fails on pristine v407**, passes 23 standalone assertions after correction and 45 checks replaying all nine original exported detector-input pages. It tests reference negation, genuine declarations, appendix partial-label avoidance, and exact original coordinates.

**Other real export replay:** five additional saved PDF.js input corpora (Ahlfors, Giusti, Simon, SPS, Banach; 466 pages) were compared before/after using the production local Results detector plus sequential-label normalization. Giusti/Simon/SPS/Banach candidate outputs were identical. Ahlfors's unpunctuated Contents references (Definition 4-1 p.4, Definition 9-1 p.6) are now rejected by this classifier, exposing the actual p.62/p.136 body locations; note that this lightweight standalone replay does not model all the builder's separate TOC prefilters. The available Yau JSON has no `detectorInputLines`, so it is not counted in the 475-page replay. Existing TOC, bibliography, OCR, formula, equation and navigation regressions must still pass.

**Evidence identity boundary:** the same-named nine-page PDF recovered separately from the file library has SHA-256 `3f17cdb50b57daa73d7319b18467b040ec4aaa4d942af63c17c76fd8d9582510`, whereas this export's `document.id` is `sha256:584a32cd8b40e0a6afb01fad48198b8dce5f095f8be93b0f4141f826d83a4c3d`. They are **not a verified identical binary PDF pair**. The definitive reproduction uses *the user's own exported PDF.js detector-input lines and positions*, not an invented matching-source claim. The separately recovered PDF visually shows the same theorem and lemma wording, but cannot certify original-byte identity. Real deployed-browser reindexing, true mathematical formula transcription, and complete OCR recall remain unverified.

**Release verification:** see `regression/v408_release_gate.json` and `V408_PATCH_MANIFEST.md`. Accepted hard-reload raw OCR evidence loss remains untouched.

---

# v407 — Immediate reference preview dismissal (2026-11-07, Beijing UTC+08)

**Baseline:** complete v405 ZIP with the previously delivered v406 patch cleanly applied. **Reproduced defect:** `hideReferencePreview()` cancelled only the 260 ms hover timer and hid the card; an already-started asynchronous `referencePreviewData()` PDF snapshot Promise could still resolve and **reopen the popup after `pointerleave`**. The new isolated Chromium regression (`tests/reference_hover_lifecycle_v407.py`) failed on untouched v406 at `late Promise cannot reopen after leave`, using actual browser pointer movement and real production hover handlers with controllable asynchronous PDF lookup.

**Small correction:** dismissal now increments `referencePreviewSerial` to invalidate all in-flight previews and clears the active link. The completion path additionally checks current link ownership, DOM connection and pointer hover (or keyboard focus) before showing. A single passive global pointer-movement listener clears stranded popups when links are replaced without firing `pointerleave`; outside pointer-down, scroll and window blur also dismiss. Pointer-enter still opens after the existing 260 ms delay; pointer-leave and blur close synchronously. Preview remains `pointer-events:none` and cannot trap the mouse. Keyboard focus still supports previews. No OCR, mathematical indexes, PDF caching or document persistence rules are modified.

**Evidence boundary:** Chromium integration uses production functions, real pointer and focus events, and a **mocked PDF target/image Promise** to force the race; this is not a test of live website preview PDF rendering or deployed behavior. A full suite, syntax/assembly gate, and replay onto the v405+v406 baseline are required for release. Previously accepted Ahlfors raw OCR evidence loss after hard reload remains unchanged.

---

# v406 — Appendix equation retry with observed formula context (2026-11-07, Beijing UTC+08)

**Baseline:** complete uploaded v405 ZIP. **Confirmed general omission:** the old numeric-only equation-gap retry excludes every alphabetic appendix label. Original Giusti (1984) PDF p231 visibly prints `(A.1)` adjacent to the formula `μₖ(ℝⁿ) ≤ M`; the saved matched-sha export has `(A.2)` / `(A.3)` but not `(A.1)`. Offline original-image Tesseract `eng` PSM 6/11 at 18%-wide left-margin crop misreads `(A.1)` as `(AL)`, while a 28%-wide crop reads the exact label; this does **not** establish browser OCR success or a deployed v405 failure of its initial wide-margin pass. New v406 retry is bounded to eight originally evidenced appendix-gap pages, uses a 28% margin crop and PSM 6, demands an *actual exact parenthesized OCR label plus math outside the tag* on a geometrically validated display line, and never invents labels or accepts `(Al)`/theorem/prose references. Existing numeric-only retry no longer wastes work on appendix queries. Worker lifecycle/document-switch and retry timing protected. No storage repair, UI redesign or general OCR/structure classifier changes.

**Evidence/tests:** `APPENDIX_MARGIN_RETRY_v406.md`, `tests/appendix_margin_retry_v406_regression.js`, `tests/appendix_retry_pipeline_v406_regression.js`, `regression/v406_original_corpus_audit.json`. The first newly added regression failed before the change (appendix retry validator absent) and passes afterward; the separate pipeline test uses a mocked OCR worker, not real PDF.js/Tesseract.js. Six original PDF/export SHA matches: 539 pages, no structural integrity errors, but genuine mathematical transcription errors persist (Giusti p231 native missing display, Ahlfors p81 native text mistakes). **Live v406 Giusti automatic recovery, exact browser navigation, complete image-to-LaTeX correctness and 100% accuracy are NOT certified.** Ahlfors hard-reload raw-evidence loss remains the accepted, unmodified limitation.

---

# v405 — Manual appendix equation labels (2026-11-07, Beijing UTC+08)

**Baseline:** v404 application, with the audit-only v405 campaign carried forward. **Scope:** manual Equations → Add / Reselect; no automatic OCR/detection changes.

- **Reproduced defect:** `equationLabelFromSelectionText()` accepted numeric `(12.45)` and symbolic `(*)` but rejected legitimate appendix equation numbers `(A.1)` and `(B-3)`, despite the automatic index already recognizing those numbering families. The new regression failed on v404 at `(A.1)` before the change.
- **Correction:** manual selected/typed equation labels reuse the existing `isPlausibleEquationTagInner()` grammar, covering `(A.1)`, `(A.10)`, `(A.1.2)`, `(B-3)`, `(A1)`, `(AA.5)`, `(C.2a)`, `(a.4)`; numeric and symbolic types remain supported. This only labels a user-selected physical location. Neither a missing equation nor its coordinates are inferred from sequence gaps. More general expressions, isolated letters, prose references and years remain invalid.
- Update the compact Add prompt and validation message in English/Chinese to include `(A.1)` without new interface controls. Preserve the order placement, linked page ratio, manual correction persistence, and all prior index formats.
- **Regression:** `tests/manual_appendix_equation_v405_regression.js` exercises the manual Add → page-click → typed label, manual Reselect with selected text, index reconstruction, ordering, persistence callback, Unicode normalization and negative examples; the pre-fix v404 run failed on `(A.1)` and the corrected run passes its 38 assertions. JS bootstrap/HTML cache keys are advanced to v405; inherited version-key checks updated.
- **Known unrelated limitation remains accepted:** Ahlfors raw equation-margin OCR observations are lost on hard reload in v404 live exports; Structure/Results/Equations/Bibliography and annotations survive. No IndexedDB repair attempted in v405. Formula OCR correctness and actual deployment-browser Add workflow are **not** certified by source-level or isolated shell tests.

---


### Verification engine V5 evidence gates

The canonical verification entry point is `tests/verification/release_gate.py`.
The release gate now includes real original-PDF Chromium navigation targets,
actual browser Texify crop-to-LaTeX measurement, repeated reliability/performance
runs, and strict supervised subprocess/partial-evidence accounting. The reader
runtime is unchanged. See `tests/verification/README.md` for reviewed manifest
schema, evidence distinctions, and the requirements for a meaningful PASS.
Without the reviewed original-PDF corpus, exact pinned PDF.js assets and a real
Texify backend, release certification **MUST remain INCOMPLETE** even when all
synthetic, source-level, and mocked-Chromium regressions are green.
